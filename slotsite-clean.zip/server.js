const express = require('express');
const http = require('http');
const socketIo = require('socket.io');
const mongoose = require('mongoose');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const cookieParser = require('cookie-parser');
const cors = require('cors');
require('dotenv').config();

const app = express();
const server = http.createServer(app);
const io = socketIo(server, {
  cors: {
    origin: "*",
    methods: ["GET", "POST"]
  }
});

// Middleware
app.use(express.json());
app.use(express.urlencoded({ extended: true }));
app.use(cookieParser());
app.use(cors());
app.use(express.static('public'));

// MongoDB Connection
mongoose.connect(process.env.MONGODB_URI, {
  useNewUrlParser: true,
  useUnifiedTopology: true
}).then(() => {
  console.log('✅ MongoDB connected');
  initializeAdmin();
}).catch(err => console.error('❌ MongoDB connection error:', err));

// User Schema
const userSchema = new mongoose.Schema({
  username: { type: String, required: true, unique: true },
  password: { type: String, required: true },
  email: String,
  phone: String,
  balance: { type: Number, default: 0 },
  role: { type: String, enum: ['member', 'admin'], default: 'member' },
  status: { type: String, enum: ['active', 'suspended'], default: 'active' },
  createdAt: { type: Date, default: Date.now },
  lastLogin: Date
});

const User = mongoose.model('User', userSchema);

// Transaction Schema
const transactionSchema = new mongoose.Schema({
  userId: { type: mongoose.Schema.Types.ObjectId, ref: 'User' },
  username: String,
  type: { type: String, enum: ['deposit', 'withdraw'] },
  amount: Number,
  status: { type: String, enum: ['pending', 'approved', 'rejected'], default: 'pending' },
  createdAt: { type: Date, default: Date.now }
});

const Transaction = mongoose.model('Transaction', transactionSchema);

// Initialize Admin Account
async function initializeAdmin() {
  try {
    const adminExists = await User.findOne({ role: 'admin' });
    if (!adminExists) {
      const hashedPassword = await bcrypt.hash(process.env.ADMIN_PASSWORD, 10);
      await User.create({
        username: process.env.ADMIN_USERNAME,
        password: hashedPassword,
        role: 'admin',
        balance: 0
      });
      console.log('✅ Admin account created');
    }
  } catch (error) {
    console.error('❌ Admin initialization error:', error);
  }
}

// JWT Middleware
const authenticateToken = (req, res, next) => {
  const token = req.cookies.token || req.headers['authorization']?.split(' ')[1];
  if (!token) return res.status(401).json({ error: 'Unauthorized' });

  jwt.verify(token, process.env.JWT_SECRET, (err, user) => {
    if (err) return res.status(403).json({ error: 'Forbidden' });
    req.user = user;
    next();
  });
};

// Admin Middleware
const isAdmin = (req, res, next) => {
  if (req.user.role !== 'admin') {
    return res.status(403).json({ error: 'Admin access required' });
  }
  next();
};

// Routes - Login
app.post('/api/login', async (req, res) => {
  try {
    const { username, password } = req.body;
    const user = await User.findOne({ username });

    if (!user || user.status === 'suspended') {
      return res.status(401).json({ error: 'Invalid credentials or account suspended' });
    }

    const validPassword = await bcrypt.compare(password, user.password);
    if (!validPassword) {
      return res.status(401).json({ error: 'Invalid credentials' });
    }

    user.lastLogin = new Date();
    await user.save();

    const token = jwt.sign(
      { id: user._id, username: user.username, role: user.role },
      process.env.JWT_SECRET,
      { expiresIn: '24h' }
    );

    res.cookie('token', token, { httpOnly: true, maxAge: 86400000 });
    res.json({
      success: true,
      token,
      user: {
        id: user._id,
        username: user.username,
        role: user.role,
        balance: user.balance
      }
    });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// Routes - Register
app.post('/api/register', async (req, res) => {
  try {
    const { username, password, email, phone } = req.body;

    const existingUser = await User.findOne({ username });
    if (existingUser) {
      return res.status(400).json({ error: 'Username already exists' });
    }

    const hashedPassword = await bcrypt.hash(password, 10);
    const user = await User.create({
      username,
      password: hashedPassword,
      email,
      phone
    });

    res.json({ success: true, message: 'Registration successful' });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// Routes - Get User Profile
app.get('/api/profile', authenticateToken, async (req, res) => {
  try {
    const user = await User.findById(req.user.id).select('-password');
    res.json(user);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// Routes - Deposit Request
app.post('/api/deposit', authenticateToken, async (req, res) => {
  try {
    const { amount } = req.body;
    const transaction = await Transaction.create({
      userId: req.user.id,
      username: req.user.username,
      type: 'deposit',
      amount: parseInt(amount),
      status: 'pending'
    });

    res.json({ success: true, transaction });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// Routes - Withdraw Request
app.post('/api/withdraw', authenticateToken, async (req, res) => {
  try {
    const { amount } = req.body;
    const user = await User.findById(req.user.id);

    if (user.balance < amount) {
      return res.status(400).json({ error: 'Insufficient balance' });
    }

    const transaction = await Transaction.create({
      userId: req.user.id,
      username: req.user.username,
      type: 'withdraw',
      amount: parseInt(amount),
      status: 'pending'
    });

    res.json({ success: true, transaction });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// Admin Routes - Get All Users
app.get('/api/admin/users', authenticateToken, isAdmin, async (req, res) => {
  try {
    const users = await User.find().select('-password').sort({ createdAt: -1 });
    res.json(users);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// Admin Routes - Update User Balance
app.post('/api/admin/users/:id/balance', authenticateToken, isAdmin, async (req, res) => {
  try {
    const { balance } = req.body;
    const user = await User.findByIdAndUpdate(
      req.params.id,
      { balance: parseInt(balance) },
      { new: true }
    ).select('-password');

    io.emit('balance-update', { userId: user._id, balance: user.balance });
    res.json({ success: true, user });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// Admin Routes - Update User Status
app.post('/api/admin/users/:id/status', authenticateToken, isAdmin, async (req, res) => {
  try {
    const { status } = req.body;
    const user = await User.findByIdAndUpdate(
      req.params.id,
      { status },
      { new: true }
    ).select('-password');

    res.json({ success: true, user });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// Admin Routes - Delete User
app.delete('/api/admin/users/:id', authenticateToken, isAdmin, async (req, res) => {
  try {
    await User.findByIdAndDelete(req.params.id);
    res.json({ success: true, message: 'User deleted' });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// Admin Routes - Get All Transactions
app.get('/api/admin/transactions', authenticateToken, isAdmin, async (req, res) => {
  try {
    const transactions = await Transaction.find()
      .populate('userId', 'username')
      .sort({ createdAt: -1 });
    res.json(transactions);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// Admin Routes - Approve Transaction
app.post('/api/admin/transactions/:id/approve', authenticateToken, isAdmin, async (req, res) => {
  try {
    const transaction = await Transaction.findById(req.params.id);
    if (!transaction) {
      return res.status(404).json({ error: 'Transaction not found' });
    }

    const user = await User.findById(transaction.userId);

    if (transaction.type === 'deposit') {
      user.balance += transaction.amount;
    } else if (transaction.type === 'withdraw') {
      user.balance -= transaction.amount;
    }

    await user.save();
    transaction.status = 'approved';
    await transaction.save();

    // Emit real-time transaction update
    io.emit('new-transaction', {
      type: transaction.type,
      username: maskUsername(transaction.username),
      amount: transaction.amount
    });

    res.json({ success: true, transaction });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// Admin Routes - Reject Transaction
app.post('/api/admin/transactions/:id/reject', authenticateToken, isAdmin, async (req, res) => {
  try {
    const transaction = await Transaction.findByIdAndUpdate(
      req.params.id,
      { status: 'rejected' },
      { new: true }
    );

    res.json({ success: true, transaction });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// Get Recent Transactions for Ticker
app.get('/api/transactions/recent', async (req, res) => {
  try {
    const deposits = await Transaction.find({ type: 'deposit', status: 'approved' })
      .sort({ createdAt: -1 })
      .limit(50);

    const withdraws = await Transaction.find({ type: 'withdraw', status: 'approved' })
      .sort({ createdAt: -1 })
      .limit(50);

    res.json({
      deposits: deposits.map(t => ({
        username: maskUsername(t.username),
        amount: t.amount
      })),
      withdraws: withdraws.map(t => ({
        username: maskUsername(t.username),
        amount: t.amount
      }))
    });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// Helper function to mask username
function maskUsername(username) {
  if (!username || username.length < 3) return username;
  const visibleChars = Math.ceil(username.length / 3);
  return username.substring(0, visibleChars) + '***' + (username.length > 5 ? username.slice(-1) : '');
}

// Socket.IO Connection
io.on('connection', (socket) => {
  console.log('✅ Client connected:', socket.id);

  socket.on('disconnect', () => {
    console.log('❌ Client disconnected:', socket.id);
  });
});

// Generate fake transactions every 10 seconds for demo
setInterval(async () => {
  const users = await User.find({ role: 'member' });
  if (users.length === 0) return;

  const randomUser = users[Math.floor(Math.random() * users.length)];
  const type = Math.random() > 0.5 ? 'deposit' : 'withdraw';
  const amount = Math.floor(Math.random() * 180000) + 10000;

  io.emit('new-transaction', {
    type,
    username: maskUsername(randomUser.username),
    amount
  });
}, 10000);

// Start Server
const PORT = process.env.PORT || 3000;
server.listen(PORT, () => {
  console.log(`🚀 Server running on http://localhost:${PORT}`);
  console.log(`👤 Admin: ${process.env.ADMIN_USERNAME} / ${process.env.ADMIN_PASSWORD}`);
});
