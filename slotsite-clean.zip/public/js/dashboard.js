// Check authentication
const token = localStorage.getItem('token');
const user = JSON.parse(localStorage.getItem('user') || '{}');

if (!token || !user.id) {
    window.location.href = '/';
}

// Connect to Socket.IO
const socket = io();

// DOM Elements
const userDisplay = document.getElementById('userDisplay');
const balanceDisplay = document.getElementById('balanceDisplay');
const logoutBtn = document.getElementById('logoutBtn');
const sidebarLinks = document.querySelectorAll('.sidebar-link');
const contentSections = document.querySelectorAll('.content-section');
const depositForm = document.getElementById('depositForm');
const withdrawForm = document.getElementById('withdrawForm');
const quickBtns = document.querySelectorAll('.quick-btn');
const playBtns = document.querySelectorAll('.btn-play');

// Initialize
userDisplay.textContent = user.username;
balanceDisplay.textContent = user.balance.toLocaleString('id-ID');

// Logout
logoutBtn.addEventListener('click', () => {
    localStorage.removeItem('token');
    localStorage.removeItem('user');
    window.location.href = '/';
});

// Sidebar navigation
sidebarLinks.forEach(link => {
    link.addEventListener('click', (e) => {
        e.preventDefault();
        
        // Remove active class from all links and sections
        sidebarLinks.forEach(l => l.classList.remove('active'));
        contentSections.forEach(s => s.classList.remove('active'));
        
        // Add active class to clicked link
        link.classList.add('active');
        
        // Show corresponding section
        const target = link.getAttribute('href').substring(1);
        const section = document.getElementById(`${target}-section`);
        if (section) {
            section.classList.add('active');
        }
    });
});

// Quick amount buttons
quickBtns.forEach(btn => {
    btn.addEventListener('click', () => {
        const amount = btn.dataset.amount;
        const parent = btn.closest('form');
        const input = parent.querySelector('input[type="number"]');
        if (input) {
            input.value = amount;
        }
    });
});

// Deposit form
depositForm.addEventListener('submit', async (e) => {
    e.preventDefault();
    
    const amount = document.getElementById('depositAmount').value;
    
    if (amount < 10000) {
        alert('Minimum deposit adalah Rp.10,000');
        return;
    }
    
    try {
        const response = await fetch('/api/deposit', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'Authorization': `Bearer ${token}`
            },
            body: JSON.stringify({ amount })
        });
        
        const data = await response.json();
        
        if (data.success) {
            alert('Permintaan deposit berhasil dikirim! Menunggu persetujuan admin.');
            depositForm.reset();
        } else {
            alert(data.error || 'Gagal mengirim permintaan deposit');
        }
    } catch (error) {
        alert('Error: ' + error.message);
    }
});

// Withdraw form
withdrawForm.addEventListener('submit', async (e) => {
    e.preventDefault();
    
    const amount = document.getElementById('withdrawAmount').value;
    
    if (amount < 50000) {
        alert('Minimum withdraw adalah Rp.50,000');
        return;
    }
    
    const currentBalance = parseInt(balanceDisplay.textContent.replace(/\./g, ''));
    if (amount > currentBalance) {
        alert('Saldo tidak mencukupi');
        return;
    }
    
    try {
        const response = await fetch('/api/withdraw', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'Authorization': `Bearer ${token}`
            },
            body: JSON.stringify({ amount })
        });
        
        const data = await response.json();
        
        if (data.success) {
            alert('Permintaan withdraw berhasil dikirim! Menunggu persetujuan admin.');
            withdrawForm.reset();
        } else {
            alert(data.error || 'Gagal mengirim permintaan withdraw');
        }
    } catch (error) {
        alert('Error: ' + error.message);
    }
});

// Play game buttons
playBtns.forEach(btn => {
    btn.addEventListener('click', () => {
        const gameCard = btn.closest('.game-card');
        const provider = gameCard.dataset.provider;
        alert(`Loading ${provider.toUpperCase()} games...\n\nFitur ini akan membuka slot games dari provider ${provider}.`);
    });
});

// Listen for balance updates
socket.on('balance-update', (data) => {
    if (data.userId === user.id) {
        balanceDisplay.textContent = data.balance.toLocaleString('id-ID');
        user.balance = data.balance;
        localStorage.setItem('user', JSON.stringify(user));
    }
});

// Load user profile
async function loadProfile() {
    try {
        const response = await fetch('/api/profile', {
            headers: {
                'Authorization': `Bearer ${token}`
            }
        });
        
        const data = await response.json();
        
        if (data.balance !== undefined) {
            balanceDisplay.textContent = data.balance.toLocaleString('id-ID');
            user.balance = data.balance;
            localStorage.setItem('user', JSON.stringify(user));
        }
    } catch (error) {
        console.error('Error loading profile:', error);
    }
}

// Load profile on page load and every 30 seconds
loadProfile();
setInterval(loadProfile, 30000);
