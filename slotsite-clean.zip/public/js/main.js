// Connect to Socket.IO
const socket = io();

// DOM Elements
const loginForm = document.getElementById('loginForm');
const registerForm = document.getElementById('registerForm');
const showRegister = document.getElementById('showRegister');
const showLogin = document.getElementById('showLogin');
const loginSection = document.querySelector('.login-section');
const registerSection = document.querySelector('.register-section');
const depositTicker = document.getElementById('depositTicker');
const withdrawTicker = document.getElementById('withdrawTicker');

// Toggle between login and register
showRegister?.addEventListener('click', (e) => {
    e.preventDefault();
    loginSection.style.display = 'none';
    registerSection.style.display = 'flex';
});

showLogin?.addEventListener('click', (e) => {
    e.preventDefault();
    registerSection.style.display = 'none';
    loginSection.style.display = 'flex';
});

// Login
loginForm?.addEventListener('submit', async (e) => {
    e.preventDefault();
    
    const username = document.getElementById('username').value;
    const password = document.getElementById('password').value;
    
    try {
        const response = await fetch('/api/login', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ username, password })
        });
        
        const data = await response.json();
        
        if (data.success) {
            localStorage.setItem('token', data.token);
            localStorage.setItem('user', JSON.stringify(data.user));
            
            if (data.user.role === 'admin') {
                window.location.href = '/admin.html';
            } else {
                window.location.href = '/dashboard.html';
            }
        } else {
            alert(data.error || 'Login gagal');
        }
    } catch (error) {
        alert('Error: ' + error.message);
    }
});

// Register
registerForm?.addEventListener('submit', async (e) => {
    e.preventDefault();
    
    const username = document.getElementById('regUsername').value;
    const password = document.getElementById('regPassword').value;
    const email = document.getElementById('regEmail').value;
    const phone = document.getElementById('regPhone').value;
    
    try {
        const response = await fetch('/api/register', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ username, password, email, phone })
        });
        
        const data = await response.json();
        
        if (data.success) {
            alert('Registrasi berhasil! Silakan login.');
            registerSection.style.display = 'none';
            loginSection.style.display = 'flex';
            registerForm.reset();
        } else {
            alert(data.error || 'Registrasi gagal');
        }
    } catch (error) {
        alert('Error: ' + error.message);
    }
});

// Load initial transactions
async function loadTransactions() {
    try {
        const response = await fetch('/api/transactions/recent');
        const data = await response.json();
        
        // Render deposits
        if (data.deposits) {
            data.deposits.forEach(tx => {
                addTickerItem('deposit', tx.username, tx.amount);
            });
        }
        
        // Render withdraws
        if (data.withdraws) {
            data.withdraws.forEach(tx => {
                addTickerItem('withdraw', tx.username, tx.amount);
            });
        }
    } catch (error) {
        console.error('Error loading transactions:', error);
    }
}

// Add ticker item
function addTickerItem(type, username, amount) {
    const ticker = type === 'deposit' ? depositTicker : withdrawTicker;
    
    const item = document.createElement('div');
    item.className = 'ticker-item';
    item.innerHTML = `
        <img src="data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='32' height='32'%3E%3Ccircle cx='16' cy='16' r='16' fill='%236366f1'/%3E%3Ctext x='16' y='22' font-family='Arial' font-size='16' fill='white' text-anchor='middle'%3E${username.charAt(0).toUpperCase()}%3C/text%3E%3C/svg%3E" alt="${username}">
        <span class="ticker-username">${username}</span>
        <span class="ticker-amount">Rp.${amount.toLocaleString('id-ID')}</span>
    `;
    
    ticker.insertBefore(item, ticker.firstChild);
    
    // Keep only 50 items
    while (ticker.children.length > 50) {
        ticker.removeChild(ticker.lastChild);
    }
}

// Listen for new transactions
socket.on('new-transaction', (data) => {
    addTickerItem(data.type, data.username, data.amount);
});

// Load transactions on page load
if (depositTicker && withdrawTicker) {
    loadTransactions();
}
