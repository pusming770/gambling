// Check authentication
const token = localStorage.getItem('token');
const user = JSON.parse(localStorage.getItem('user') || '{}');

if (!token || user.role !== 'admin') {
    window.location.href = '/';
}

// DOM Elements
const adminDisplay = document.getElementById('adminDisplay');
const logoutBtn = document.getElementById('logoutBtn');
const sidebarLinks = document.querySelectorAll('.sidebar-link');
const contentSections = document.querySelectorAll('.content-section');
const usersTableBody = document.getElementById('usersTableBody');
const transactionsTableBody = document.getElementById('transactionsTableBody');
const searchUsers = document.getElementById('searchUsers');
const filterBtns = document.querySelectorAll('.filter-btn');
const editUserModal = document.getElementById('editUserModal');
const editUserForm = document.getElementById('editUserForm');
const cancelEdit = document.getElementById('cancelEdit');
const closeModal = document.querySelector('.close');

// Initialize
adminDisplay.textContent = user.username;

// Logout
logoutBtn.addEventListener('click', () => {
    localStorage.removeItem('token');
    localStorage.removeItem('user');
    window.location.href = '/';
});

// Sidebar navigation
sidebarLinks.forEach(link => {
    link.addEventListener('click', (e) => {
        e.preventDefault();
        
        sidebarLinks.forEach(l => l.classList.remove('active'));
        contentSections.forEach(s => s.classList.remove('active'));
        
        link.classList.add('active');
        
        const target = link.getAttribute('href').substring(1);
        const section = document.getElementById(`${target}-section`);
        if (section) {
            section.classList.add('active');
            
            // Load data when switching sections
            if (target === 'users') {
                loadUsers();
            } else if (target === 'transactions') {
                loadTransactions();
            } else if (target === 'stats') {
                loadStats();
            }
        }
    });
});

// Load users
async function loadUsers() {
    try {
        const response = await fetch('/api/admin/users', {
            headers: {
                'Authorization': `Bearer ${token}`
            }
        });
        
        const users = await response.json();
        
        usersTableBody.innerHTML = users
            .filter(u => u.role !== 'admin')
            .map(u => `
                <tr>
                    <td>${u.username}</td>
                    <td>${u.email || '-'}</td>
                    <td>${u.phone || '-'}</td>
                    <td>Rp.${u.balance.toLocaleString('id-ID')}</td>
                    <td><span class="status-badge status-${u.status}">${u.status.toUpperCase()}</span></td>
                    <td>${u.lastLogin ? new Date(u.lastLogin).toLocaleString('id-ID') : '-'}</td>
                    <td>
                        <button class="action-btn btn-edit" onclick="editUser('${u._id}')">EDIT</button>
                        <button class="action-btn btn-delete" onclick="deleteUser('${u._id}')">DELETE</button>
                    </td>
                </tr>
            `).join('');
    } catch (error) {
        console.error('Error loading users:', error);
    }
}

// Search users
searchUsers?.addEventListener('input', (e) => {
    const search = e.target.value.toLowerCase();
    const rows = usersTableBody.querySelectorAll('tr');
    
    rows.forEach(row => {
        const text = row.textContent.toLowerCase();
        row.style.display = text.includes(search) ? '' : 'none';
    });
});

// Edit user
window.editUser = async (userId) => {
    try {
        const response = await fetch('/api/admin/users', {
            headers: {
                'Authorization': `Bearer ${token}`
            }
        });
        
        const users = await response.json();
        const user = users.find(u => u._id === userId);
        
        if (user) {
            document.getElementById('editUserId').value = user._id;
            document.getElementById('editUsername').value = user.username;
            document.getElementById('editBalance').value = user.balance;
            document.getElementById('editStatus').value = user.status;
            
            editUserModal.classList.add('show');
        }
    } catch (error) {
        console.error('Error loading user:', error);
    }
};

// Close modal
closeModal?.addEventListener('click', () => {
    editUserModal.classList.remove('show');
});

cancelEdit?.addEventListener('click', () => {
    editUserModal.classList.remove('show');
});

// Edit user form submit
editUserForm?.addEventListener('submit', async (e) => {
    e.preventDefault();
    
    const userId = document.getElementById('editUserId').value;
    const balance = document.getElementById('editBalance').value;
    const status = document.getElementById('editStatus').value;
    
    try {
        // Update balance
        const balanceResponse = await fetch(`/api/admin/users/${userId}/balance`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'Authorization': `Bearer ${token}`
            },
            body: JSON.stringify({ balance })
        });
        
        // Update status
        const statusResponse = await fetch(`/api/admin/users/${userId}/status`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'Authorization': `Bearer ${token}`
            },
            body: JSON.stringify({ status })
        });
        
        if (balanceResponse.ok && statusResponse.ok) {
            alert('User berhasil diupdate!');
            editUserModal.classList.remove('show');
            loadUsers();
        } else {
            alert('Gagal mengupdate user');
        }
    } catch (error) {
        alert('Error: ' + error.message);
    }
});

// Delete user
window.deleteUser = async (userId) => {
    if (!confirm('Yakin ingin menghapus user ini?')) return;
    
    try {
        const response = await fetch(`/api/admin/users/${userId}`, {
            method: 'DELETE',
            headers: {
                'Authorization': `Bearer ${token}`
            }
        });
        
        const data = await response.json();
        
        if (data.success) {
            alert('User berhasil dihapus!');
            loadUsers();
        } else {
            alert('Gagal menghapus user');
        }
    } catch (error) {
        alert('Error: ' + error.message);
    }
};

// Load transactions
let allTransactions = [];

async function loadTransactions(filter = 'all') {
    try {
        const response = await fetch('/api/admin/transactions', {
            headers: {
                'Authorization': `Bearer ${token}`
            }
        });
        
        allTransactions = await response.json();
        renderTransactions(filter);
    } catch (error) {
        console.error('Error loading transactions:', error);
    }
}

// Render transactions
function renderTransactions(filter) {
    let filtered = allTransactions;
    
    if (filter !== 'all') {
        filtered = allTransactions.filter(t => t.status === filter);
    }
    
    transactionsTableBody.innerHTML = filtered.map(t => `
        <tr>
            <td>${t.username}</td>
            <td><span class="status-badge ${t.type === 'deposit' ? 'status-approved' : 'status-pending'}">${t.type.toUpperCase()}</span></td>
            <td>Rp.${t.amount.toLocaleString('id-ID')}</td>
            <td><span class="status-badge status-${t.status}">${t.status.toUpperCase()}</span></td>
            <td>${new Date(t.createdAt).toLocaleString('id-ID')}</td>
            <td>
                ${t.status === 'pending' ? `
                    <button class="action-btn btn-approve" onclick="approveTransaction('${t._id}')">APPROVE</button>
                    <button class="action-btn btn-reject" onclick="rejectTransaction('${t._id}')">REJECT</button>
                ` : '-'}
            </td>
        </tr>
    `).join('');
}

// Filter buttons
filterBtns.forEach(btn => {
    btn.addEventListener('click', () => {
        filterBtns.forEach(b => b.classList.remove('active'));
        btn.classList.add('active');
        
        const filter = btn.dataset.filter;
        renderTransactions(filter);
    });
});

// Approve transaction
window.approveTransaction = async (transactionId) => {
    try {
        const response = await fetch(`/api/admin/transactions/${transactionId}/approve`, {
            method: 'POST',
            headers: {
                'Authorization': `Bearer ${token}`
            }
        });
        
        const data = await response.json();
        
        if (data.success) {
            alert('Transaksi berhasil diapprove!');
            loadTransactions();
        } else {
            alert('Gagal approve transaksi');
        }
    } catch (error) {
        alert('Error: ' + error.message);
    }
};

// Reject transaction
window.rejectTransaction = async (transactionId) => {
    if (!confirm('Yakin ingin reject transaksi ini?')) return;
    
    try {
        const response = await fetch(`/api/admin/transactions/${transactionId}/reject`, {
            method: 'POST',
            headers: {
                'Authorization': `Bearer ${token}`
            }
        });
        
        const data = await response.json();
        
        if (data.success) {
            alert('Transaksi berhasil direject!');
            loadTransactions();
        } else {
            alert('Gagal reject transaksi');
        }
    } catch (error) {
        alert('Error: ' + error.message);
    }
};

// Load stats
async function loadStats() {
    try {
        const [usersRes, transactionsRes] = await Promise.all([
            fetch('/api/admin/users', {
                headers: { 'Authorization': `Bearer ${token}` }
            }),
            fetch('/api/admin/transactions', {
                headers: { 'Authorization': `Bearer ${token}` }
            })
        ]);
        
        const users = await usersRes.json();
        const transactions = await transactionsRes.json();
        
        // Calculate stats
        const totalUsers = users.filter(u => u.role !== 'admin').length;
        const totalDeposits = transactions
            .filter(t => t.type === 'deposit' && t.status === 'approved')
            .reduce((sum, t) => sum + t.amount, 0);
        const totalWithdraws = transactions
            .filter(t => t.type === 'withdraw' && t.status === 'approved')
            .reduce((sum, t) => sum + t.amount, 0);
        const pendingTransactions = transactions.filter(t => t.status === 'pending').length;
        
        // Update UI
        document.getElementById('totalUsers').textContent = totalUsers;
        document.getElementById('totalDeposits').textContent = `Rp.${totalDeposits.toLocaleString('id-ID')}`;
        document.getElementById('totalWithdraws').textContent = `Rp.${totalWithdraws.toLocaleString('id-ID')}`;
        document.getElementById('pendingTransactions').textContent = pendingTransactions;
    } catch (error) {
        console.error('Error loading stats:', error);
    }
}

// Load initial data
loadUsers();
