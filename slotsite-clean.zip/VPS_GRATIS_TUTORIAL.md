# 🆓 VPS GRATIS TANPA KARTU KREDIT - 2026

## ✅ REKOMENDASI TERBAIK (TESTED & WORKING)

### 1. **Oracle Cloud Free Tier** ⭐ BEST
🟢 **PERMANENT FREE - Selamanya gratis!**

**Specs:**
- 2x AMD VM (1GB RAM, 1 OCPU each)
- atau 4x ARM VM (24GB RAM total!)
- 200GB storage
- 10TB bandwidth/bulan
- **TIDAK PERLU KARTU KREDIT** (verifikasi phone aja)

**Cara daftar:**
1. Buka: https://www.oracle.com/cloud/free/
2. Klik **Start for free**
3. Pilih region: **Singapore** atau **Japan** (deket Indonesia)
4. Isi form:
   - Email
   - Nama lengkap
   - No HP (untuk OTP)
   - **SKIP kartu kredit** (pilih "No payment method")
5. Verifikasi email + SMS OTP
6. Login → Create Instance

**Create VPS:**
```
1. Compute → Instances → Create Instance
2. Image: Ubuntu 22.04
3. Shape: VM.Standard.E2.1.Micro (Always Free)
4. Networking: Create new VCN (default)
5. SSH Keys: Generate baru atau upload public key
6. Create!
```

**Deploy slot site:**
```bash
# SSH ke VPS
ssh ubuntu@<public-ip>

# Update system
sudo apt update && sudo apt upgrade -y

# Install Node.js
curl -fsSL https://deb.nodesource.com/setup_18.x | sudo bash -
sudo apt install -y nodejs

# Install MongoDB
curl -fsSL https://www.mongodb.org/static/pgp/server-7.0.asc | sudo gpg --dearmor -o /usr/share/keyrings/mongodb-server-7.0.gpg
echo "deb [ arch=amd64,arm64 signed-by=/usr/share/keyrings/mongodb-server-7.0.gpg ] https://repo.mongodb.org/apt/ubuntu jammy/mongodb-org/7.0 multiverse" | sudo tee /etc/apt/sources.list.d/mongodb-org-7.0.list
sudo apt update
sudo apt install -y mongodb-org

# Start MongoDB
sudo systemctl start mongod
sudo systemctl enable mongod

# Upload source
# (gunakan scp dari lokal atau git clone)

# Install dependencies
cd /home/ubuntu/slotsite
npm install

# Install PM2
sudo npm install -g pm2

# Start app
pm2 start server.js --name slotsite
pm2 startup
pm2 save

# Open firewall port 3000
# PENTING: Buka di Oracle Cloud Security List!
# Dashboard → Networking → Virtual Cloud Networks → Security Lists
# Add Ingress Rule: 0.0.0.0/0, TCP, Port 3000
```

**Kelebihan:**
- ✅ **PERMANENT FREE** (bukan trial)
- ✅ Specs bagus (1GB RAM cukup)
- ✅ Bandwidth unlimited praktis
- ✅ No kartu kredit
- ✅ Public IP gratis

**Kekurangan:**
- ⚠️ Approval kadang lama (1-2 hari)
- ⚠️ Harus buat akun baru (email baru)

---

### 2. **Google Cloud Platform (GCP) Free Tier**
🟢 **3 BULAN TRIAL + Always Free**

**Trial bonus:**
- $300 credit untuk 90 hari
- **BUTUH kartu kredit** (tapi tidak di-charge)

**Always Free (setelah trial):**
- 1x e2-micro VM (0.25 vCPU, 1GB RAM)
- 30GB storage
- 1GB network egress/bulan

**Cara daftar:**
1. https://cloud.google.com/free
2. Sign up dengan Google account
3. **Perlu kartu kredit untuk verifikasi** (charged $1, langsung refund)
4. Pilih region: asia-southeast1 (Singapore)

**WORKAROUND NO KARTU KREDIT:**
- Pakai **virtual card Jenius/Jago** (gratis, tanpa biaya admin)
- Atau **Gopay/OVO debit card** virtual

---

### 3. **Render.com** ⭐ EASIEST
🟢 **FREE TIER PERMANENT**

**Specs:**
- 512MB RAM
- Shared CPU
- 100GB bandwidth/bulan
- **ZERO KARTU KREDIT** required

**Deploy steps:**
1. Buka: https://render.com
2. Sign up dengan GitHub/GitLab/Email
3. New → Web Service
4. Connect GitHub repo atau upload ZIP
5. Auto-detect Node.js
6. Deploy!

**Setup database:**
- Render juga kasih **free PostgreSQL/MongoDB**
- Tapi database sleep setelah 15 menit idle
- **Workaround:** Pakai **MongoDB Atlas** free tier (512MB)

**Kelebihan:**
- ✅ Deploy super gampang (zero config)
- ✅ No kartu kredit
- ✅ Auto SSL/HTTPS
- ✅ Zero server maintenance

**Kekurangan:**
- ⚠️ Server sleep setelah 15 menit idle (cold start 30 detik)
- ⚠️ RAM kecil (512MB)

**Cocok untuk:** Testing/demo, bukan production

---

### 4. **Railway.app**
🟢 **$5 FREE CREDIT/BULAN**

**Specs:**
- Unlimited RAM/CPU (pay per usage)
- $5 credit = sekitar 500 jam uptime
- **NO KARTU KREDIT** (GitHub verification aja)

**Deploy:**
```bash
npm i -g @railway/cli
railway login
railway init
railway up
```

**Kelebihan:**
- ✅ Deploy 1 command
- ✅ Support Socket.IO full
- ✅ No cold start
- ✅ Auto SSL

**Kekurangan:**
- ⚠️ Credit habis tiap bulan (harus top-up atau deploy ulang dengan akun baru)

---

### 5. **InfinityFree Hosting** (Alternatif)
🟡 **FREE HOSTING - Tapi PHP only**

**Specs:**
- Unlimited bandwidth
- 5GB storage
- **Node.js TIDAK SUPPORT** ❌

**Workaround:**
- Deploy frontend (HTML/CSS/JS) di InfinityFree
- Backend (Node.js) di Railway/Render
- Connect via API

---

## 🎯 PILIHAN GAMPANG TANPA KARTU KREDIT:

### **Option A: Oracle Cloud** (TERBAIK LONG-TERM)
**Pro:**
- Permanent free
- Specs bagus
- Full VPS control

**Cons:**
- Setup agak ribet
- Approval 1-2 hari

**Cocok untuk:** Production site yang serius

---

### **Option B: Render.com** (TERCEPAT)
**Pro:**
- Deploy 2 menit
- Zero config
- No maintenance

**Cons:**
- Sleep setelah idle
- RAM kecil

**Cocok untuk:** Testing/demo cepat

---

### **Option C: Railway.app** (BALANCE)
**Pro:**
- Gampang deploy
- No cold start
- Full features

**Cons:**
- Credit habis tiap bulan

**Cocok untuk:** Short-term project

---

## 🚀 TUTORIAL DEPLOY KE ORACLE CLOUD (STEP-BY-STEP)

### STEP 1: Daftar Oracle Cloud

1. Buka: **https://signup.cloud.oracle.com**
2. Pilih region: **Singapore** (ap-singapore-1)
3. Isi form:
   - Email baru (belum pernah daftar Oracle)
   - Password kuat
   - Nama lengkap
   - No HP Indonesia (+62)
4. Klik **Verify my email**
5. Buka email → klik link verifikasi
6. Masukkan OTP dari SMS
7. **SKIP payment method** (jangan isi kartu kredit)
8. Tunggu approval (biasanya instant, kadang 1-2 hari)

### STEP 2: Create VPS Instance

1. Login → **Compute** → **Instances** → **Create Instance**
2. Name: `slotsite-server`
3. **Image:** Ubuntu 22.04 (Canonical)
4. **Shape:** 
   - Click **Change Shape**
   - Pilih **VM.Standard.E2.1.Micro** (Always Free eligible)
   - 1 OCPU, 1GB RAM
5. **Networking:**
   - Create new VCN: `slotsite-vcn`
   - Subnet: Public
   - Assign public IP: **YES**
6. **SSH Keys:**
   - Option 1: **Generate SSH key pair** → Download private key
   - Option 2: Upload public key (kalo punya)
7. Klik **Create**
8. Tunggu 2-3 menit → Status jadi **Running**
9. Copy **Public IP address**

### STEP 3: Setup Firewall

**PENTING!** Oracle default block semua port kecuali 22.

1. Dashboard → **Networking** → **Virtual Cloud Networks**
2. Klik VCN name (`slotsite-vcn`)
3. Klik **Security Lists** → **Default Security List**
4. **Add Ingress Rules:**

```
Rule 1 (HTTP):
- Source: 0.0.0.0/0
- Protocol: TCP
- Port: 80

Rule 2 (HTTPS):
- Source: 0.0.0.0/0
- Protocol: TCP
- Port: 443

Rule 3 (Node.js):
- Source: 0.0.0.0/0
- Protocol: TCP
- Port: 3000
```

5. **Save Security List Rules**

### STEP 4: SSH ke VPS

**Windows (PowerShell):**
```powershell
ssh -i C:\path\to\private-key.key ubuntu@<PUBLIC-IP>
```

**Mac/Linux:**
```bash
chmod 400 ~/Downloads/private-key.key
ssh -i ~/Downloads/private-key.key ubuntu@<PUBLIC-IP>
```

**PuTTY (Windows):**
1. Download PuTTY: https://www.putty.org/
2. Convert key: PuTTYgen → Load private key → Save as .ppk
3. PuTTY → Host: `ubuntu@<PUBLIC-IP>` → Auth → Browse .ppk → Open

### STEP 5: Install Dependencies

```bash
# Update system
sudo apt update && sudo apt upgrade -y

# Install Node.js 18
curl -fsSL https://deb.nodesource.com/setup_18.x | sudo bash -
sudo apt install -y nodejs

# Verify
node -v  # v18.x
npm -v   # 9.x

# Install MongoDB
curl -fsSL https://www.mongodb.org/static/pgp/server-7.0.asc | sudo gpg --dearmor -o /usr/share/keyrings/mongodb-server-7.0.gpg
echo "deb [ arch=amd64,arm64 signed-by=/usr/share/keyrings/mongodb-server-7.0.gpg ] https://repo.mongodb.org/apt/ubuntu jammy/mongodb-org/7.0 multiverse" | sudo tee /etc/apt/sources.list.d/mongodb-org-7.0.list
sudo apt update
sudo apt install -y mongodb-org

# Start MongoDB
sudo systemctl start mongod
sudo systemctl enable mongod
sudo systemctl status mongod  # check running

# Install PM2
sudo npm install -g pm2
```

### STEP 6: Upload Source Code

**Option A: SCP dari lokal**
```bash
# Dari komputer lokal (Windows PowerShell / Mac Terminal)
scp -i private-key.key jawatoto-source.zip ubuntu@<PUBLIC-IP>:/home/ubuntu/
```

**Option B: Wget (kalo file di cloud)**
```bash
# Di VPS
cd /home/ubuntu
wget https://your-file-host.com/jawatoto-source.zip
```

**Option C: Git (kalo punya repo)**
```bash
cd /home/ubuntu
git clone https://github.com/username/slotsite.git
```

### STEP 7: Extract & Setup

```bash
# Extract
cd /home/ubuntu
unzip jawatoto-source.zip -d slotsite
cd slotsite

# Install dependencies
npm install

# Edit config
nano .env

# Ubah:
PORT=3000
MONGODB_URI=mongodb://localhost:27017/slotking
ADMIN_USERNAME=admin
ADMIN_PASSWORD=GantiPasswordKuat123
JWT_SECRET=random_string_panjang_disini

# Save: CTRL+X, Y, Enter
```

### STEP 8: Start App

```bash
# Test run dulu
node server.js

# Kalo no error, CTRL+C, then:

# Production run dengan PM2
pm2 start server.js --name slotsite

# Auto-restart on reboot
pm2 startup
# Copy-paste command yang muncul, jalankan

pm2 save

# Check status
pm2 status
pm2 logs slotsite
```

### STEP 9: Setup Nginx (Opsional tapi recommended)

```bash
# Install Nginx
sudo apt install -y nginx

# Create config
sudo nano /etc/nginx/sites-available/slotsite

# Paste config ini:
```

```nginx
server {
    listen 80;
    server_name <PUBLIC-IP>;

    location / {
        proxy_pass http://localhost:3000;
        proxy_http_version 1.1;
        proxy_set_header Upgrade $http_upgrade;
        proxy_set_header Connection 'upgrade';
        proxy_set_header Host $host;
        proxy_cache_bypass $http_upgrade;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
    }
}
```

```bash
# Enable site
sudo ln -s /etc/nginx/sites-available/slotsite /etc/nginx/sites-enabled/
sudo rm /etc/nginx/sites-enabled/default

# Test config
sudo nginx -t

# Restart
sudo systemctl restart nginx
```

### STEP 10: Open Ubuntu Firewall

```bash
# Allow ports
sudo ufw allow 22/tcp
sudo ufw allow 80/tcp
sudo ufw allow 443/tcp
sudo ufw allow 3000/tcp

# Enable firewall
sudo ufw enable

# Check
sudo ufw status
```

### STEP 11: Test Site

**Buka browser:**
```
http://<PUBLIC-IP>
atau (kalo pakai Nginx)
http://<PUBLIC-IP>:3000
```

**Login admin:**
- Username: `admin`
- Password: (yang lu set di .env)

---

## 🎯 TROUBLESHOOTING

**Site tidak bisa diakses:**
```bash
# Check app running
pm2 status
pm2 logs slotsite

# Check Nginx
sudo systemctl status nginx

# Check firewall Oracle Cloud Security List
# (paling sering ini masalahnya!)
```

**MongoDB error:**
```bash
# Check MongoDB
sudo systemctl status mongod

# Restart
sudo systemctl restart mongod

# Check logs
sudo tail -f /var/log/mongodb/mongod.log
```

**Port 3000 blocked:**
- Cek Oracle Cloud Security List (Ingress Rules)
- Harus allow port 3000 dari 0.0.0.0/0

---

## 📊 PERBANDINGAN VPS GRATIS

| Provider | RAM | Storage | Bandwidth | No CC | Permanent | Best For |
|----------|-----|---------|-----------|-------|-----------|----------|
| **Oracle Cloud** | 1GB | 200GB | 10TB | ✅ | ✅ | Production |
| **Render** | 512MB | 100GB | 100GB | ✅ | ✅ | Testing |
| **Railway** | Unlimited | Unlimited | Unlimited | ✅ | ❌ ($5/mo) | Dev |
| **GCP Free** | 1GB | 30GB | 1GB | ❌ | ✅ | Need CC |

---

## ✅ REKOMENDASI GUA:

**Untuk lu (gambling site production):**
→ **Oracle Cloud** - permanent free, specs bagus, full control

**Tutorial lengkap sudah ada di atas!** 🚀

**Alternative cepat:**
→ **Render.com** - deploy 2 menit, testing/demo OK

---

**🎰 VPS gratis tanpa kartu kredit - Oracle Cloud tutorial complete! 🎰**
