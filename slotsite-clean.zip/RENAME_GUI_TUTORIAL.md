# 📁 CARA RENAME JAWATOTO VIA FILE MANAGER (GUI)

## 🎯 PANDUAN LENGKAP - TANPA TERMINAL

### STEP 1: EXTRACT ZIP FILE

**Via cPanel File Manager:**
1. Login ke cPanel
2. Klik **File Manager**
3. Pilih folder tujuan (misal: `public_html`)
4. Klik **Upload** → pilih `jawatoto-source.zip`
5. Setelah upload selesai, klik kanan file ZIP
6. Pilih **Extract**
7. Pilih lokasi extract → **Extract Files**

**Via DirectAdmin:**
1. Login DirectAdmin
2. Klik **File Manager**
3. Navigate ke folder tujuan
4. Upload `jawatoto-source.zip`
5. Klik file ZIP → **Extract**

**Via Desktop (Windows):**
1. Klik kanan `jawatoto-source.zip`
2. Pilih **Extract All...**
3. Pilih folder tujuan
4. Klik **Extract**

**Via Desktop (Mac):**
1. Double-click `jawatoto-source.zip`
2. Folder otomatis ter-extract

---

## STEP 2: RENAME BRAND NAME

### File yang WAJIB diedit:

#### ✅ 1. **public/index.html**

**Cari dan ganti:**

| Cari ini | Ganti jadi | Lokasi |
|----------|-----------|--------|
| `🎰 JAWATOTO` | `💎 SLOTKING` | Baris 14 (logo header) |
| `JAWATOTO:` | `SLOTKING:` | Baris 9 (title) |
| `SELAMAT DATANG DI JAWATOTO` | `SELAMAT DATANG DI SLOTKING` | Baris 48 (info banner) |
| `© 2026 JAWATOTO` | `© 2026 SLOTKING` | Baris terakhir (footer) |

**Cara edit via File Manager:**
1. Klik kanan **index.html**
2. Pilih **Edit** atau **Code Edit**
3. Tekan `Ctrl+F` (Windows) atau `Cmd+F` (Mac)
4. Ketik: `JAWATOTO`
5. Ganti satu-satu jadi: `SLOTKING`
6. Klik **Save Changes**

---

#### ✅ 2. **public/dashboard.html**

**Cari dan ganti:**

| Cari ini | Ganti jadi | Lokasi |
|----------|-----------|--------|
| `🎰 JAWATOTO` | `💎 SLOTKING` | Baris 16 (logo) |
| `Dashboard - JAWATOTO` | `Dashboard - SLOTKING` | Baris 5 (title) |

**Cara edit:**
1. Klik kanan **dashboard.html** → **Edit**
2. `Ctrl+F` → cari `JAWATOTO`
3. Ganti semua jadi `SLOTKING`
4. **Save**

---

#### ✅ 3. **public/admin.html**

**Cari dan ganti:**

| Cari ini | Ganti jadi | Lokasi |
|----------|-----------|--------|
| `ADMIN PANEL - JAWATOTO` | `ADMIN PANEL - SLOTKING` | Baris 16 |
| `Admin Panel - JAWATOTO` | `Admin Panel - SLOTKING` | Baris 5 |

**Cara edit:**
1. Klik kanan **admin.html** → **Edit**
2. `Ctrl+F` → cari `JAWATOTO`
3. Ganti jadi `SLOTKING`
4. **Save**

---

#### ✅ 4. **.env** (Config file)

**Edit file .env:**

```env
# SEBELUM:
MONGODB_URI=mongodb://localhost:27017/jawatoto
ADMIN_USERNAME=admin
ADMIN_PASSWORD=admin123

# SESUDAH (ganti jadi nama database baru):
MONGODB_URI=mongodb://localhost:27017/slotking
ADMIN_USERNAME=admin
ADMIN_PASSWORD=GantiPasswordKuatDisini123
```

**⚠️ PENTING:**
- Ganti `jawatoto` jadi `slotking` (lowercase)
- **WAJIB** ganti `ADMIN_PASSWORD` untuk production!
- Ganti `JWT_SECRET` jadi random string panjang

**Cara generate JWT secret random:**
- Buka: https://randomkeygen.com/
- Copy "Fort Knox Passwords" → paste ke `JWT_SECRET=`

---

#### ✅ 5. **README.md**

**Opsional - ganti untuk dokumentasi:**

1. Edit **README.md**
2. Find & Replace:
   - `JAWATOTO` → `SLOTKING`
   - `jawatoto` → `slotking`
3. Save

---

## STEP 3: GANTI WARNA / TEMA

### Edit **public/css/style.css**

**Cari bagian ini (sekitar baris 10-20):**

```css
:root {
    --bg-primary: #0a0e27;
    --bg-secondary: #1a1f3a;
    --bg-card: rgba(26, 31, 58, 0.6);
    --bg-glass: rgba(255, 255, 255, 0.05);
    --text-primary: #ffffff;
    --text-secondary: #b8bcc8;
    --accent-primary: #6366f1;      ← GANTI INI
    --accent-secondary: #8b5cf6;    ← DAN INI
    --success: #10b981;
    --warning: #f59e0b;
    --danger: #ef4444;
    --border: rgba(255, 255, 255, 0.1);
}
```

### 🎨 Pilihan Warna:

#### MERAH (Aggressive):
```css
--accent-primary: #ff6b6b;
--accent-secondary: #ff8787;
```

#### EMAS (Luxury):
```css
--accent-primary: #ffd43b;
--accent-secondary: #ffe066;
```

#### HIJAU (Money):
```css
--accent-primary: #51cf66;
--accent-secondary: #69db7c;
```

#### BIRU (Trust):
```css
--accent-primary: #339af0;
--accent-secondary: #4dabf7;
```

#### ORANGE (Energy):
```css
--accent-primary: #ff922b;
--accent-secondary: #ffa94d;
```

**Cara edit:**
1. Buka **public/css/style.css**
2. Scroll ke bagian `:root {`
3. Ganti nilai `--accent-primary` dan `--accent-secondary`
4. **Save**

---

## STEP 4: GANTI LOGO EMOJI

### Emoji yang recommended:

| Emoji | Code | Cocok untuk |
|-------|------|-------------|
| 💎 | `💎` | Premium, luxury |
| 👑 | `👑` | Royal, VIP |
| 🔥 | `🔥` | Hot, trending |
| ⚡ | `⚡` | Fast, instant |
| 💰 | `💰` | Money focused |
| 🎲 | `🎲` | Casino vibes |
| 🃏 | `🃏` | Card games |
| ♠️ | `♠️` | Poker/cards |
| 🎯 | `🎯` | Target/goal |
| ✨ | `✨` | Magic, special |

**Cara ganti di 3 file HTML:**

**File: index.html, dashboard.html, admin.html**

Cari:
```html
<h1>🎰 JAWATOTO</h1>
```

Ganti jadi (pilih salah satu):
```html
<h1>💎 SLOTKING</h1>
<h1>👑 ROYALSLOT</h1>
<h1>🔥 FIREWIN</h1>
```

---

## STEP 5: GANTI INFO BANNER

**Edit file: public/index.html**

**Cari baris ini (sekitar baris 46-48):**

```html
<div class="info-banner">
    <h3>📢 INFO TERKINI:</h3>
    <p>SELAMAT DATANG DI JAWATOTO AGEN TOGEL ONLINE TERPERCAYA...</p>
</div>
```

**Ganti jadi teks promo lu sendiri:**

```html
<div class="info-banner">
    <h3>📢 INFO TERKINI:</h3>
    <p>SELAMAT DATANG DI SLOTKING! SITUS SLOT GACOR TERPERCAYA #1 INDONESIA 2026. 
    MINIMAL DEPOSIT 10RB, MAXIMAL WITHDRAW UNLIMITED! PROSES DEPOSIT/WITHDRAW 1 MENIT. 
    BONUS NEW MEMBER 100%, CASHBACK HARIAN 20%. DAFTAR SEKARANG!</p>
</div>
```

---

## STEP 6: GANTI FAVICON (Icon di Tab Browser)

**Via File Manager:**

1. Download icon baru (32x32 atau 64x64 px, format .ico atau .png)
2. Rename jadi `favicon.ico`
3. Upload ke folder **public/**
4. Edit **index.html**, **dashboard.html**, **admin.html**
5. Tambah di bagian `<head>`:

```html
<link rel="icon" href="/favicon.ico" type="image/x-icon">
```

**Free icon generator:**
- https://favicon.io/
- https://realfavicongenerator.net/

---

## STEP 7: TEST PERUBAHAN

**Via Browser:**

1. Buka site (misal: `http://localhost:3000` atau `http://vps-ip`)
2. **Hard refresh** untuk clear cache:
   - Windows: `Ctrl + Shift + R`
   - Mac: `Cmd + Shift + R`
3. Check:
   - ✅ Logo berubah jadi nama baru
   - ✅ Warna button sesuai tema baru
   - ✅ Info banner teks baru
   - ✅ Title browser tab

**Kalo masih tampil nama lama:**
- Clear browser cache
- Restart app server (via cPanel/hosting panel)

---

## 🗂️ CHECKLIST RENAME LENGKAP

### Files yang WAJIB diedit:

- [ ] **public/index.html** → Ganti semua `JAWATOTO` jadi nama baru
- [ ] **public/dashboard.html** → Ganti logo & title
- [ ] **public/admin.html** → Ganti admin panel title
- [ ] **.env** → Ganti database name & admin password
- [ ] **public/css/style.css** → Ganti warna tema (opsional)

### Visual Elements:

- [ ] Logo emoji diganti
- [ ] Warna accent (button, link) diganti
- [ ] Info banner teks diganti
- [ ] Footer copyright diganti
- [ ] Favicon (browser icon) diganti (opsional)

### Testing:

- [ ] Hard refresh browser
- [ ] Test login admin
- [ ] Check semua halaman
- [ ] Mobile responsive test

---

## 💡 TIPS FILE MANAGER

**cPanel Tips:**
- Gunakan **Code Editor** (bukan Text Editor) untuk syntax highlighting
- Backup file sebelum edit: klik kanan → **Copy**
- Kalo salah edit: restore dari backup

**Search & Replace di File Manager:**
1. Edit file
2. `Ctrl+F` → cari text
3. Manual ganti satu-satu
4. Atau pakai **Find & Replace** (kalo ada):
   - `Ctrl+H` (Windows)
   - `Cmd+Option+F` (Mac)

**File Permission:**
- `.env` harus permission `600` (read/write owner only)
- Klik kanan → **Permissions** → set `600`

---

## 🚨 COMMON MISTAKES

❌ **Ganti nama file:**
- Jangan rename file `.html` atau `.js`!
- Cuma ganti ISI file, bukan nama filenya

❌ **Lupa ganti .env:**
- Database name harus lowercase: `slotking` bukan `SLOTKING`
- Kalo lupa, app tidak bisa connect ke database

❌ **Typo di CSS:**
- Kalo warna tidak berubah, check typo di `:root {}`
- Pastikan format warna: `#ff6b6b` (# + 6 digit hex)

❌ **Lupa hard refresh:**
- Browser cache CSS & JS
- Selalu `Ctrl+Shift+R` setelah edit

---

## 📞 BANTUAN

**Kalo stuck:**
1. Backup dulu sebelum edit
2. Edit satu file dulu → test
3. Kalo error, restore backup
4. Upload file baru (jangan edit via file manager)

**Quick backup via File Manager:**
1. Klik kanan file → **Copy**
2. Rename copy jadi `index.html.backup`
3. Sekarang aman untuk edit `index.html`

---

**🎰 Tutorial rename via file manager - NO CODING NEEDED! 🎰**
