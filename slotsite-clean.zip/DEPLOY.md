# 🔧 CARA RENAME & DEPLOY JAWATOTO

## 📝 CARA RENAME / REBRAND

### 1. Ganti Nama Site
**File yang perlu diubah:**

```bash
# Ganti semua "JAWATOTO" jadi nama baru (misal: "SLOTKING")
# Ganti semua "jawatoto" jadi nama baru lowercase

# 1. public/index.html
sed -i 's/JAWATOTO/SLOTKING/g' public/index.html
sed -i 's/jawatoto/slotking/g' public/index.html

# 2. public/dashboard.html
sed -i 's/JAWATOTO/SLOTKING/g' public/dashboard.html

# 3. public/admin.html
sed -i 's/JAWATOTO/SLOTKING/g' public/admin.html

# 4. README.md
sed -i 's/JAWATOTO/SLOTKING/g' README.md
sed -i 's/jawatoto/slotking/g' README.md

# 5. .env (database name)
sed -i 's/jawatoto/slotking/g' .env

# 6. server.js (kalo ada hardcoded)
sed -i 's/jawatoto/slotking/g' server.js
```

### 2. Ganti Warna / Theme
**Edit: public/css/style.css**

```css
/* Ganti di bagian :root {} */
:root {
    --accent-primary: #ff6b6b;  /* Merah contoh */
    --accent-secondary: #ff8787; /* Merah muda */
}
```

**Color presets:**
- Merah: `#ff6b6b` / `#ff8787`
- Hijau: `#51cf66` / `#69db7c`
- Emas: `#ffd43b` / `#ffe066`
- Biru: `#339af0` / `#4dabf7`

### 3. Ganti Logo Emoji
**Edit semua file HTML:**

```html
<!-- Ganti 🎰 jadi emoji lain -->
<h1>💎 SLOTKING</h1>  <!-- Diamond -->
<h1>👑 SLOTKING</h1>  <!-- Crown -->
<h1>🔥 SLOTKING</h1>  <!-- Fire -->
<h1>💰 SLOTKING</h1>  <!-- Money -->
```

---

## 🚀 CARA DEPLOY KE VPS

### Opsi 1: Deploy ke VPS LO (101.32.168.130)

**1. Upload source ke VPS:**
```bash
# Dari lokal
scp jawatoto-source.zip root@101.32.168.130:/root/

# SSH ke VPS
ssh root@101.32.168.130

# Extract
cd /root
unzip jawatoto-source.zip -d /var/www/slotsite
cd /var/www/slotsite
```

**2. Install dependencies di VPS:**
```bash
# Install Node.js (kalo belum)
curl -fsSL https://deb.nodesource.com/setup_18.x | bash -
apt-get install -y nodejs

# Install MongoDB
curl -fsSL https://www.mongodb.org/static/pgp/server-7.0.asc | gpg --dearmor -o /usr/share/keyrings/mongodb-server-7.0.gpg
echo "deb [ arch=amd64,arm64 signed-by=/usr/share/keyrings/mongodb-server-7.0.gpg ] https://repo.mongodb.org/apt/ubuntu jammy/mongodb-org/7.0 multiverse" | tee /etc/apt/sources.list.d/mongodb-org-7.0.list
apt-get update
apt-get install -y mongodb-org

# Install project dependencies
npm install

# Install PM2 (process manager)
npm install -g pm2
```

**3. Setup MongoDB:**
```bash
# Start MongoDB
systemctl start mongod
systemctl enable mongod

# Verify
systemctl status mongod
```

**4. Configure environment:**
```bash
# Edit .env
nano .env

# Ubah PORT jika perlu (default 3000)
PORT=3000

# Ubah admin credentials
ADMIN_USERNAME=admin
ADMIN_PASSWORD=GantiPasswordKuat123

# Save: CTRL+X, Y, Enter
```

**5. Setup Nginx reverse proxy:**
```bash
# Install Nginx
apt-get install -y nginx

# Create config
nano /etc/nginx/sites-available/slotsite

# Isi config:
```

```nginx
server {
    listen 80;
    server_name 101.32.168.130;  # atau domain lu

    location / {
        proxy_pass http://localhost:3000;
        proxy_http_version 1.1;
        proxy_set_header Upgrade $http_upgrade;
        proxy_set_header Connection 'upgrade';
        proxy_set_header Host $host;
        proxy_cache_bypass $http_upgrade;
    }
}
```

```bash
# Enable site
ln -s /etc/nginx/sites-available/slotsite /etc/nginx/sites-enabled/
rm /etc/nginx/sites-enabled/default

# Test & restart
nginx -t
systemctl restart nginx
```

**6. Start app dengan PM2:**
```bash
cd /var/www/slotsite

# Start
pm2 start server.js --name slotsite

# Auto-restart on reboot
pm2 startup
pm2 save

# Check status
pm2 status
pm2 logs slotsite
```

**7. Setup firewall:**
```bash
# UFW
ufw allow 80/tcp
ufw allow 443/tcp
ufw allow 22/tcp
ufw enable
```

**8. Access site:**
```
http://101.32.168.130
```

---

### Opsi 2: Deploy dengan Domain

**1. Setup DNS:**
```
A Record: @ -> 101.32.168.130
A Record: www -> 101.32.168.130
```

**2. Install SSL (Let's Encrypt):**
```bash
# Install certbot
apt-get install -y certbot python3-certbot-nginx

# Get certificate
certbot --nginx -d yourdomain.com -d www.yourdomain.com

# Auto-renew
systemctl enable certbot.timer
```

**3. Update Nginx config:**
```nginx
server {
    listen 80;
    server_name yourdomain.com www.yourdomain.com;
    return 301 https://$server_name$request_uri;
}

server {
    listen 443 ssl http2;
    server_name yourdomain.com www.yourdomain.com;

    ssl_certificate /etc/letsencrypt/live/yourdomain.com/fullchain.pem;
    ssl_certificate_key /etc/letsencrypt/live/yourdomain.com/privkey.pem;

    location / {
        proxy_pass http://localhost:3000;
        proxy_http_version 1.1;
        proxy_set_header Upgrade $http_upgrade;
        proxy_set_header Connection 'upgrade';
        proxy_set_header Host $host;
        proxy_cache_bypass $http_upgrade;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
    }
}
```

```bash
# Restart
nginx -t
systemctl restart nginx
```

---

## 🔐 SECURITY HARDENING (Production)

**1. Ganti JWT secret:**
```bash
# Generate random secret
openssl rand -base64 32

# Paste ke .env
JWT_SECRET=hasil_random_di_atas
```

**2. Setup MongoDB authentication:**
```bash
mongosh

use admin
db.createUser({
  user: "slotadmin",
  pwd: "PasswordKuat123",
  roles: [{role: "root", db: "admin"}]
})

exit
```

```bash
# Edit MongoDB config
nano /etc/mongod.conf

# Uncomment & enable:
security:
  authorization: enabled

# Restart
systemctl restart mongod
```

```bash
# Update .env
MONGODB_URI=mongodb://slotadmin:PasswordKuat123@localhost:27017/slotking?authSource=admin
```

**3. Restart app:**
```bash
pm2 restart slotsite
```

---

## 📊 MONITORING & MAINTENANCE

**Check logs:**
```bash
# App logs
pm2 logs slotsite

# MongoDB logs
tail -f /var/log/mongodb/mongod.log

# Nginx logs
tail -f /var/log/nginx/access.log
tail -f /var/log/nginx/error.log
```

**Restart services:**
```bash
pm2 restart slotsite
systemctl restart mongod
systemctl restart nginx
```

**Update code:**
```bash
cd /var/www/slotsite
git pull  # kalo pake git
# atau
# upload file baru via SCP

pm2 restart slotsite
```

---

## 🎯 QUICK DEPLOY SCRIPT

```bash
#!/bin/bash
# deploy.sh - Run ini untuk auto deploy

cd /var/www/slotsite
git pull origin main  # or upload manually
npm install
pm2 restart slotsite
echo "✅ Deploy complete!"
```

```bash
chmod +x deploy.sh
./deploy.sh
```

---

## 📞 TROUBLESHOOTING

**Site tidak bisa diakses:**
```bash
# Check app
pm2 status
pm2 logs slotsite --lines 50

# Check Nginx
systemctl status nginx
nginx -t

# Check MongoDB
systemctl status mongod
mongosh
```

**Port 3000 already in use:**
```bash
# Find process
lsof -i :3000

# Kill
kill -9 <PID>

# Atau
pm2 delete slotsite
pm2 start server.js --name slotsite
```

**MongoDB connection failed:**
```bash
# Check service
systemctl status mongod

# Restart
systemctl restart mongod

# Check logs
tail -f /var/log/mongodb/mongod.log
```

---

## ✅ CHECKLIST DEPLOY

- [ ] Upload source ke VPS
- [ ] Install Node.js + MongoDB
- [ ] npm install
- [ ] Edit .env (port, credentials, JWT secret)
- [ ] Start MongoDB
- [ ] Setup Nginx reverse proxy
- [ ] Start app dengan PM2
- [ ] Setup firewall (port 80, 443, 22)
- [ ] Test akses http://IP-VPS
- [ ] (Optional) Setup domain + SSL
- [ ] Ganti admin password di production
- [ ] Setup MongoDB authentication
- [ ] Test login admin
- [ ] Test register member
- [ ] Test deposit/withdraw flow

**Site ready untuk production! 🚀**
