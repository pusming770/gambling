# 🎰 JAWATOTO - Slot Gambling Site Clone

Clone lengkap dari situs slot gambling dengan admin panel full access untuk manajemen member.

## 🚀 STATUS: LIVE & RUNNING

✅ Server: http://localhost:3000  
✅ MongoDB: Running  
✅ Real-time Socket.IO: Active

---

## 📂 STRUKTUR PROJECT

```
/root/workspace/7554333225/
├── server.js                 # Backend Node.js + Express + Socket.IO
├── package.json              # Dependencies
├── .env                      # Environment variables
├── public/
│   ├── index.html           # Landing page dengan login/register
│   ├── dashboard.html       # Member dashboard (slot games)
│   ├── admin.html           # Admin panel (member management)
│   ├── css/
│   │   └── style.css        # Material Design 3 Dark Theme
│   └── js/
│       ├── main.js          # Landing page logic
│       ├── dashboard.js     # Member dashboard logic
│       └── admin.js         # Admin panel logic
```

---

## 🔐 AKUN DEFAULT

### Admin Account
- **Username:** `admin`
- **Password:** `admin123`
- **Access:** Full control panel untuk manage member & transaksi

### Test Member Account
Register baru via http://localhost:3000

---

## 🎯 FITUR UTAMA

### 1️⃣ **Landing Page** (/)
- Login form
- Register form  
- Real-time deposit/withdraw ticker (live updates via Socket.IO)
- Info banner
- Material Design 3 dark theme dengan glassmorphism

### 2️⃣ **Member Dashboard** (/dashboard.html)
- Balance display (real-time updates)
- Slot games grid (Pragmatic Play, PG Soft, Habanero, dll)
- Deposit request form
- Withdraw request form
- Quick amount buttons (50K, 100K, 200K, 500K, 1JT)

### 3️⃣ **Admin Panel** (/admin.html)
- **Member Management:**
  - View all members
  - Edit balance (real-time update)
  - Suspend/activate accounts
  - Delete members
  - Search functionality
  
- **Transaction Management:**
  - View all deposits & withdraws
  - Approve/reject pending transactions
  - Filter by status (pending/approved/rejected)
  - Real-time ticker updates on approval
  
- **Statistics Dashboard:**
  - Total members
  - Total deposits
  - Total withdraws
  - Pending transactions count

---

## 🛠️ TEKNOLOGI

- **Backend:** Node.js + Express
- **Database:** MongoDB
- **Real-time:** Socket.IO
- **Auth:** JWT + bcrypt
- **Frontend:** Vanilla JS + Material Design 3
- **Styling:** Glassmorphism + Dark theme

---

## 📡 API ENDPOINTS

### Public
- `POST /api/login` - Login member/admin
- `POST /api/register` - Register member baru
- `GET /api/transactions/recent` - Get recent transactions untuk ticker

### Member (Requires Auth)
- `GET /api/profile` - Get user profile
- `POST /api/deposit` - Request deposit
- `POST /api/withdraw` - Request withdraw

### Admin (Requires Auth + Admin Role)
- `GET /api/admin/users` - Get all users
- `POST /api/admin/users/:id/balance` - Update user balance
- `POST /api/admin/users/:id/status` - Update user status
- `DELETE /api/admin/users/:id` - Delete user
- `GET /api/admin/transactions` - Get all transactions
- `POST /api/admin/transactions/:id/approve` - Approve transaction
- `POST /api/admin/transactions/:id/reject` - Reject transaction

---

## 🔄 REAL-TIME FEATURES

### Socket.IO Events
- `new-transaction` - Broadcast transaksi baru ke semua client
- `balance-update` - Update balance member secara real-time

### Auto-Generated Transactions
Server generate fake transactions setiap 10 detik untuk demo ticker.

---

## 🎨 DESIGN FEATURES

- **Material Design 3 Dark Theme**
- **Glassmorphism effects** dengan backdrop-filter blur
- **Gradient accents** (Purple/Indigo)
- **Smooth animations** dan transitions
- **Responsive layout** (mobile-friendly)
- **Custom scrollbars**
- **Animated background gradient**

---

## 🚀 CARA MENJALANKAN

### Start Server (Already Running)
```bash
cd /root/workspace/7554333225
node server.js
```

### Start MongoDB (Already Running)
```bash
mongod --dbpath /var/lib/mongodb --logpath /var/log/mongodb/mongod.log --fork
```

### Stop Everything
```bash
# Kill Node server
pkill -f "node server.js"

# Kill MongoDB
pkill mongod
```

---

## 🔧 KONFIGURASI (.env)

```env
PORT=3000
MONGODB_URI=mongodb://localhost:27017/jawatoto
JWT_SECRET=jawatoto_secret_key_2026_super_secure_random_string
ADMIN_USERNAME=admin
ADMIN_PASSWORD=admin123
```

---

## 📝 CARA PENGGUNAAN

### Sebagai Admin:
1. Buka http://localhost:3000
2. Login dengan `admin` / `admin123`
3. Redirect otomatis ke admin panel
4. Manage member: edit balance, suspend, delete
5. Approve/reject deposit/withdraw requests

### Sebagai Member:
1. Buka http://localhost:3000
2. Register akun baru
3. Login dengan akun yang sudah dibuat
4. Request deposit (akan pending sampai admin approve)
5. Main slot games
6. Request withdraw (balance harus cukup)

---

## 🎰 GAME PROVIDERS

- Pragmatic Play
- PG Soft
- Habanero
- Microgaming
- Playtech
- Spade Gaming

(Game buttons sudah ada, tinggal integrate dengan game provider API)

---

## 📊 DATABASE SCHEMA

### Users Collection
```javascript
{
  username: String (unique),
  password: String (bcrypt hashed),
  email: String,
  phone: String,
  balance: Number (default: 0),
  role: "member" | "admin",
  status: "active" | "suspended",
  createdAt: Date,
  lastLogin: Date
}
```

### Transactions Collection
```javascript
{
  userId: ObjectId (ref: User),
  username: String,
  type: "deposit" | "withdraw",
  amount: Number,
  status: "pending" | "approved" | "rejected",
  createdAt: Date
}
```

---

## 🔒 SECURITY FEATURES

- Password hashing dengan bcrypt
- JWT authentication dengan HTTP-only cookies
- Admin role checking middleware
- Input validation
- CORS enabled
- Sanitized usernames di ticker (masked display)

---

## 📱 RESPONSIVE DESIGN

- Desktop: Full sidebar + main content
- Mobile: Collapsible sidebar, stacked layout
- Touch-friendly buttons
- Smooth scrolling

---

## 🎯 NEXT STEPS (Optional Enhancements)

1. **Integrate Real Game Providers:**
   - Connect dengan Pragmatic Play API
   - Connect dengan PG Soft API
   
2. **Payment Gateway Integration:**
   - QRIS
   - Bank transfer
   - E-wallet (GoPay, OVO, Dana)

3. **Admin Analytics:**
   - Revenue charts
   - Member activity graphs
   - Game popularity stats

4. **Member Features:**
   - Transaction history page
   - Referral system
   - Bonus/promo claims

---

## 📞 SUPPORT

Project dibuat untuk: LO  
Workspace: /root/workspace/7554333225/  
Date: 2026-07-24

---

**🎰 SELAMAT DATANG DI JAWATOTO! 🎰**
