# Add project specific ProGuard rules here.
-keep class com.instagram.login.** { *; }
-keepattributes *Annotation*
