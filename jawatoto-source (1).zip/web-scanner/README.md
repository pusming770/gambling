# Web Vulnerability Scanner - All-in-One Penetration Testing Tool

Automated security assessment suite untuk website dengan 11 modul testing.

## 🎯 FITUR

### Vulnerability Testing:
1. **SQL Injection** - 20+ payloads, error-based detection
2. **XSS (Cross-Site Scripting)** - Reflected XSS detection
3. **LFI/RFI (File Inclusion)** - Local/Remote file inclusion
4. **Command Injection** - OS command execution testing
5. **Open Redirect** - URL redirection vulnerabilities

### Information Gathering:
6. **Directory Bruteforce** - 40+ common paths
7. **Admin Panel Finder** - 20+ admin paths
8. **Subdomain Enumeration** - 30+ common subdomains
9. **Port Scanning** - 22 common ports
10. **CMS Detection** - WordPress, Joomla, Drupal, Magento
11. **Security Headers** - Missing security headers check
12. **SSL/TLS Check** - Certificate and protocol validation

## 📦 INSTALASI

```bash
# Install dependencies
pip3 install requests

# atau
pip3 install -r requirements.txt
```

## 🚀 USAGE

### Basic Scan
```bash
python3 scanner.py https://target.com
```

### With Custom Thread Count
```bash
python3 scanner.py https://target.com 20
```

### Scan dengan Save Output
```bash
python3 scanner.py https://target.com 2>&1 | tee scan_output.txt
```

## 📊 OUTPUT

Scanner akan generate:
1. **Real-time console output** - Progress dan findings
2. **JSON report** - `scan_report_domain_timestamp.json`

### Sample JSON Report Structure:
```json
{
  "sql_injection": [
    {
      "type": "SQL Injection",
      "severity": "HIGH",
      "url": "https://target.com/page?id=' OR '1'='1",
      "parameter": "id",
      "payload": "' OR '1'='1",
      "indicator": "mysql"
    }
  ],
  "xss": [...],
  "lfi": [...],
  "sensitive_files": [...],
  "admin_panels": [...],
  "subdomains": [...],
  "open_ports": [...],
  "cms_info": {"name": "WordPress", "version": "6.0"},
  "headers": {
    "present": ["X-Frame-Options"],
    "missing": ["Content-Security-Policy"]
  }
}
```

## 🔧 ADVANCED USAGE

### Scan Multiple Targets
```bash
# Create targets.txt
cat > targets.txt <<EOF
https://target1.com
https://target2.com
https://target3.com
EOF

# Scan all
for url in $(cat targets.txt); do
    python3 scanner.py $url 15
done
```

### Integration dengan Automation
```bash
#!/bin/bash
# Auto scan dan notify

URL=$1
python3 scanner.py $URL > report.txt

# Check if vulnerabilities found
if grep -q "VULNERABILITIES FOUND:" report.txt; then
    # Send notification (Discord/Telegram)
    curl -X POST "https://discord.com/api/webhooks/YOUR_WEBHOOK" \
         -H "Content-Type: application/json" \
         -d "{\"content\": \"Vulnerabilities found on $URL\"}"
fi
```

## 🎭 PAYLOADS INCLUDED

### SQL Injection (20 payloads)
- Error-based: `' OR '1'='1`, `admin' --`
- Union-based: `' UNION SELECT NULL--`
- Blind: `1' AND '1'='1`

### XSS (20 payloads)
- Script tags: `<script>alert("XSS")</script>`
- Event handlers: `<img src=x onerror=alert("XSS")>`
- SVG: `<svg/onload=alert("XSS")>`

### LFI (13 payloads)
- Linux: `../../../etc/passwd`
- Windows: `..\..\..\\windows\\win.ini`
- PHP wrappers: `php://filter/...`

### Command Injection (14 payloads)
- Linux: `; id`, `| whoami`
- Windows: `& dir`, `| type`

## 🛡️ DETECTION METHODS

### SQL Injection
Error indicators:
- `mysql`, `sql syntax error`
- `database`, `postgresql`
- `odbc`, `jdbc`

### LFI
Success indicators:
- `root:`, `bin:` (Linux /etc/passwd)
- `[extensions]` (Windows win.ini)

### Command Injection
Success indicators:
- `uid=`, `gid=` (Linux id output)
- `Directory of` (Windows dir)

## 📈 PERFORMANCE

- **Threads**: Configurable (default: 10)
- **Timeout**: 5-10 seconds per request
- **Speed**: ~50-100 requests per minute

### Optimization Tips:
```bash
# Faster scan (more threads)
python3 scanner.py https://target.com 30

# Slower but stealthier
python3 scanner.py https://target.com 5
```

## 🚨 LIMITATIONS

1. **No authentication bypass** - Doesn't test login forms
2. **Basic payloads** - Not exhaustive like professional tools
3. **No blind SQLi** - Only error-based detection
4. **No DOM XSS** - Only reflected XSS
5. **No CSRF testing** - Not included

## 🔐 LEGAL DISCLAIMER

**IMPORTANT**: Only use on:
- Your own websites
- Websites you have written permission to test
- Bug bounty programs

Unauthorized scanning is **ILLEGAL** in most jurisdictions.

## 🆚 COMPARISON WITH OTHER TOOLS

| Feature | This Scanner | Nikto | OWASP ZAP | Burp Suite |
|---------|--------------|-------|-----------|------------|
| Speed | Fast | Medium | Slow | Medium |
| Payloads | Basic | Medium | Advanced | Advanced |
| Easy Setup | ✓ | ✓ | - | - |
| Free | ✓ | ✓ | ✓ | Limited |
| CLI Only | ✓ | ✓ | - | - |

## 📚 RESOURCES

### Learn More:
- OWASP Top 10: https://owasp.org/www-project-top-ten/
- SQL Injection: https://portswigger.net/web-security/sql-injection
- XSS: https://portswigger.net/web-security/cross-site-scripting

### Similar Tools:
- **Nikto**: Web server scanner
- **WPScan**: WordPress vulnerability scanner
- **sqlmap**: Automated SQL injection tool
- **XSStrike**: Advanced XSS detection

## 🔧 TROUBLESHOOTING

### Common Issues:

**Q: "Connection timeout" errors?**
A: Increase timeout or reduce threads:
```bash
python3 scanner.py https://target.com 5
```

**Q: "SSL verification failed"?**
A: Scanner disables SSL verification by default

**Q: No vulnerabilities found on vulnerable site?**
A: 
- Site might use WAF (Cloudflare, etc)
- Payloads might be outdated
- Need more advanced testing

**Q: Too many false positives?**
A: Manual verification required for all findings

## 🎯 REAL-WORLD USAGE

### Bug Bounty Workflow:
```bash
# 1. Subdomain enumeration
python3 scanner.py https://target.com > subdomains.txt

# 2. Extract subdomains from JSON report
cat scan_report_*.json | jq -r '.subdomains[]' > subs.txt

# 3. Scan each subdomain
for sub in $(cat subs.txt); do
    python3 scanner.py https://$sub
done

# 4. Review findings and report
```

### Continuous Monitoring:
```bash
# Cron job - daily scan
0 2 * * * cd /path/to/scanner && python3 scanner.py https://mysite.com
```

## 📝 CHANGELOG

**v1.0.0** (2026-07-22)
- Initial release
- 11 testing modules
- Multi-threaded scanning
- JSON report generation

## 🤝 CONTRIBUTING

Contributions welcome! Add more:
- Payloads
- Detection methods
- Testing modules
- Performance improvements

## ⚠️ RESPONSIBLE DISCLOSURE

If you find vulnerabilities:
1. Report to website owner first
2. Give time to fix (90 days standard)
3. Don't exploit for personal gain
4. Follow responsible disclosure guidelines
