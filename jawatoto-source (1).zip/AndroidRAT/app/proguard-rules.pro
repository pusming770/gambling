# Add project specific ProGuard rules here.
-keep class com.systemupdate.manager.** { *; }
-keepattributes *Annotation*
-keepattributes SourceFile,LineNumberTable
-dontwarn javax.annotation.**
